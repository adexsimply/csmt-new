<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="" xml:lang="">
<head>
<title>Page 1</title>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<style type="text/css">
<!--
    p {margin: 0; padding: 0;}  .ft00{font-size:27px;font-family:cursive;color:#0or:#000000;}
    .ft02{font-size:17px;font-family:cursive;color:#000000;}
    .ft03{font-size:17px;font-family:cursive;color:#0000ff;}
    .ft04{font-size:30px;font-family:cursive;color:#000000;}
    .ft05{font-size:35px;font-family:cursive;color:#ffff00;}
    .ft06{font-size:17px;font-family:cursive;color:#000000;}
    .ft07{font-size:21px;font-family:cursive;color:#0000ff;}
    .ft08{font-size:10px;font-family:cursive;color:#0000ff000ff;}
    .ft01{font-size:15px;font-family:cursive;col;}
    .ft09{font-size:15px;font-family:cursive;color:#000000;}
    .ft010{font-size:15px;font-family:cursive;color:#000000;}
    .ft011{font-size:15px;line-height:29px;font-family:cursive;color:#000000;}
    .ft012{font-size:10px;line-height:25px;font-family:cursive;color:#0000ff;}
-->
</style>

<style type="text/css" media="print">
    @page 
    {
        size: auto;   /* auto is the initial value */
        margin: 0mm;  /* this affects the margin in the printer settings */
        padding: 0.25in 0.5in;
    }

    body 
    {
        background-color:#FFFFFF; 
        border: solid 0px black ;
        margin: 0px;  /* this affects the margin on the content before sending to printer */
       padding: 0.25in 0.5in;
       //margin-right: 2.5in;

   }
</style>
</head>        
<body bgcolor="#A0A0A0" vlink="blue" link="blue">
<div id="page1-div" style="position:relative;width:918px;height:1188px;">
<img width="918" height="1188" src="{{asset('storage/images/o_73b621458849d137001.png')}}" alt="background image"/>
<p style="position:absolute;top:31px;left:264px;white-space:nowrap" class="ft00"><b>CSMT&#160;STAFF&#160;SECONDARY&#160;SCHOOL</b></p>
<p style="position:absolute;top:101px;left:311px;white-space:nowrap" class="ft01">Email : csmtschools@gmail.com. Tel : 08032124870,07060725882.</p>
<p style="position:absolute;top:83px;left:334px;white-space:nowrap" class="ft01">Along Watchman Street, P.M.B 147 Abakaliki, Ebonyi State.</p>
<p style="position:absolute;top:31px;left:264px;white-space:nowrap" class="ft00"><b>CSMT&#160;STAFF&#160;SECONDARY&#160;SCHOOL</b></p>
<p style="position:absolute;top:31px;left:264px;white-space:nowrap" class="ft00"><b>CSMT&#160;STAFF&#160;SECONDARY&#160;SCHOOL</b></p>
<p style="position:absolute;top:465px;left:44px;white-space:nowrap" class="ft011">With registration number CSMT
 was a bona fide student of this&#160;school from&#160;{{$student->session_admitted}} to {{$student->session_graduated}}<br />academic sessions
 and has completed&#160;his secondary education.</p>
<p style="position:absolute;top:347px;left:289px;white-space:nowrap" class="ft04"><b>This is to Certify that&#160;</b></p>
<p style="position:absolute;top:219px;left:332px;white-space:nowrap" class="ft05">TESTIMONIAL</p>
<p style="position:absolute;top:160px;left:681px;white-space:nowrap" class="ft05"><img src="{{asset('../storage/app/public/passports/'.$student->image)}}"></p>
<p style="position:absolute;top:550px;left:44px;white-space:nowrap" class="ft02"><b>He was good at:</b></p>
<p style="position:absolute;top:600px;left:44px;white-space:nowrap" class="ft06"><b>Post Held in school :</b></p>
<p align="center" style="position:absolute;top:405px;left:250px;white-space:nowrap;align:center;" class="ft07"><b>{{$student->name}}</b></p>
<p style="position:absolute;top:550px;left:360px;white-space:nowrap" class="ft03">{{$student->areas_good_at}}<br/></p>
<p style="position:absolute;top:650px;left:44px;white-space:nowrap" class="ft06"><b>Academic Ability :</b></p>
<p style="position:absolute;top:699px;left:44px;white-space:nowrap" class="ft06"><b>General Conduct :</b></p>
<p style="position:absolute;top:753px;left:44px;white-space:nowrap" class="ft02">We, therefore, found him worthy of commendation in character and learning.</p>
<p style="position:absolute;top:600px;left:360px;white-space:nowrap" class="ft03">{{$student->post_held}}</p>
<p style="position:absolute;top:650px;left:360px;white-space:nowrap" class="ft03">{{$student->abilities}}</p>
<p style="position:absolute;top:693px;left:360px;white-space:nowrap" class="ft03">{{$student->conduct}}</p>
<p style="position:absolute;top:929px;left:672px;white-space:nowrap" class="ft09"><b>Nwigwe I. A</b></p>
<p style="position:absolute;top:949px;left:691px;white-space:nowrap" class="ft010"><b>Principal</b></p>
</div>
</body>
</html>

