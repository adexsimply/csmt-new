<?php 
	use App\Student;
	use App\Aagc;

	$students = Student::find(1);

	dd($students);
?>

