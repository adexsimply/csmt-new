@extends('layouts.app')
@section('title','Page not found')
@section('content')
  <div class="row">  
      <div class='col-md-4 center-block'>
          <h3><center>401</center></h3><br>
          <p><center>Full Authentication required to view this Page.</center></p>
      </div>
  </div>
@endsection