<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Assessment extends Model
{
    protected $fillable = ['test1','test2','test3','exam','student_id','aagc_id','session_id','term_id','subject_id'];



    /*Print specified subject assessment for a given class*/
    public static function printer($fiddle){

    	$assessments = Assessment::where($fiddle)
    			->join('students','students.id','=','assessments.student_id')
    			->select('students.id as student_id','students.surname','students.othernames','students.admission_no','assessments.id',
    				DB::raw('testScore(assessments.test1) as test1'),
    				DB::raw('testScore(assessments.test2) as test2'),
    				DB::raw('testScore(assessments.test3) as test3'),
    				DB::raw('examScore(assessments.exam) as exam'),
    				DB::raw('gradePoint(test1,test2,test3,exam) as gp'),
    				DB::raw('grade(gradePoint(test1,test2,test3,exam)) as grade'),
    				DB::raw('remark(gradePoint(test1,test2,test3,exam)) as remark')
    				)
    			->orderBy('gp','DESC')
				->get();

        return $assessments;
    }






    /*Print all class students' grades for all subjects*/
    public static function classAssessment($fiddle){
    	$assessments = Assessment::where($fiddle)
    			->join('students','students.id','=','assessments.student_id')
    			->join('subjects','subjects.id','=','assessments.subject_id')
				->select('students.id as student_id','students.surname','students.othernames','students.admission_no','subjects.name as subject_name',
    				DB::raw('gradePoint(assessments.test1,assessments.test2,assessments.test3,assessments.exam) as gp')
    				)              
				->simplePaginate(100);

		return $assessments;
    }





    /* Can't imagine myself writing this function. However, it lazy load student grade in a subject loop  */
    public static function stupidLoading($subject_id,$student_id,$aagc_id,$session_id,$term_id=false,$cummulative=false){

    	
    	/*Calculate the cummulative (Add all terms score) of a specified subject and student*/
    	if($cummulative){
    		$score = self::where([
	    		['subject_id',$subject_id],
	    		['student_id',$student_id],
	    		['aagc_id',$aagc_id],
	    		['session_id',$session_id]

	    	])

    		->select(
    					DB::raw('(IFNULL(sum(test1),0) / '.$cummulative.') AS test1'), 
    					DB::raw('(IFNULL(sum(test2),0) / '.$cummulative.') AS test2'), 
    					DB::raw('(IFNULL(sum(test3),0) / '.$cummulative.') AS test3'), 
    					DB::raw('(IFNULL(sum(exam),0) / '.$cummulative.') AS exam') 
    				)
	    	->first();
    	}


    	/*Collect student grade for a given term*/
    	else
	    	$score = self::where([
	    		['subject_id',$subject_id],
	    		['student_id',$student_id],
	    		['aagc_id',$aagc_id],
	    		['session_id',$session_id],
	    		['term_id',$term_id]

	    	])->first(['test1','test2','test3','exam']);



    	return round(self::gradePoint($score->test1,$score->test2,$score->test3,$score->exam));
    }





    /*Collect all class student that have been assessed*/
    public static function classStudent($aagc_id,$session_id,$term_id=false){

    	/*Collect students in a given term*/
    	if($term_id)
    		$students = DB::select('SELECT DISTINCT std.id, std.admission_no,std.othernames,std.surname FROM (SELECT student_id FROM assessments WHERE aagc_id='.$aagc_id.' AND session_id='.$session_id.' AND term_id='.$term_id.') ass inner join (SELECT id,admission_no,othernames,surname FROM students) std on ass.student_id = std.id ORDER BY std.surname ASC');

    	/*Collect student in a given session*/
    	else
    		$students = DB::select('SELECT DISTINCT std.id, std.admission_no,std.othernames,std.surname FROM (SELECT student_id FROM assessments WHERE aagc_id='.$aagc_id.' AND session_id='.$session_id.') ass inner join (SELECT id,admission_no,othernames,surname FROM students) std on ass.student_id = std.id ORDER BY std.surname ASC');


    	return $students;
    }




    /*Collect subjects that has assessment stored in the assessment table*/
    public static function classSubject($aagc_id,$session_id,$term_id=false){
    	
    	/*Collect subject in a given term*/
    	if($term_id)
    		$subjects = DB::select('SELECT DISTINCT sub.id, sub.name FROM (SELECT subject_id FROM assessments WHERE aagc_id='.$aagc_id.' AND session_id='.$session_id.' AND term_id='.$term_id.') ass INNER JOIN subjects sub ON ass.subject_id = sub.id ORDER BY sub.name ASC');


    	/*Collect subject in a given session*/
    	else
    		$subjects = DB::select('SELECT DISTINCT sub.id, sub.name FROM (SELECT subject_id FROM assessments WHERE aagc_id='.$aagc_id.' AND session_id='.$session_id.') ass INNER JOIN subjects sub ON ass.subject_id = sub.id ORDER BY sub.name ASC');


    	return $subjects;
    }







    /*Url to statement of result print page*/
    public static function printUrl($student_id,$aagc_id,$session_id,$term_id=false,$cummulative=false){

    	$url = null;

    	/*Print a student's statement of result for a given term*/
    	if($term_id)
    		$url = url('assessments/print-term-statement/'.$student_id.'/'.$aagc_id.'/'.$session_id.'/'.$term_id);


    	/*Print a student's cummulative (All done terms') statement of result */
    	else if($cummulative)
    		$url = url('assessments/print-cummulative-statement/'.$student_id.'/'.$aagc_id.'/'.$session_id.'/'.$cummulative);
    	else
    		$url = "#";


    	return $url;
    }




    /*Print single student score in a given subject*/
    public static function termStudentScore($student_id,$subject_id,$aagc_id,$session_id,$term_id)
    {
    	
	    	$score = self::where([
			    		['student_id',$student_id],
			    		['subject_id',$subject_id],
			    		['aagc_id',$aagc_id],
			    		['session_id',$session_id],
			    		['term_id',$term_id]
			    	])->first([

			    		DB::raw('testScore(test1) AS test1'),
			    		DB::raw('testScore(test2) AS test2'),
			    		DB::raw('testScore(test3) AS test3'),
			    		DB::raw('examScore(exam) AS exam'),

			    	]);


	   	    
	   	    $score = self::gradeHelper($score->test1,$score->test2,$score->test3,$score->exam);



	    return $score;


    }




    
    /*Print single student score in a given subject*/
    public static function cummulativeStudentScore($student_id,$subject_id,$aagc_id,$session_id,$cummulative)
    {
    	
	    	$scores = self::where([
			    		['student_id',$student_id],
			    		['subject_id',$subject_id],
			    		['aagc_id',$aagc_id],
			    		['session_id',$session_id]
			    	])
	    			->groupBy('term_id')

	    			->get([

			    		DB::raw('SUM( testScore(test1) + testScore(test2) + testScore(test3) + examScore(exam) ) as score')
			    		]);

	    // $score = self::gradeHelper($test1,$test2,$test3,$exam);


	    return $scores;


    }








    public static function gradePoint($test1,$test2,$test3,$exam){
    	$test = ($test1 + $test2 + $test3) * 0.1 ;
        $gp = $test + ($exam * 0.7);

        return $gp;
    }



    public static function grade($gp){

    	if($gp >= 90 and $gp <= 100)
    		$grade = 'A+';

    	else if($gp >= 80 and $gp < 90)
    		$grade = 'A';

    	else if($gp >= 70 and $gp < 80)
    		$grade = 'B+';

    	else if($gp >= 60 and $gp < 70)
    		$grade = 'B';

    	else if($gp >= 50 and $gp < 60)
    		$grade = 'C';

    	else if($gp >= 40 and $gp < 50)
    		$grade = 'D';

    	else if($gp < 40 )
    		$grade = 'F';

    	else 
    		/*Not Valid*/
    		$grade = 'NI';

    	return $grade;

    }



    public static function remark($gp){
    	
    	if($gp >= 90 and $gp <= 100)
    		$remark = 'EXCELLENT';

    	else if($gp >= 80 and $gp < 90)
    		$remark = 'VERY GOOD';

    	else if($gp >= 70 and $gp < 80)
    		$remark = 'GOOD';

    	else if($gp >= 60 and $gp < 70)
    		$remark = 'FAIRLY GOOD';

    	else if($gp >= 50 and $gp < 60)
    		$remark = 'FAIR';

    	else if($gp >= 40 and $gp < 50)
    		$remark = 'POOR';

    	else if($gp < 40 )
    		$remark = 'VERY POOR';

    	else 
    		/*Not Valid*/
    		$remark = 'NI';

    	return $remark;

    }


    public static function gradeHelper($test1,$test2,$test3,$exam){
    	$gp = $test1 + $test2 + $test3 + $exam;
    	$grade = self::grade($gp);
    	$remark = self::remark($gp);

    	return [
    		'gp'=>$gp,
    		'grade'=>$grade,
    		'remark'=>$remark,
    		'scores' => array('test1'=>$test1, 'test2'=>$test2, 'test3'=> $test3, 'exam'=>$exam)
    	];
    }





}
