<?php

namespace App\Policies;
use App\Plugin\UserRole;

class Department extends UserRole
{
    
}
