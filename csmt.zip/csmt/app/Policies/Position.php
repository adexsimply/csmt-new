<?php

namespace App\Policies;
use App\Plugin\UserRole;

class Position extends UserRole
{
    
}
