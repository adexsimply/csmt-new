<?php

namespace App\Policies;
use App\Plugin\UserRole;

class Batch extends UserRole
{
    public function add_expenses(){
    	return self::user([1,2]);
    }
}
