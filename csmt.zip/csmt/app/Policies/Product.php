<?php

namespace App\Policies;
use App\Plugin\UserRole;

class Product extends UserRole
{
    
}
