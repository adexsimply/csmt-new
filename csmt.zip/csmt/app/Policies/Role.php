<?php

namespace App\Policies;
use App\Plugin\UserRole;

class Role extends UserRole
{
    
}
