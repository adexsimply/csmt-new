<?php

namespace App\Policies;
use App\Plugin\UserRole;

class Service extends UserRole
{
    public static function toggleAction(){
        
        return self::user([1]);
    }

     public function status(){
        
        return self::user([1]);
    }


    public function create(){
            
            return self::user([1,2]);
        }
}
