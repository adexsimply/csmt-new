<?php

namespace App\Policies;
use App\Plugin\UserRole;

class User extends UserRole
{
   
}
