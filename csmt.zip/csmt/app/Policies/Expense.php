<?php
namespace App\Policies;
use App\Plugin\UserRole;

class Expense extends UserRole
{
    public static function toggleAction(){
        
        return self::user([1]);
    }
}
