<?php
namespace App\Policies;
use App\Plugin\UserRole;

class Salary extends UserRole
{
    public static function toggleAction(){
        
        return self::user([1]);
    }

    public function view()
    {
        
        return self::user([1]);
    }
}


