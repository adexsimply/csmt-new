<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Parent extends Model
{
    protected $fillable = ['name','address','phone1','phone2'];


    public function students(){
    	return $this->hasMany('App\Student');
    }

    
}
