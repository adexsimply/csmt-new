<?php

namespace App\Http\Controllers;

use App\Student;
use App\Student_parent;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Exception;

class StudentController extends Controller
{
    

    public function index()
    {
        $students = Student::join('parents','parents.id','=','students.parent_id')
                            ->join('student_spies','student_spies.student_id','=','students.id')
                            ->select('students.id','students.admission_no','students.surname','students.othernames','parents.name as parent','student_spies.current_class','student_spies.arm')
                            ->paginate(1000);
        $x=1;
        return view('students.index',compact('students','x'));
    }

    



    public function create($aagc_id,$session_id)
    {

        return view('students.ajax.student-registration',compact('aagc_id','session_id'))->render();
    }



 public function createFull()
    {

        return view('students.ajax.full-student-registration')->render();
    }



    public function store(Request $request)
    {
        try{
        
            $transaction = DB::transaction(function() use($request){

                /*Collect all array data and make them variables*/
                extract($request->all());

                /*Check if parent already exist*/
            $parentDetails = DB::table('parents')
                    ->where('phone1',$phone1)
                    ->orWhere('phone1',$phone2)
                    ->orWhere('phone2',$phone1)
                    ->orWhere('phone2',$phone2)
                    ->first(['id']);

            if(count($parentDetails) > 0){
                $parent_id = $parentDetails->id;
            }
            else{

                $parent_id = DB::table('parents')->insertGetId([
                    'name' => $parent_name,
                    'phone1' => $phone1,
                    'phone2' => $phone2,
                    'address' => $parent_address
                ]);
            }



            $student = new Student;

            /*Check if admission no already exists*/
            if(Student::where('admission_no',$admission_no)->exists())
                    throw new Exception("Student ID already taken");           

            $student->surname = $surname;
            $student->othernames = $othernames;
            $student->dob = $dob;
            $student->admission_no = $admission_no;
            $student->gender = $gender;
            $student->blood_group = $blood_group;
            $student->genotype = $genotype;
            $student->health_challenges = $health_challenges;
            $student->emergency_treatment = $emergency_treatment;
            $student->immunization = $immunization;
            $student->lab_test = $lab_test;
            $student->admitted_session_id = $admitted_session_id;
            $student->parent_id = $parent_id;
            $student->state_id = $state_id;
            $student->lga_id = $lga_id;
            $student->parent_relationship = $parent_relationship;
            $student->club_id = $club_id;
            $student->house_id = $house_id;
            $student->student_category_id = $student_category_id;
            $student->status = 1;

            $student->save();


            /*Add student to class*/
            DB::table('aagc_session_student')->insert([
                'aagc_id' => $aagc_id,
                'session_id' => $admitted_session_id,
                'student_id' => $student->id
            ]);



            /*Update student details in student spy table for easy access of class detaiils*/
            $aagc_helper = DB::table('aagc_view')->where('id',$aagc_id)->first();

            DB::table('student_spies')->insert([
                'student_id' => $student->id,
                'aagc_id' => $aagc_id,
                'current_class' => $aagc_helper->class,
                'arm' => $aagc_helper->arm
            ]);



            /*Register student to all class subjects*/
            $aagc_subjects = DB::table('aagc_subject')->where('aagc_id',$aagc_id)->get(['subject_id']);
            

            $insert = array();
            foreach($aagc_subjects as $aagc_subject){
                $insert[count($insert)] = [
                    'aagc_id' => $aagc_id,
                    'session_id' => $admitted_session_id,
                    'student_id' => $student->id,
                    'subject_id' => $aagc_subject->subject_id
                ];

            }


            DB::table('aagc_subject_student')->insert($insert);

        });

        } catch(Exception $e){
            
            return response(['success'=>0,'message'=>$e->getMessage()]);
        }

        
        return response(['success'=>301,'message'=>$request->surname.' '.$request->othernames.' registered successfully!']);
        

    }

  


    public function edit($student_id)
    {
         $student = Student::where('students.id',$student_id)
                            ->join('student_spies','student_spies.student_id','=','students.id')
                            ->join('parents','parents.id','=','students.parent_id')
                            ->join('aagc','aagc.id','=','student_spies.aagc_id')
                            ->select('students.*','students.id as student_id','aagc.id as aagc_id','aagc.group_class_id','parents.*')->first();
            // dd($student);
        
        return view('students.ajax.edit',compact('student'));
    }

   


    public function update(Request $request)
    {

        // dd($request->all());
        try {

            DB::transaction(function() use($request){

                extract($request->all());

                $student = Student::find($id);
                $student->surname = $surname;
                $student->othernames = $othernames;
                $student->dob = $dob;

                /*Check if admission no already exists*/
                if(Student::where([['admission_no',$admission_no],['id','<>',$id]])->exists())
                    throw new Exception("Student ID already taken");
                    
                $student->admission_no = $admission_no;
                $student->gender = $gender;
                $student->blood_group = $blood_group;
                $student->genotype = $genotype;
                $student->health_challenges = $health_challenges;
                $student->emergency_treatment = $emergency_treatment;
                $student->immunization = $immunization;
                $student->lab_test = $lab_test;
                $student->admitted_session_id = $admitted_session_id;
                $student->state_id = $state_id;
                $student->lga_id = $lga_id;
                $student->parent_relationship = $parent_relationship;
                $student->club_id = $club_id;
                $student->house_id = $house_id;
                $student->student_category_id = $student_category_id;
                $student->parent_relationship = $parent_relationship;
                $student->status = $status;
                $student->save();


                /*Update parent details*/
                $parent = Student_parent::find($parent_id);
                $parent->name = $parent_name;
                $parent->address = $parent_address;
                $parent->phone1 = $phone1;
                $parent->phone2 = $phone2;
                $parent->save();


                /*===========Updating student class===========*/
                /*Collect current class details*/
                $current_aagc_id = DB::table('student_spies')->where('student_id',$id)->first()->aagc_id;

                /*Check if changes are made to student class*/
                if($aagc_id != $current_aagc_id){

                    /*Update student spies details*/
                    $aagc_details = DB::table('aagc_view')->where('id',$aagc_id)->first();

                    DB::table('student_spies')->where('student_id',$id)->update([
                        'aagc_id' => $aagc_id,
                        'current_class' => $aagc_details->class,
                        'arm' => $aagc_details->arm
                    ]);


                    /*Update class session student*/
                    DB::table('aagc_session_student')->where([['aagc_id',$current_aagc_id],['student_id',$id]])->update([
                        'aagc_id' => $aagc_id
                    ]);


                    /*Remove student from previously assigned subjects*/
                    DB::table('aagc_subject_student')->where([['aagc_id',$current_aagc_id],['student_id',$id]])->delete();


                    /*Collect subject in newly assigned class*/
                    $aagc_subjects = DB::table('aagc_subject')->where('aagc_id',$aagc_id)->get(['subject_id']);


                    /*Collect activated session*/
                    $active_session_id = DB::table('session_term')->where('status',1)->first();

                    if($active_session_id)
                        $active_session_id = $active_session_id->session_id;

                    else

                        throw new Exception ("No active session found, please activate a session to proceed");
                        

                    /*Array to collect subject student insertion data*/
                    $insert = [];

                    foreach ($aagc_subjects as $aagc_subject) {
                        $insert[count($insert)] = [
                            'session_id' => $active_session_id,
                            'aagc_id' => $aagc_id,
                            'subject_id' => $aagc_subject->subject_id,
                            'student_id' => $id
                        ];
                    }

                    /*Assign subject to student*/
                    DB::table('aagc_subject_student')->insert($insert);
                    
                }

            });

            
        } catch (Exception $e) {
             return response(['success'=>0,'message'=>$e->getMessage()]);
        }


        return response(['success'=>1,'message'=>'Student updated successfully','retain'=>301]);

    }



    public function show($id){
        $student = Student::with('spy')->where('id',$id)->first();

        return view('students.ajax.show',compact('student'))->render();
    }



    public function birthday(){
        $students = Student::with(['spy','state','lga','club','house','parent','category','admitted_session','graduated_session'])
                    ->whereRaw("date_format(dob,'%m %d') = date_format(curdate(),'%m %d') AND status=1")
                    ->get(['id','admission_no','surname','othernames','dob']);

        $x=1;

        return view('students.ajax.birthday',compact('students','x'))->render();
    }





    public function destroy(Request $request)
    {
        if(Student::destroy($request->id))

            return response(['success'=>1,'message'=>'Student deleted successfully','retain'=>301]);

        return response(['success'=>0,'message'=>'Connection error']);
    }


    
}
