<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Assessment;
use App\Subject;
use Illuminate\Support\Facades\DB;

class AssessmentController extends Controller
{
    
    public static function active(){
        $active = DB::table('session_term')->where('status',1)->first(['session_id','term_id']);

        return $active;
    }


	/*Collecting assessement details for upload */
    public function create($aagc_id,$session_id,$subject_id,$term_id=false){

        $term_id = $term_id ? $term_id : self::active()->term_id;

    	$students = DB::table('students')->whereRaw('

            id IN (SELECT student_id FROM aagc_subject_student WHERE aagc_id='.$aagc_id.' AND session_id='.$session_id.' AND subject_id='.$subject_id.') 

            AND id NOT IN (SELECT student_id FROM assessments WHERE aagc_id='.$aagc_id.' AND session_id='.$session_id.' AND subject_id='.$subject_id.' AND term_id='.$term_id.')')->get(['id','admission_no','surname','othernames']);


    	$x=1;
    	return view('assessments.ajax.upload',compact('students','aagc_id','session_id','subject_id','x','term_id'))->render();
    }



    /*Upload assessment*/
    public function store(Request $request){

    	try {

    		DB::transaction(function() use($request){

    			extract($request->all());

    			$scores = [];
    			$cummulative = [];



    			/*Formatting assessment data*/
    			for( $x=0; $x < count($student_id); $x++){

    				/*Prepare student exam details for insertion*/
    				$scores[$x] = [
                        'test1' => $test1[$x],
                        'test2' => $test2[$x],
                        'test3' => $test3[$x],
    					'exam' => $exam[$x],
    					'student_id' => $student_id[$x],
    					'aagc_id' => $aagc_id,
    					'session_id' => $session_id,
    					'term_id' => $term_id,
    					'subject_id' => $subject_id,
    				];


    			}


    			/*Upload assessment to database*/
    			DB::table('assessments')->insert($scores);



    		});
    		
    	} catch (Exception $e) {
    		return response(['success'=>0,'message'=>$e->getMessage()]);
    	}


    	return response(['success'=>301,'message'=>'Assessment Uploaded']);

    }




    /*Collect assessment result*/
    public function printer(Request $request){
        
        $aagc_id = $request->aagc_id;
        $subject_id = $request->subject_id;
        $session_id = $request->has('session_id') ? $request->session_id : null;
        $term_id = $request->has('term_id') ? $request->term_id : null;


        /*Use active session if session is not specified*/
        $session_id = is_null($session_id) ? self::active()->session_id : $session_id;

        /*Use active term if term is not specified*/
        $term_id = is_null($term_id) ? self::active()->term_id : $term_id;


       
 
        
        $fiddle = [
            ['aagc_id',$aagc_id],
            ['subject_id',$subject_id],
            ['session_id',$session_id],
            ['term_id',$term_id],
        ];


        $assessments = Assessment::printer($fiddle);
        $subject = Subject::find($subject_id);

        $x=1;


        return view('assessments.score-sheet',compact('assessments','session_id','term_id','aagc_id','subject','x'));
    }



    /*Print entire class assessment*/
    public function classAssessment(Request $request){

        $term_id = $request->has('term_id') ? $request->term_id : self::active()->term_id;
        $session_id = $request->has('session_id') ? $request->session_id : self::active()->session_id;
        $aagc_id = $request->aagc_id;


        $subjects = Assessment::classSubject($aagc_id,$session_id,$term_id);



        $students = Assessment::classStudent($aagc_id,$session_id,$term_id);

        // dd($subjects,$students);

        $x=1;

        /*Set cummulative to false in order to use the stupidLoading function in the view*/
        $cummulative = false;

        return view('assessments.full-score-sheet',compact('students','subjects','session_id','term_id','aagc_id','cummulative','x'));   

    }





    /*Print class assessment cummulative*/
    public function cummulative(Request $request){

        $session_id = $request->has('session_id') ? $request->session_id : self::active()->session_id;
        $aagc_id = $request->aagc_id;

        /*Collect total terms*/
        $cummulative = DB::table('assessments')->distinct('term_id')->where([['aagc_id',$aagc_id],['session_id',$session_id]])->count('term_id');

        

        $subjects = Assessment::classSubject($aagc_id,$session_id);



        $students = Assessment::classStudent($aagc_id,$session_id);

        /*Set term id to false in order to use the stupidLoading function in the view*/
        $term_id = false;
        $x=1;

        return view('assessments.full-score-sheet',compact('students','subjects','session_id','term_id','aagc_id','cummulative','x'));   

    }




    /*Print a term statement of result*/
    public function printTermStatement(Request $request){
        $student_id = $request->student_id;
        $aagc_id = $request->aagc_id;
        $session_id = $request->session_id;
        $term_id = $request->term_id;

        $subjects = Assessment::classSubject($aagc_id,$session_id,$term_id);
        $x=1;

        return view('assessments.print-term-statement',compact('subjects','student_id','aagc_id','session_id','term_id','x'));
    }



    /*Print cummulative(All terms) statement of result*/
    public function printCummulativeStatement(Request $request){
        $student_id = $request->student_id;
        $aagc_id = $request->aagc_id;
        $session_id = $request->session_id;
        $cummulative = $request->cummulative;


        /*Authenticate cummulative*/
        if($cummulative < 2)
            back()->with('error','Cummulative function is not available for a single term');

        $subjects = Assessment::classSubject($aagc_id,$session_id);
        $x=1;



        return view('assessments.print-cummulative-statement',compact('subjects','student_id','aagc_id','session_id','cummulative','x'));
    }





    public function edit($id){

        $assessment = Assessment::find($id);

        return view('assessments.ajax.edit',compact('assessment'))->render();
    }


    public function update(Request $request){
        $assessment = Assessment::find($request->id);

        if($assessment->update($request->all()))
            return response(['success'=>1,'message'=>'Update successful','retain'=>301]);

        return response(['success'=>0,'message'=>'An error occured']);
    }



    /*Remove am assess,memt*/
    public function destroy(Request $request){

        if(Assessment::destroy($request->id))

             return response(['success'=>1,'message'=>'Assessment deleted','retain'=>301]);

        return response(['success'=>0,'message'=>'Assessment unable to delete']); 

    }

}
