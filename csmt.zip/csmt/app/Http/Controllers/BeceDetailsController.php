<?php

namespace App\Http\Controllers;

use App\Bece_details;
use Illuminate\Http\Request;

class BeceDetailsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Bece_details  $bece_details
     * @return \Illuminate\Http\Response
     */
    public function show(Bece_details $bece_details)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Bece_details  $bece_details
     * @return \Illuminate\Http\Response
     */
    public function edit(Bece_details $bece_details)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Bece_details  $bece_details
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Bece_details $bece_details)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Bece_details  $bece_details
     * @return \Illuminate\Http\Response
     */
    public function destroy(Bece_details $bece_details)
    {
        //
    }
}
