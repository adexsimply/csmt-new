<?php

namespace App\Http\Controllers;

use App\User;
use App\State;
use App\Bio;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\MessageBag;
use Image;

class UserController extends Controller
{
    
   
    public function index()
    {
        if(Gate::allows('users.view')){

            $states = State::all();
            $users = DB::table('users')
                            ->join('states','users.state_id','=','states.id')
                            ->select(DB::raw('CONCAT(users.surname," ",users.first_name," ",users.middle_name) as name'),'users.email','users.phone','users.id','states.name as state')->paginate(100);
           
            return view('users.index',compact('users','states'));
        }
        else{
            return view('150');
        }
    }

    


    
    public function store(Request $request)
    {
        if($request->ajax()){

            if(Gate::allows('users.create')){

            $validated = $request->validate([
                'surname' => 'required|string',
                'first_name' => 'required|string',
                'middle_name' => 'required|string',
                'email' => 'required|E-Mail',
                'phone' => 'required|string',
                'state_id' => 'required|numeric',
            ]);


            if(User::where('email',$request->input('email'))
                    ->orWhere('phone',$request->input('phone'))
                    ->exists()){
              return response(['success'=>0,'message'=>'User email or phone number already created']);
            }

            else{
                if($user = User::create($request->all())){
                    /*Insert id into biography table*/
                    DB::table('bios')->insert(['user_id'=>$user->id]);
                    return response(['success'=>1,'message'=>$request->input('name').' created','retain'=>0]);
                }

                return response(['success'=>0,'message'=>$request->input('name').' not created']);
            }

            }

            else{
                return response('150');
            }
                        
        }
    }




    public function profile_pix(Request $request){
        if(Gate::allows('users.view')){
                $user = User::find($request->input('user_id'));

                
                if($request->hasFile('dp')){

                    $dp  = $request->file('dp');

                    /*Validate uploaded file*/
                   if(!in_array($dp->extension(), User::imageExtensions)){
                    return response(['success'=>301]);
                   }



                    $oldFile = User::viewPath.$user->image;
                    is_file($oldFile) ? unlink($oldFile) : '' ;


                    $fileName = $user->surname.'-'.$user->first_name.'-'.time();

                    /*File name should not be more than 45 letters*/
                    $fileName = strlen($fileName) > 45 ? substr($fileName, 0, 45) : $fileName;
                    $fileName.='.'.$dp->extension();

                    $a = Image::make($dp)->resize(300,300)->save(User::viewPath.'/'.$fileName);
                    if($a){
                    // if($dp->storeAs(User::uploadPath,$fileName)){
                        
                        $user->image = $fileName;
                        if($user->save()){
                            return response(['success'=>301,'message'=>'Done']);
                        }

                    } 
                    return response('Not done');
                }

                return response('no');
            }
        
        else{
                return view("150");
            }
            
    }






    public function view(Request $request)
    {
              
            if(Gate::allows('users.view')){
                $user = User::find($request->id);

                if(count($user)!==1 or count($user->bio)!==1){
                    return view('150');
                }

                $states = State::all();
                $levels = DB::table('levels')->get();
                return view('users.view',compact('user','states','levels'));
            }
            else{
                return view("150");
            }
                  
    }


    
    public function update(Request $request)
    {
        if(Gate::allows('users.update')){
            if(User::where([
                ['email','=',$request->input('name')],
                ['phone','=',$request->input('phone')],
                ['id','<>',$request->input('id')]
            ])->exists()){
                return response(['success'=>0,'message'=>'Phone number or email already exists!']);
            }
            else{
                $User = User::find($request->input('id'));
                if($User->update($request->all())){
                    return response(['success'=>1,'message'=>'User Updated!','retain'=>301]);
                }
                return response(['success'=>0,'message'=>'Database connection error']);
            }
        }
        else{
            return response('150');
        }
        

        
    }


    
    public function destroy(Request $request){
        if($request->ajax()){
            if(Gate::allows('users.delete')){

                if(User::destroy($request->id)){
                    return response(['success'=>1,'message'=>'User deleted']);
                }
                else{
                    return response(['success'=>0,'message'=>'Unable to delete']);
                }
            }
            else{
            return response('150');
              }

            
        }
        
    }






/* ======================================================================================== 
        Biography Methods
   ========================================================================================  */

      public function bio_update(Request $request)
    {
        if($request->ajax()){

            if(Gate::allows('users.update')){
                
              
                $Bio = Bio::find($request->input('id'));

                if($request->hasFile('certificate')){
                    $certificate = $request->file('certificate');

                    /*Authenticating file format*/
                    if(!in_array($certificate->extension(), Bio::fileExtensions)){
                        return response(['success'=>0,'message'=>'Invalid file format']);
                    }

                    /*Change file name*/
                    $user = User::find($Bio->user_id);
                    $fileName = $user->surname.'-'.$user->first_name.'-'.$user->id.'.'.$certificate->extension();

                    /*Delete old file*/
                    $oldFile = Bio::viewPath.$Bio->certificate;
                    is_file($oldFile) ? unlink($oldFile) : '';


                    /*Store file into file system*/
                    if($certificate->storeAs(Bio::uploadPath,$fileName)){

                        /*Convert request to array*/
                         $request = $request->all();
                         $request['certificate'] = $fileName; 
                        }

                    else{
                        return response(['success'=>0,'message'=>'Certificate upload failed']);
                    }

                }
                else{
                    /*Fetch certificate and insert into update array*/
                    $request = $request->all();
                    $request['certificate'] = $Bio->certificate; 
                }

               
                 /*Updating database*/
                    if($Bio->update($request)){
                        return response(['success'=>1,'message'=>'Update made successfully!','retain'=>301]);
                      }
                

                
                return response(['success'=>0,'message'=>'An error occured']);
               

            }

                return response('150');             
        }
    }



















}
