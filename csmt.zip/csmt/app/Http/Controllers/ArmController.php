<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ArmController extends Controller
{
    //
}
