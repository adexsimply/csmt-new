<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Subject;
use App\Subject_category as Category;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\MessageBag;

class SubjectController extends Controller
{
    public function index(){

    	/*Collecting all subjects in the subject bank*/
    	$subjects = Subject::join('subject_schools','subject_schools.id','=','subjects.subject_school_id')
    					->select('subjects.*','subject_schools.name as school')
    					->orderBy('name','ASC')
    					->paginate(100);



    	/*Collecting junior secondary school subject categories*/
        $juniorSubjects = Category::with('subjects')->where('subject_school_id',2)->get();

        /*Collecting junior secondary school subject categories*/
    	$seniorSubjects = Category::with('subjects')->where('subject_school_id',3)->get();
       

    	$x=1;
    	return view('subjects.index',compact('subjects','juniorSubjects','seniorSubjects','x'));
    }



    public function store(Request $request){
    	$request->validate([
    		'name' => 'string|required',
    		'subject_school_id' => 'string|required'
    	]);

        if(Subject::where('name',$request->name)->exists())

            return response(['success'=>0,'message'=>$request->name.' already exist!']);

        /*Insert subject into database*/
    	if(Subject::create($request->all()))

    		return response(['success'=>1,'message'=>$request->name.' created!','retain'=>301]);

        else

            return response(['success'=>0,'message'=>'Connection error!']);
    }




    public function edit($id)
    {
        $subject = Subject::find($id);
        return response(compact('subject'));
    }

    




    public function update(Request $request)
    {
        $request->validate([
            'name' => 'string|required',
    		'subject_school_id' => 'string|required'
        ]);

        $subject = Subject::find($request->id);

        if($subject->update($request->all()))

            return response(['success'=>1,'message'=>$request->name.' updated!','retain'=>301]);

        else

            return response(['success'=>0,'message'=>'Connection error!']);
    }

    




    public function destroy(Request $request)
    {
        $id = $request->id;

        $transaction = DB::transaction(function() use($id){
            DB::table('subject_category_subject')->where('subject_id',$id)->delete();
            DB::table('class_subject')->where('subject_id',$id)->delete();
            DB::table('assessments')->where('subject_id',$id)->delete();
            DB::table('cummulative_assessements')->where('subject_id',$id)->delete();
            DB::table('beces')->where('subject_id',$id)->delete();
            DB::table('waecs')->where('subject_id',$id)->delete();
            DB::table('necos')->where('subject_id',$id)->delete();
            DB::table('junior_mocks')->where('subject_id',$id)->delete();
            DB::table('senior_mocks')->where('subject_id',$id)->delete();
            Subject::destroy($id);
        });


        if(is_null($transaction))


            return response(['success'=>1,'message'=>'Subject deleted!','retain'=>301]);


        else


            return response(['success'=>0,'message'=>'Connection error!']);


    }

}
