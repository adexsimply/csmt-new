<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Neco_details extends Model
{
    //
}
