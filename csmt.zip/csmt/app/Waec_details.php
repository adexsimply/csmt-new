<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Waec_details extends Model
{
    //
}
