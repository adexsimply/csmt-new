<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Junior_mock_details extends Model
{
    //
}
