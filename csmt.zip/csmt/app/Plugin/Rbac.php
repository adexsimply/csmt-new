<?php

namespace App\Plugin;

use Illuminate\Auth\Access\HandlesAuthorization;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class Rbac
{
	use HandlesAuthorization;

    public static $model;


    /* Authenticate user permission*/
   public static function permission($permission){
    
        return DB::table('model_role_permission')
                    ->whereRaw(' model_role_id IN (SELECT id FROM model_role where role_id 

                                    IN (SELECT role_id FROM role_user WHERE user_id='.Auth::user()->id.') 

                                    AND model_id = (SELECT id FROM models WHERE name="'.self::$model.'")

                                    ) 

                                    AND permission_id = (select id from permissions where name="'.$permission.'")')
                    ->exists() ? true : false;
    }


    /*Give all permissions to super admin*/
    public static function superAdmin(){
        return DB::table('role_user')
                    ->where([['user_id',Auth::user()->id],['role_id',1]])
                    ->exists() ? true : false;
    }



    /*Check user permission*/
    public static function check($permission){

         if(self::superAdmin()){
            return true;
         }

        else if(self::permission($permission)){
            return true;
         }
       
         return false;
    }




    public function create()
    {
         return self::check('create');
    }



    public function view()
    {
        
        return self::check('view');
    }

    

    public function update()
    {
        return self::check('update');
    }


    public function delete()
    {
        return self::check('delete');
    }

     public function status()
    {
        return self::check('status');
    }

    

}
