<?php

namespace App\Plugin;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Auth\Access\HandlesAuthorization;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class UserRole
{
	use HandlesAuthorization;


    /*A global function that takes array of users role and check it against database to see if they exists*/
   static public function user($roles){

        return DB::table('role_user')
                    ->where('user_id',Auth::user()->id)
                    ->whereIn('role_id',$roles)
                    ->exists() ? true : false;
    }


    public function view()
    {
        
        return self::user([1,2]);
    }


    public function create()
    {
         return self::user([1,2]);
    }
    

    public function update()
    {
        return self::user([1,2]);
    }


    public function delete()
    {
        return self::user([1,2]);
    }

    public function super(){
            
            return self::user([1]);
        }


    public function status(){
        return self::user([1]);
    }

}
