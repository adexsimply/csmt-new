<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Senior_mock_details extends Model
{
    //
}
