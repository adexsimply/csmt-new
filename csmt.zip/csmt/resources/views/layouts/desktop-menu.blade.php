 <!--
        START - Menu side v2 
        -->
        <div class="desktop-menu menu-side-v2-w menu-activated-on-hover flying-menu">
          <ul class="main-menu">
            
            <li class="menu-sub-header">
              <span>Dashboard</span>
            </li>
            <li>
              <a href="{{url('home')}}">
                <div class="icon-w">
                  <div class="os-icon os-icon-window-content"></div>
                </div>
                <span>Go to Dashboard</span>
              </a>
              
            </li>




            <li>
              <a href="{{url('sessions')}}">
                <div class="icon-w">
                  <div class="os-icon os-icon-tasks-checked"></div>
                </div>
                <span>Sessions</span>
              </a>
            </li>


            <li class="has-sub-menu">
              <a href="#">
                <div class="icon-w">
                  <div class="os-icon os-icon-tasks-checked"></div>
                </div>
                <span>Classes</span>
              </a>
              <div class="sub-menu-w">
                <div class="sub-menu-header">
                  Classes
                </div>
                <div class="sub-menu-i">
                  <ul class="sub-menu">
                    <li>
                      <a href="{{url('classes/1')}}"> Junior Classes</a>
                    </li>
                    <li>
                      <a href="{{url('classes/2')}}"> Senior Classes </a>
                    </li>
                    <li>
                      <a href="{{url('sessions')}}"> Session setup </a>
                    </li>
                 </ul>
                </div>
              </div>
            </li>





            <li class="has-sub-menu">
              <a href="{{url('students')}}">
                <div class="icon-w">
                  <div class="os-icon os-icon-user-male-circle"></div>
                </div>
                <span>Students</span>
              </a>
              <div class="sub-menu-w">
                <div class="sub-menu-header">
                  Students
                </div>
                <div class="sub-menu-i">
                  <ul class="sub-menu">
                    <li>
                      <a href="{{url('students')}}">Student Details</a>
                    </li>
                   <!--  <li>
                      <a href="student_birthday.html">Birthdays</a>
                    </li> -->
                    <li>
                      <a href="{{url('testimonials')}}">Testimonial</a>
                    </li>

                    
                  </ul>
                </div>
              </div>
            </li>


            <li class="has-sub-menu">
              <a href="{{url('subjects')}}">
                <div class="icon-w">
                  <div class="os-icon os-icon-pencil-12"></div>
                </div>
                <span>Subject</span></a>
              <div class="sub-menu-w">
                <div class="sub-menu-header">
                  Subject
                </div>
                <div class="sub-menu-i">
                  <ul class="sub-menu">
                    <li>
                      <a href="{{url('subjects#Setup')}}">Setup </a>
                    </li>
                    <li>
                      <a href="{{url('subjects#junior-school')}}">Junior school</a>
                    </li>
                    <li>
                      <a href="{{url('subjects#senior-school')}}">Senior school</a>
                    </li>
                    <li>
                      <a href="{{url('subjects#assessment')}}">Assessments</a>
                    </li>
                    <li>
                      <a href="{{url('subjects#external')}}">External Exams</a>
                    </li>
                  </ul>
                </div>
              </div>
            </li>



            


            <li class="has-sub-menu">
              <a href="#">
                <div class="icon-w">
                  <div class="os-icon os-icon-pencil-12"></div>
                </div>
                <span>Extra</span></a>
              <div class="sub-menu-w">
                <div class="sub-menu-header">
                  Extra
                </div>
                <div class="sub-menu-i">
                  <ul class="sub-menu">
                    <li>
                      <a href="extra#nextTerm">Next term begins</a>
                    </li>
                    <li>
                      <a href="extra#house">House</a>
                    </li>
                    <li>
                      <a href="extra#club">Club</a>
                    </li>
                  </ul>
                </div>
              </div>
            </li>




            <li class="has-sub-menu">
              <a href="users.html">
                <div class="icon-w">
                  <div class="icon-people"></div>
                </div>
                <span>Users</span>
              </a>
            </li>

            
            
          </ul>
         
        </div>
        <!--
        END - Menu side v2 
        -->