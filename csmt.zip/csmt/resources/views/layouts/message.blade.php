@if(session()->has('success'))
	<div class="alert text-center alert-success">
		<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		{{session()->get('success')}}
	</div>
@endif
@if(session()->has('error'))
	<div class="alert text-center alert-danger">
		<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		{{session()->get('error')}}
	</div>
@endif