@extends('layouts.app')

@section('content')

    <div class="content-i">
            <div class="content-box">
              <div class="element-wrapper compact pt-4">
                <div class="element-wrapper">
                    
                    <h6 class="element-header">
                      Academic Record Menus
                    </h6>
                   
                    <div class="element-box">
                      <div class="os-tabs-w">
                        <div class="os-tabs-controls">
                          <ul class="nav nav-tab-sticky nav-tabs smaller">
                            <li class="nav-item active">
                              <a class="nav-link" data-toggle="tab" href="#tab_operations">Operations</a>
                            </li>
                          </ul>
                          
                        </div>
                        <div class="tab-content">








                          <div class="tab-pane active" id="tab_operations">
                            <div class="tablo-with-chart">
                              <div class="row">
                                <div class="col-sm-12 col-xxl-12">
                                  <div class="tablos">



                                    <div class="row mb-xl-2 mb-xxl-3">
                                      <div class="col-sm-4">
                                        <a class="element-box el-tablo centered trend-in-corner padded bold-label" href="continous_assestment.html">
                                          <div class="label dashboard-icons">
                                            <div class="ti-harddrives"></div>
                                          </div>
                                          <div class="value dashboard-title">
                                            Continous Assesment
                                          </div>
                                          
                                        </a>
                                      </div>
                                      <div class="col-sm-4">
                                        <a class="element-box el-tablo centered trend-in-corner padded bold-label" href="{{url('subjects#assessment')}}">
                                          <div class="label dashboard-icons">
                                            <div class="icon-book-open"></div>
                                          </div>
                                          <div class="value dashboard-title">
                                            Statement of result
                                          </div>
                                          
                                        </a>
                                      </div>
                                    
                                      <div class="col-sm-4">
                                        <a class="element-box el-tablo centered trend-in-corner padded bold-label" href="{{url('testimonials')}}">
                                          <div class="label dashboard-icons">
                                            <div class="picons-thin-icon-thin-0037_smiley_happy_like_face"></div>
                                          </div>
                                          <div class="value dashboard-title">
                                            Testimonial
                                          </div>
                                          
                                          
                                        </a>
                                      </div>
                                      
                                    </div>




                                    <div class="row mb-xl-2 mb-xxl-3">
                                      <div class="col-sm-4">
                                        <a class="element-box el-tablo centered trend-in-corner padded bold-label" href="{{url('subjects#assessment')}}">
                                          <div class="label dashboard-icons">
                                            <div class="icon-book-open"></div>
                                          </div>
                                          <div class="value dashboard-title">
                                            Academic result manager
                                          </div>
                                          
                                        </a>
                                      </div>
                                      <div class="col-sm-4">
                                        <a class="element-box el-tablo centered trend-in-corner padded bold-label" href="{{url('extra#nextTerm')}}">
                                          <div class="label dashboard-icons">
                                            <div class="os-icon os-icon-mail-19"></div>
                                          </div>
                                          <div class="value dashboard-title">
                                            Next Term Begins
                                          </div>
                                          
                                        </a>
                                      </div>
                                    
                                      <div class="col-sm-4">
                                        <a class="externalResultYear element-box el-tablo centered trend-in-corner padded bold-label" href="{{url('bece/sessions')}}">
                                          <div class="label dashboard-icons">
                                            <div class="ti-ruler-pencil"></div>
                                          </div>
                                          <div class="value dashboard-title">
                                            BECE
                                          </div>
                                          
                                          
                                        </a>
                                      </div>
                                      
                                    </div>

                                    <div class="row mb-xl-2 mb-xxl-3">
                                      <div class="col-sm-4">
                                        <a class="externalResultYear element-box el-tablo centered trend-in-corner padded bold-label" href="{{url('waec/sessions')}}">
                                          <div class="label dashboard-icons">
                                            <div class="ti-receipt"></div>
                                          </div>
                                          <div class="value dashboard-title">
                                            WAEC 
                                          </div>
                                          
                                        </a>
                                      </div>
                                      <div class="col-sm-4">
                                        <a class="externalResultYear element-box el-tablo centered trend-in-corner padded bold-label" href="{{url('neco/sessions')}}">
                                          <div class="label dashboard-icons">
                                            <div class="ti-pencil-alt"></div>
                                          </div>
                                          <div class="value dashboard-title">
                                            NECO
                                          </div>
                                          
                                        </a>
                                      </div>
                                    
                                      <div class="col-sm-4">
                                        <a class="externalResultYear element-box el-tablo centered trend-in-corner padded bold-label" href="{{url('junior-mock/sessions')}}">
                                          <div class="label dashboard-icons">
                                            <div class="ti-ruler-alt"></div>
                                          </div>
                                          <div class="value dashboard-title">
                                           JUNIOR Mock
                                          </div>
                                          
                                          
                                        </a>
                                      </div>
                                    
                                      <div class="col-sm-4">
                                        <a class="externalResultYear element-box el-tablo centered trend-in-corner padded bold-label" href="{{url('senior-mock/sessions')}}">
                                          <div class="label dashboard-icons">
                                            <div class="ti-ruler-alt"></div>
                                          </div>
                                          <div class="value dashboard-title">
                                            SENIOR Mock
                                          </div>
                                          
                                          
                                        </a>
                                      </div>
                                      
                                    </div>



                                    
                                  </div>
                                </div>
                              
                              </div>
                            </div>
                          </div>


                        </div>
                      </div>
                    </div>
                </div>
              </div>
              

              
            </div>
          </div>




@endsection


@section('script')
    <script type="text/javascript">
        $(document).ready(function(){

          $(".nav-tab-sticky").stickyTabs();


            subject_categoryOptions();



               /*Show external examination year modal*/
      $(".externalResultYear").click(function(e){
          e.preventDefault();
          var url = $(this).attr('href');

           dialog(url,'Examination Academic Session','l');

      });


        });
    </script>
@endsection
