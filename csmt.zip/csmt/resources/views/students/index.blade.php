@extends('layouts.app')

@section('content')

	<ul class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="dashboard.html">Dashboard</a>
      </li>
      <li class="breadcrumb-item">
        <span>Admission</span>
      </li>
      <li class="breadcrumb-item">
        <span>Student Registration</span>
      </li>
      </ul>
      <!--
      END - Breadcrumbs
      -->
      <div class="content-i">
      <div class="content-box">
        <div class="element-wrapper">
          
          <h3 class="element-header">
            Student's Details

            <a id="full-registration" class="btn btn-outline-primary float-right" href="{{url('students/full-registration')}}">Add New Student</a>
          </h3>


          <div class="element-box">

            @if(count($students) > 0 )
            <div class="table-responsive">
            <table id="studentTable" class="table table-striped table-bordered" style="width:100%">
              <thead>
                <tr>
                  <th>S/N</th>
                  <th>Student's ID</th>
                  <th>Name</th>
                  <th>Class</th>
                  <th>Parent's Name</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>

                @foreach($students as $student)



                <tr id="{{$student->id}}">
                  <td>{{$x}}</td>
                  <td>{{$student->admission_no}}</td>
                  <td>{{$student->surname.' '.$student->othernames}}</td>
                  <td>{{$student->current_class.' '.$student->arm}}</td>
                  <td>{{$student->parent}}</td>
                  <td>
                  
                  <a class="edit" href="{{url('students/edit/'.$student->id)}}" title="Edit student"><i class="os-icon os-icon-ui-49"></i></a>


                  <a class="text-danger delete" data-spin="yes" data-id="{{$student->id}}" href="{{url('students/destroy')}}" title="Delete">
                    <i class="os-icon os-icon-ui-15"></i>
                  </a>

                  </td>
                </tr>

                @php ($x++)
                @endforeach
                
                
              </tbody>
              
            </table>
            </div> 

            

            @else 
            <div class="text-center">
              <h3>No student found</h3>
              <a class="btn full-registration btn-outline-primary" href="{{url('students/full-registration')}}">Add New Student</a>
            </div>
            @endif
            

          </div>
        </div>
        

        
      </div>
      </div>

@endsection



@section('script')
	<script type="text/javascript">
		$(document).ready(function(){

      $("#studentTable").DataTable();
      
      if(hash = location.hash){
       
        $(hash).trigger('click');
       
      }


      
      /*Edit student details*/
      $(".edit").click(function(e){
          e.preventDefault();

          var url = $(this).attr('href');

          dialog(url,'Student Update','xl');

      });





      /*Register new student*/
      $("#full-registration").click(function(e){
          e.preventDefault();

          var url = $(this).attr('href');

          dialog(url,'Student registration','xl');
          
      });




		});
	</script>
@endsection