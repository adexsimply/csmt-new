

          <div class="element-box">

            @if(count($students) > 0 )
            <div class="table-responsive">
            
            <table id="table" class="table">
                <thead class="text-primary">
                    <tr>
                        <th>SN</th>
                        <th>Surname</th>
                        <th>Othernames</th>
                        <th>Student ID:</th>
                        <th>Birthday</th>
                        <th>Class</th>
                        <th>Arm</th>
                    </tr>
                </thead>
                <tbody>
                   @foreach($students as $student)
                      <tr>
                        <td>{{$x}}</td>
                        <td>{{$student->surname}}</td>
                        <td>{{$student->othernames}}</td>
                        <td><a class="studentDetails" href="{{url('students/show/'.$student->id)}}">{{$student->admission_no}}</a></td>
                        <td><span class="badge badge-success">{{$student->dob}}</span></td>
                        <td>{{$student->spy->current_class}}</td>
                        <td>{{$student->spy->arm}}</td>
                      </tr>

                      @php ($x++)
                   @endforeach                                            
                </tbody>
            </table>


            </div> 


          @else

            <h3>No birthday today</h3>

          @endif

            
          </div>


<script type="text/javascript">
  $(document).ready(function(){
    studentDetails();
  });

</script>
