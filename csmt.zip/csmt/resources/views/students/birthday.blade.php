@extends('layouts.app')

@section('content')

	<ul class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="dashboard.html">Dashboard</a>
      </li>
      <li class="breadcrumb-item">
        <span>Admission</span>
      </li>
      <li class="breadcrumb-item">
        <span>Student Registration</span>
      </li>
      </ul>
      <!--
      END - Breadcrumbs
      -->
      <div class="content-i">
      <div class="content-box">
        <div class="element-wrapper">
          
          <h3 class="element-header">
            Student's Details

            <a id="full-registration" class="btn btn-outline-primary float-right" href="{{url('students/full-registration')}}">Add New Student</a>
          </h3>


          <div class="element-box">

            @if(count($students) > 0 )
            <div class="table-responsive">
            
            <table id="table" class="table">
                                        <thead class="text-primary">
                                            <tr>
                                                <th><i class="fa fa-user ml-2"></i></th>
                                                <th>User</th>
                                                <th>Item</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <th><img src="images/profile.jpg" alt="profile" class="rounded-circle" width="40"
                                                        height="40" /></th>
                                                <td>Larry</td>
                                                <td>Acer</td>
                                                <td><span class="badge badge-success">Success</span></td>
                                            </tr>
                                            <tr>
                                                <th><img src="images/profile.jpg" alt="profile" class="rounded-circle" width="40"
                                                        height="40" /></th>
                                                <td>Larry</td>
                                                <td>Acer</td>
                                                <td><span class="badge badge-danger">Failed</span></td>
                                            </tr>
                                            <tr>
                                                <th><img src="images/profile.jpg" alt="profile" class="rounded-circle" width="40"
                                                        height="40" /></th>
                                                <td>Larry</td>
                                                <td>Acer</td>
                                                <td><span class="badge badge-primary">Processing</span></td>
                                            </tr>
                                            <tr>
                                                <th><img src="images/profile.jpg" alt="profile" class="rounded-circle" width="40"
                                                        height="40" /></th>
                                                <td>Larry</td>
                                                <td>Acer</td>
                                                <td><span class="badge badge-success">Success</span></td>
                                            </tr>
                                            <tr>
                                                <th><img src="images/profile.jpg" alt="profile" class="rounded-circle" width="40"
                                                        height="40" /></th>
                                                <td>Larry</td>
                                                <td>Acer</td>
                                                <td><span class="badge badge-danger">Failed</span></td>
                                            </tr>
                                        </tbody>
                                    </table>


            </div> 

            

            @else 
            <div class="text-center">
              <h3>No student found</h3>
              <a class="btn full-registration btn-outline-primary" href="{{url('students/full-registration')}}">Add New Student</a>
            </div>
            @endif
            

          </div>
        </div>
        

        
      </div>
      </div>

@endsection



@section('script')
	<script type="text/javascript">
		$(document).ready(function(){

      $("#studentTable").DataTable();
      


      /*Register new student*/
      $("#full-registration").click(function(e){
          e.preventDefault();

          var url = $(this).attr('href');

          dialog(url,'Student registration','xl');
          
      });




		});
	</script>
@endsection