    
    @if(count($students) > 0 )
    <div class="table-responsive">
                                <table class="table table-lightborder">
                                  <thead>
                                    <tr>
                                      <th>S/N</th>
                                      <th>Student's ID</th>
                                      <th>Name</th>
                                    </tr>
                                  </thead>
                                  <tbody>
 

                                @foreach($students as $student)
                                  <tr>
                                    <td>{{$x}}</td>
                                    <td>{{$student->admission_no}}</td>
                                    <td>{{$student->surname.' '.$student->othernames}}</td>
                                  </tr>
                                  @php ($x++) @endphp
                                @endforeach



                                    </tbody>
                    
                                   </table>
                                </div>
      @else
        <h3 class="text-center">No student found in selected subject</h3>
      @endif