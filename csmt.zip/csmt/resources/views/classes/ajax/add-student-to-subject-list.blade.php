    
    @if(count($students) > 0 )
    <form class="formProcessor" method="POST" action="{{url('classes/aagc/subject-student-addup')}}">

      {{@csrf_field()}}

      <div class="formAlert"></div>

      <input type="hidden" name="session_id" value="{{$session_id}}" />
      <input type="hidden" name="aagc_id" value="{{$aagc_id}}" />
      <input type="hidden" name="subject_id" value="{{$subject_id}}" />
      
    <div class="table-responsive">
            <table class="table table-lightborder">
                <thead>
                   <tr>
                      <th>S/N</th>
                      <th>Select</th>
                       <th>Student's ID</th>
                       <th>Name</th>
                    </tr>
                  </thead>
                  <tbody>
 

                                @foreach($students as $student)
                                  <tr>
                                    <td>{{$x}}</td>
                                    <td><input type="checkbox" id="{{$x}}" name="student_id[]" value="{{$student->id}}" /></td>
                                    <td><label for="{{$x}}">{{$student->admission_no}}</label></td>
                                    <td><label for="{{$x}}">{{$student->surname.' '.$student->othernames}}</label></td>
                                  </tr>
                                  @php ($x++) @endphp
                                @endforeach



                                    </tbody>
                    
                                   </table>
                                </div>

                    <button class="btn btn-success" type="submit">Add selected student(s)</button>
            </form>
      @else
        <h3 class="text-center">No student found in selected subject</h3>
      @endif