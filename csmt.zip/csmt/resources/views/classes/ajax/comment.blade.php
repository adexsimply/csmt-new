
              <div class="element-box"> 
                              @if( count($students) > 0 )
                              <form method="post" class="formProcessor" action="{{url('classes/aagc/comment')}}">

                                <div class="formAlert"></div>

                              <div class="table-responsive">
                               <table class="table table-lightborder">
                                  <thead>
                                    <tr>
                                      <th>S/N</th>
                                      <th>Student's ID</th>
                                      <th>Name</th>
                                      <th>Principal's Comment</th>
                                      <th>Teacher's Comment</th>
                                      <th>Hostel Parent's Comment</th>
                                    </tr>
                                  </thead>
                                  <tbody>

                                 <input type="hidden" name="aagc_id" value="{{$aagc_id}}" /> 
                                 <input type="hidden" name="session_id" value="{{$session_id}}" /> 

                                @foreach($students as $student)

                                  <input type="hidden" name="id[]" value="{{$student->pivot->id}}" />
                                  <input type="hidden" name="student_id[]" value="{{$student->id}}" />
                                  
                                  <input type="hidden" name="promotion_status[]" value="{{$student->pivot->promotion_status}}" />

                                  <tr>
                                    <td>{{$x}}</td>
                                    <td>{{$student->admission_no}}</td>
                                    <td>{{$student->surname.' '.$student->othernames}}</td>

                                    <td><input class="form-control" name="principal_comment[]" type="text" value="{{$student->pivot->principal_comment}}" /></td>

                                    <td><input class="form-control" name="teacher_comment[]" type="text" value="{{$student->pivot->teacher_comment}}" /></td>

                                    <td><input class="form-control" name="hostel_comment[]" type="text" value="{{$student->pivot->hostel_comment}}" /></td>
                                    


                                  </tr>
                                  @php ($x++) @endphp
                                @endforeach



                                    </tbody>
                    
                                   </table>
                                </div>

                                <button class="btn btn-primary" type="submit">Submit comment</button>

                              </form>

                              @else
                                  <h3 class="text-center text-danger"> <i class="fa fa-warning"></i> No active student found! </h3>
                              @endif
                            
                    </div>

<script type="text/javascript">
  $(document).ready(function(){
    formProcessor();
  });
</script>