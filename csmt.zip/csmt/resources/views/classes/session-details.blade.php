@extends('layouts.app')

@section('content')

	<ul class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="{{url('home')}}">Dashboard</a>
            </li>
            <li class="breadcrumb-item">
              <a href="{{url('classes')}}">All classes</a>
            </li>
            <li class="breadcrumb-item">
              <a href="{{url('classes/'.$group_id)}}">{{App\Group::name($group_id)}} classes</a>
            </li>
            <li class="breadcrumb-item">
              <span>{{$name}} Class students</span>
            </li>
          </ul>
          <!--
          END - Breadcrumbs
          -->
          <div class="content-i">
            <div class="content-box">
              <div class="element-wrapper compact pt-4">
                <div class="element-wrapper">
                    

                    <h4 class="element-header clearfix">
                      {{$name}}
                      <div class="float-right btn-group">

                        <a class="studentRegistration btn btn-success" href="{{url('students/create/'.$aagc_id.'/'.$session_id)}}"> <i class="fa fa-user-circle"></i> Add new student</a>

                        <a href="#" data-session_id="{{$session_id}}" data-aagc_id="{{$aagc->id}}" class="btn addNewSubject btn-success"><i class="fa fa-book"></i> Add new subject</a>


                      </div>
                      
                    </h4>

                    

                    <div class="element-box">
                      <div class="os-tabs-w">
                        <div class="os-tabs-controls">



                          <ul class="nav nav-tabs nav-tabs-sticky smaller">
                            <li class="nav-item">
                              <a class="nav-link active" data-toggle="tab" href="#students"><i class="fa fa-users"></i> Class students</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" data-toggle="tab" href="#subjects"> <i class="fa fa-cog"></i> Class subject setup</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" data-toggle="tab" href="#comments"><i class="fa fa-comments"></i> Comments</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" href="{{url('assessments/class-assessment-printer/'.$aagc_id.'/'.$session_id.'/'.$term_id)}}"><i class="fa fa-pie-chart"></i> Assessments</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link promotionToggle" data-toggle="tab" href="#promotion"><i class="fa fa-arrow-circle-right"></i> Promotion</a>
                            </li>
                          </ul>
                          
                        </div>
                        <div class="tab-content">
                          



                          <!-- Class arm students -->
                          <div class="tab-pane active" id="students">
                                @if(count($students) > 0 )

                            <div class="element-box">

                              <h3>Class students</h3>
                               <hr>

                              <div class="table-responsive">
                               <table class="table table-lightborder">
                                  <thead>
                                    <tr>
                                      <th>S/N</th>
                                      <th>Student's ID</th>
                                      <th>Name</th>
                                      <th>Parent's Name</th>
                                      <th>Actions</th>
                                    </tr>
                                  </thead>
                                  <tbody>


                                @foreach($students as $student)
                                  <tr>
                                    <td>{{$x}}</td>
                                    <td>{{$student->admission_no}}</td>
                                    <td>{{$student->surname.' '.$student->othernames}}</td>
                                    <td>{{$student->parent_name}}</td>
                                    <td>
                                     <a class="edit" href="{{url('students/edit/'.$student->id)}}" title="Edit student"><i class="os-icon os-icon-ui-49"></i></a>

                                    <!-- <a class="text-danger" href="#" title="Delete">
                                      <i class="os-icon os-icon-ui-15"></i>
                                    </a> -->

                                    </td>
                                  </tr>
                                  @php ($x++) @endphp
                                @endforeach



                                    </tbody>
                    
                                   </table>
                                </div>
                            </div>

                          @else

                            <div class="text-center">
                              <h3> No student found! </h3>
                              <a class="studentRegistration btn btn-success" href="{{url('students/create/'.$aagc_id.'/'.$session_id)}}"> <i class="fa fa-user-circle"></i> Add new student</a>
                            </div>
                          @endif
                          </div>





                          <!-- Class arm students comment-->
                          <div class="tab-pane" id="comments">
                                @if(count($students) > 0 )

                            <div class="element-box">

                              <h3 class="element-header clearfix">Comments
                                  <a href="{{url('classes/aagc/comment/'.$aagc_id.'/'.$session_id)}}" class="float-right btn btn-primary makeComment">
                                    <i class="fa fa-comments"></i> Add comments</a>
                              </h3>
                              

                              <div class="table-responsive">
                               <table class="table table-lightborder">
                                  <thead>
                                    <tr>
                                      <th>S/N</th>
                                      <th>Student's ID</th>
                                      <th>Name</th>
                                      <th>Principal's Comment</th>
                                      <th>Teacher's Comment</th>
                                      <th>Hostel Parent's Comment</th>
                                    </tr>
                                  </thead>
                                  <tbody>


                                @foreach($students as $student)
                                  <tr>
                                    <td>{{$x}}</td>
                                    <td>{{$student->admission_no}}</td>
                                    <td>{{$student->surname.' '.$student->othernames}}</td>
                                    <td>{{$student->pivot->principal_comment}}</td>
                                    <td>{{$student->pivot->teacher_comment}}</td>
                                    <td>{{$student->pivot->hostel_comment}}</td>
                                  </tr>
                                  @php ($x++) @endphp
                                @endforeach



                                    </tbody>
                    
                                   </table>
                                </div>
                            



                            </div>

                          @else

                            <div class="text-center">
                              <h3> No student found! </h3>
                              <a class="studentRegistration btn btn-success" href="{{url('students/create/'.$aagc_id.'/'.$session_id)}}"> <i class="fa fa-user-circle"></i> Add new student</a>
                            </div>
                          @endif
                          </div>







                          <!-- Class arm students comment-->
                          <div class="tab-pane" id="promotion"></div>





                          <!-- Class subjects -->
                          <div class="tab-pane" id="subjects">
                            @if(count($subjects) > 0)

                              <div class="table-responsive">
                                        <table class="table table-lightborder">
                                          <thead>
                                            <tr>
                                              <th>
                                                S/N
                                              </th>
                                              <th>
                                                Subject Name
                                              </th>
                                              <th>
                                                Date Added
                                              </th>
                                              <th class="text-center">
                                                Action
                                              </th>
                                            </tr>
                                          </thead>
                                          <tbody>

                                          @php $x=1; @endphp
                                          @foreach($subjects as $subject)
                                            <tr id="{{$subject->pivot->id}}">
                                                <td>{{$x}}</td>

                                                <td>{{$subject->name}}</td>

                                                <td>{{Carbon\Carbon::parse($subject->created_at)->format('Y-m-d')}}</td>

                                                <td class="row-actions">
                                                    <a class="viewSubjectStudents" href="{{url('classes/aagc/subject-student/view/'.$aagc_id.'/'.$session_id.'/'.$subject->id)}}" data-toggle="tooltip" title="View students" > 

                                                      <i class="fa fa-users"></i> </a>

                                                    <a class="addNewStudents" data-toggle="tooltip" title="Add student" href="{{url('classes/aagc/subject-student/getnew/'.$aagc_id.'/'.$session_id.'/'.$subject->id)}}"> <i class="fa fa-user-plus"></i> </a>

                                                     <a class="uploadAssessment" data-toggle="tooltip" title="Add new assessments" href="{{url('assessments/create/'.$aagc_id.'/'.$session_id.'/'.$subject->id)}}"> <i class="fa fa-pie-chart"></i> </a>

                                                     <a class="showAssessment" data-toggle="tooltip" title="View assessments" href="{{url('assessments/printer/'.$subject->id.'/'.$aagc_id.'/'.$session_id)}}"> <i class="fa fa-pie-chart"></i> </a>

                                                    <a data-toggle="tooltip" title="Remote subject from class" data-id="{{$subject->pivot->id}}" class="text-danger delete" href="{{url('classes/aagc/subject/destroy')}}" title="Delete">
                                                      <i class="os-icon os-icon-ui-15"></i>
                                                    </a>
                                                </td>
                                              </tr>
                                              @php ($x++) @endphp
                                          @endforeach

                                          </tbody>
                                        </table>
                                      </div>  

                                                 

                            @else




                              <!-- Setup class subjects -->
                              <div class="element-box">

                                @php
                                  $subjects = App\Subject::where('subject_school_id',($group_id + 1))->orWhere('subject_school_id',1)->get();
                                @endphp

                                  
                                   @if(count($subjects) > 0)

                                    <form class="mt-4 formProcessor" method="POST" action="{{url('classes/aagc/subject-setup')}}">

                                      {{@csrf_field()}}

                                      <div class="formAlert"></div>
                                      <input type="hidden" name="aagc_id" value="{{$aagc->id}}">
                                      <input type="hidden" name="session_id" value="{{$session_id}}">

                                       <div class="table-responsive">
                                        <table class="table table-lightborder">
                                          <thead>
                                            <tr>
                                              <th>
                                                Action
                                              </th>
                                              <th>
                                                Subject Name
                                              </th>
                                              <th class="text-center">
                                                Date Added
                                              </th>
                                              
                                            </tr>
                                          </thead>
                                          <tbody>

                                          @foreach($subjects as $subject)
                                            <tr>
                                                <td>
                                                  
                                                  <div class="form-check">
                                                    <input type="checkbox" checked="" value="{{$subject->id}}" name="subject_ids[]" class="form-check-input" id="{{$subject->id}}" />
                                                  </div>

                                                </td>

                                                <td><label for="{{$subject->id}}" style="cursor:pointer;">{{$subject->name}}</label></td>


                                                <td class="text-center">{{Carbon\Carbon::parse($subject->created_at)->format('Y-m-d')}}</td>

                                              </tr>
                                              
                                          @endforeach

                                          </tbody>
                                        </table>

                                        
                                      </div> 
                             <div class="form-buttons-w">
                              <button class="btn btn-primary" type="submit"> Save subjects</button>
                            </div>
                       </form>

                        @else
                          <div class="alert alert-danger text-center">
                              <h1>No subject found</h1>
                              <a href="{{url('subjects')}}">Create new subject</a>
                          </div>
                        @endif








                              </div>
                              

                            @endif
                          </div>



                        </div>

                      </div>
                    </div>

                    
                </div>
              </div>
              

              
            </div>
          </div>

@endsection




@section('modal')
  

  
  <!-- Create new subject modal -->
  <div class="modal fade" id="addNewSubject">
    <div class="modal-dialog modal-sm mx-auto">
      <div class="modal-content">

        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-name">Add new subject</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>

        <!-- Modal body -->
        <div class="modal-body">
          <form class="formProcessor" method="POST" action="{{url('classes/aagc/subjects/addnew')}}">
           

            <div class="formAlert"></div>
            

          <input type="hidden" name="aagc_id" id="aagc_id">
          <input type="hidden" name="session_id" id="session_id">

          <div class="form-group">
              <label for=""> Subject school</label>
              <select required="" class="subjectOptions form-control" required name='subject_id'></select>
          </div>

          <button class="btn btn-primary" type="submit"> Add Subject</button>

             </form>
        </div>

      </div>
    </div>
  </div>







@endsection





@section('script')
  <script type="text/javascript">
    $(document).ready(function(){

      $('.nav-tabs-sticky').stickyTabs();

      function fetchPromotionList(){
         $('#promotion').html('<p class="text-center"> <i class="fa fa-spinner fa-spin fa-5x"></i> </p>');


        $.get('{{url("classes/aagc/promotion/".$aagc_id."/".$session_id."/".$term_id)}}',function(data){
            $("#promotion").html(data);
        });
        
      }

      var promotion = false;

      /*Collect Promotion details*/
      $(".promotionToggle").click(function(){

          fetchPromotionList();
          promotion = true;
      });

      if(!promotion){
        var hash = location.hash;

        if(hash == '#promotion'){
          fetchPromotionList();
        }
      }
      


      /*Pricipal, Teacher and hostel parent comment*/
      $(".makeComment").click(function(e){
          e.preventDefault();
          var url = $(this).attr('href');

          dialog(url,'Make comments','xl');
      });

      /*Upload assessments*/
      $(".uploadAssessment").click(function(e){
          e.preventDefault();

          var url = $(this).attr('href');

          uploadAssessment(url);
    }); 
      


       /*Edit student details*/
      $(".edit").click(function(e){
          e.preventDefault();

          var url = $(this).attr('href');

          dialog(url,'Student Update','xl');

      });


      /*Register new student*/
      $(".studentRegistration").click(function(e){
          e.preventDefault();

          var url = $(this).attr('href');

          dialog(url,'Student registration','xl');
      });


      /*Add new students to class*/
      $('.addNewStudents').click(function(e){
          e.preventDefault();

          var url = $(this).attr('href');

          dialog(url,'Class student list','l');

      });





      /*View subject students*/
      $('.viewSubjectStudents').click(function(e){
          e.preventDefault();

          var url = $(this).attr('href');

          dialog(url,'Student offering this subject','xl');
 



      });


      /*Add new subjects*/
      $(".addNewSubject").click(function(e){
          e.preventDefault();
          subjectOptions();
          var aagc_id = $(this).data('aagc_id');
          var session_id = $(this).data('session_id');
          $('#aagc_id').val(aagc_id);
          $('#session_id').val(session_id);

          $("#addNewSubject").modal('show');
      });

    });
  </script>
@endsection

