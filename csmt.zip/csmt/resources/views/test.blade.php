<?php
    use App\Group_class;
    use App\Aagc;
    use App\User;
    use App\Student;
    use App\Plugin\Addons;
    use Illuminate\SUpport\Facades\DB;

     $student = Student::with('category')->where('id',8)->first();
    

    	dd($student);
    
    
 ?>
