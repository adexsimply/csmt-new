@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 top-50 center-block">
            <h1 class="text-center"><i class="fa fa-warning"></i> Access Denied</h1>
        </div>
    </div>
</div>
@endsection
