@extends('layouts.app')

@section('content')

  <ul class="breadcrumb">
             <li class="breadcrumb-item">
              <a href="{{url('home')}}">Dashboard</a>
            </li>
            <li class="breadcrumb-item">
              <a href="{{url('classes')}}">All classes</a>
            </li>
          </ul>
          <!--------------------
          END - Breadcrumbs
          -------------------->
          <div class="content-i">
            <div class="content-box">
                <div class="element-wrapper">
                    
                    <h3 class="element-header">
                      {!! App\Aagc::name($aagc_id) !!} 

                      @php
                          if($cummulative)
                            echo 'Cummulative result';

                          else if($term_id)
                            echo App\Term::find($term_id)->name.' result';

                       @endphp

                      <div class="btn-group float-right">  

                        <a href="#" class="moreOption btn btn-primary"><i class="fa fa-search"></i>  </a>

                        <a href="{{url('assessments/cummulative/'.$aagc_id.'/'.$session_id)}}" class="btn btn-primary"><i class="fa fa-bar-chart"></i> Cummulative </a>

                        


                      
                      </div>
                      

                    </h3>



                    

                    <div class="element-box ">


                     
                     @if( count($students) > 0 )

                     <div class="table-responsive">
                      
                        <table id="table" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>S/N</th>
                                    <th>Print</th>
                                    <th>Students' ID</th>
                                    <th>Name</th>
                                    @foreach( $subjects as $subject)
                                      <th>{{$subject->name}}</th>
                                    @endforeach
                                    <th>Total</th>
                                    <th>Print</th>
                                </tr>
                            </thead>
                            <tbody>

                              @foreach($students as $student)
                                <tr>
                                  <td>{{$x}}</td>
                                  <td class="text-center">
                                      <a target="_blank" href="{{App\Assessment::printUrl($student->id,$aagc_id,$session_id,$term_id,$cummulative)}}"><i class="fa fa-print"></i></a>
                                    
                                  </td>
                                  <td>{{$student->admission_no}}</td>
                                  <td>{{$student->surname.' '.$student->othernames}}</td>

                                  @php $total=0 @endphp

                                  @foreach($subjects as $subject)
                                    <td>

                                      @php
                                        $score =  App\Assessment::stupidLoading($subject->id,$student->id,$aagc_id,$session_id,$term_id,$cummulative);

                                        $total+=$score;
                                      @endphp

                                      {{$score}}

                                    </td>
                                  @endforeach

                                  <td>{{$total}}</td>
                                  <td>
                                      <a href="#"><i class="fa fa-print"></i></a>
                                    
                                  </td>
                                </tr>

                                @php ($x++)
                              @endforeach
                                
                            </tbody>
                              

                        </table>

                      </div>

                      @else 
                        <h3 class="text-center">No assessment found!</h3>
                      @endif
                    </div>
                </div>
              

              
            </div>
          </div>

@endsection


@section('modal')
  <!-- Create new subject modal -->
  <div class="modal fade" id="moreOption">
    <div class="modal-dialog modal-md ">
      <div class="modal-content">

        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-name">Fetch assessment</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>

        <!-- Modal body -->
        <div class="modal-body">
          <form method="get" action="{{url('assessments/class-assessment-printer')}}">

                        

                      

                        
                        <div class="form-group">
                          <select class="form-control classOptions"></select>
                        </div>

                        
                        <div class="form-group">
                          <select class="form-control fullArmOptions" required="" name="aagc_id"></select>
                        </div>
                        
                        <div class="form-group">
                          <select class="form-control sessionOptions" required="" name="session_id"></select>
                        </div>

                        <div class="form-group">
                          <select class="form-control termOptions" required="" name="term_id"></select>
                        </div>

                        <div class="form-group">
                          <button class="btn btn-primary" type="submit">View Result</button>

                          
                        </div>

                      


                      </form>
        </div>

      </div>
    </div>
  </div>
@endsection


<?php

    $group_class_id = App\Aagc::find($aagc_id)->group_class->id;

?>


@section('script')
  

  <script type="text/javascript">
    $(document).ready(function(){

        $("#table").DataTable();




      $(".moreOption").click(function(e){
        e.preventDefault();
        sessionOptions('{{$session_id}}');
        termOptions('{{$term_id}}');
        classOptions('{{$group_class_id}}');
        fullArmOptions('{{$group_class_id}}','{{$aagc_id}}');


        $(".classOptions").change(function(){
          var group_class_id = $(this).val();
          fullArmOptions(group_class_id);
        });
  

        $("#moreOption").modal('show');
      });

    });
  </script>
@endsection




