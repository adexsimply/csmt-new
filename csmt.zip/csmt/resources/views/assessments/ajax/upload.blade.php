<div class="element-box">

@if(count($students) > 0 )
	<form action="{{url('assessments/store')}}" class="formProcessor" method="post" class="f-16">

		{{@csrf_field()}}

		<div class="formAlert"></div>


		<div class="row">

			<div class="col-md-6">
				<div class="form-group">
					<label>Session</label>
					<select name="session_id" required="" class="form-control sessionOptions"></select>
				</div>
			</div>


			<div class="col-md-6">
				<div class="form-group">
					<label>Term</label>
					<select name="term_id" required="" class="form-control termOptions"></select>
				</div>
			</div>


			<input type="hidden" name="aagc_id" value="{{$aagc_id}}">
			<input type="hidden" name="subject_id" value="{{$subject_id}}">

		</div>
		<div class="table-responsive">
            <table class="table table-lightborder">
                <thead>
                   <tr>
                      <th>S/N</th>
                      <th>Student name</th>
                       <th>Student's ID</th>
                       <th>First test</th>
                       <th>Second test</th>
                       <th>Third test</th>
                       <th>Exam</th>
                    </tr>
                </thead>
                <tbody>
 

                @foreach($students as $student)
                    <tr>
                        <td>{{$x}}</td>
                        <td><a class="studentDetails" href="{{url('students/show/'.$student->id)}}">{{$student->admission_no}}</a></td>
                        <td>{{$student->surname.' '.$student->othernames}}</td>
                        <td>
                            <input type="hidden" name="student_id[]" value="{{$student->id}}">
                            <input type="number" min="0" max="100" name="test1[]" required="" class="form-control" />
                        </td>
                                    
                        <td> <input type="number" min="0" max="100" name="test2[]" required="" class="form-control" /></td>
                                    
                        <td> <input type="number" min="0" max="100" name="test3[]" required="" class="form-control" /></td>
                                    
                        <td> <input type="number" min="0" max="100" name="exam[]" required="" class="form-control" /> </td>
                                    
                        </tr>
                    @php ($x++) @endphp
                @endforeach



                </tbody>
                    
           	</table>
        </div>



		<div class="row">
			<div class="col-md-12">
				<button type="submit" class="btn btn-primary btn-md">Register</button>
				<button type="reset" class="btn btn-sceondary btn-md">Clear fields</button>
			</div>
		</div>


	</form>

@else
	<h3 class="text-center">All students' assessments have been uploaded </h3>
@endif
					  

</div>


<script type="text/javascript">
	
	termOptions('{{$term_id}}');
	sessionOptions('{{$session_id}}');
	studentDetails();


	formProcessor();

</script>