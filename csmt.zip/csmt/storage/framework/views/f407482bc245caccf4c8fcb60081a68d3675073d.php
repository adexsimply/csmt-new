<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name')); ?></title>

    <!-- Styles -->
    <!-- <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/special.css')); ?>" rel="stylesheet"> -->
    <link href="<?php echo e(asset('fa/css/font-awesome.css')); ?>" rel="stylesheet">

    <link href="favicon.png" rel="shortcut icon">
    <link href="apple-touch-icon.png" rel="apple-touch-icon">
    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('bower_components/select2/dist/css/select2.min.css')); ?>" rel="stylesheet" >
    <link href="<?php echo e(asset('bower_components/bootstrap-daterangepicker/daterangepicker.css')); ?>" rel="stylesheet" >
    <link href="<?php echo e(asset('bower_components/dropzone/dist/dropzone.css')); ?>" rel="stylesheet" >
    <link href="<?php echo e(asset('bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet" >

    <link href="<?php echo e(asset('bower_components/bootstrap/dist/css/bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('bower_components/perfect-scrollbar/css/perfect-scrollbar.min.css')); ?>" rel="stylesheet" >
    <link href="<?php echo e(asset('bower_components/slick-carousel/slick/slick.css')); ?>" rel="stylesheet" >
    <link href="<?php echo e(asset('icon_fonts_assets/simple-line-icons/css/simple-line-icons.css')); ?>" rel="stylesheet" >
    <link href="<?php echo e(asset('icon_fonts_assets/themefy/themify-icons.css')); ?>" rel="stylesheet" >
    <link href="<?php echo e(asset('icon_fonts_assets/picons-thin/style.css')); ?>" rel="stylesheet" >
    <link href="<?php echo e(asset('css/main.css')); ?>" rel="stylesheet" >
    <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/jquery-confirm.css')); ?>" rel="stylesheet">
</head>
<body>
    <div class="all-wrapper menu-side menu-top solid-bg-all">

        <?php echo $__env->make('layouts.top-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="layout-w">
            <?php echo $__env->make('layouts.mobile-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('layouts.desktop-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    		<div class="content-w">

    		  <?php echo $__env->make('layouts.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    		  <?php echo $__env->yieldContent('content'); ?>

            </div>


		</div>
        <div class="display-type"></div>
    </div>




    <?php echo $__env->yieldContent('modal'); ?>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/jquery/dist/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/popper.js/dist/umd/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/moment/moment.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/chart.js/dist/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/select2/dist/js/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/jquery-bar-rating/dist/jquery.barrating.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/ckeditor/ckeditor.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/bootstrap-validator/dist/validator.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/ion.rangeSlider/js/ion.rangeSlider.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/dropzone/dist/dropzone.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/editable-table/mindmup-editabletable.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/perfect-scrollbar/js/perfect-scrollbar.jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/tether/dist/js/tether.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/slick-carousel/slick/slick.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/bootstrap/js/dist/util.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/bootstrap/js/dist/alert.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/bootstrap/js/dist/button.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/bootstrap/js/dist/carousel.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/bootstrap/js/dist/collapse.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/bootstrap/js/dist/dropdown.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/bootstrap/js/dist/modal.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/bootstrap/js/dist/tab.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/bootstrap/js/dist/tooltip.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/bootstrap/js/dist/popover.js')); ?>"></script>
    <script src="<?php echo e(asset('js/sticky-tabs.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery-confirm.js')); ?>"></script>
    <script src="<?php echo e(asset('js/main.js?version=4.2.0')); ?>"></script>
    <script>
      (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
      m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
      })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
      
      ga('create', 'UA-XXXXXXXX-9', 'auto');
      ga('send', 'pageview');
    </script>




    <?php echo $__env->make('layouts.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
    <?php echo $__env->make('layouts.select', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
    <?php echo $__env->yieldContent('script'); ?>
    
	
</body>
</html>