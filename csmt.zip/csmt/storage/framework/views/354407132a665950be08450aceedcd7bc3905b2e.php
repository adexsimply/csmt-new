<?php $__env->startSection('content'); ?>

	<ul class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="dashboard.html">Dashboard</a>
      </li>
      <li class="breadcrumb-item">
        <span>Admission</span>
      </li>
      <li class="breadcrumb-item">
        <span>Student Registration</span>
      </li>
      </ul>
      <!--
      END - Breadcrumbs
      -->
      <div class="content-i">
      <div class="content-box">
        <div class="element-wrapper">
          
          <h3 class="element-header">
            Student's Details

            <a id="full-registration" class="btn btn-outline-primary float-right" href="<?php echo e(url('students/full-registration')); ?>">Add New Student</a>
          </h3>


          <div class="element-box">

            <?php if(count($students) > 0 ): ?>
            <div class="table-responsive">
            <table id="studentTable" class="table table-striped table-bordered" style="width:100%">
              <thead>
                <tr>
                  <th>S/N</th>
                  <th>Student's ID</th>
                  <th>Name</th>
                  <th>Class</th>
                  <th>Parent's Name</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>

                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



                <tr id="<?php echo e($student->id); ?>">
                  <td><?php echo e($x); ?></td>
                  <td><?php echo e($student->admission_no); ?></td>
                  <td><?php echo e($student->surname.' '.$student->othernames); ?></td>
                  <td><?php echo e($student->current_class.' '.$student->arm); ?></td>
                  <td><?php echo e($student->parent); ?></td>
                  <td>
                  
                  <a class="edit" href="<?php echo e(url('students/edit/'.$student->id)); ?>" title="Edit student"><i class="os-icon os-icon-ui-49"></i></a>


                  <a class="text-danger delete" data-spin="yes" data-id="<?php echo e($student->id); ?>" href="<?php echo e(url('students/destroy')); ?>" title="Delete">
                    <i class="os-icon os-icon-ui-15"></i>
                  </a>

                  </td>
                </tr>

                <?php ($x++); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                
              </tbody>
              
            </table>
            </div> 

            

            <?php else: ?> 
            <div class="text-center">
              <h3>No student found</h3>
              <a class="btn full-registration btn-outline-primary" href="<?php echo e(url('students/full-registration')); ?>">Add New Student</a>
            </div>
            <?php endif; ?>
            

          </div>
        </div>
        

        
      </div>
      </div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('script'); ?>
	<script type="text/javascript">
		$(document).ready(function(){

      $("#studentTable").DataTable();
      
      if(hash = location.hash){
       
        $(hash).trigger('click');
       
      }


      
      /*Edit student details*/
      $(".edit").click(function(e){
          e.preventDefault();

          var url = $(this).attr('href');

          dialog(url,'Student Update','xl');

      });





      /*Register new student*/
      $("#full-registration").click(function(e){
          e.preventDefault();

          var url = $(this).attr('href');

          dialog(url,'Student registration','xl');
          
      });




		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>