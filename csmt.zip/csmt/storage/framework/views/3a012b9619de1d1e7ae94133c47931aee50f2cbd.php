
<script type="text/javascript">
$(document).ready(function(){
	
	$('[data-toggle="tooltip"]').tooltip();
	String.prototype.nl2br = function(){ return this.replace(/\n/g, "<br />"); }
	
/*Ajax csrf token declaration*/
	$.ajaxSetup({
		headers: {
			'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
		},
	});
	

	/*Open link in new tab*/

	window.newTab = function(url){
		return window.open(url,'_blank');
	}

/*Dialog box for ajax pop up processing*/
	window.dialog = function(url,title='Operation',size='m'){
		
		$.dialog({
              content: function () {
                  var self = this;
                  return $.ajax({
                      url: url,
                      method: 'get',
                  }).done(function (data) {
                      self.setContent(data);
                      self.setTitle(title);
                  }).fail(function(){
                      self.setContent('Something went wrong');
                  });
              },
              columnClass: size,
          });

	}



	
/*Table rows to link*/
	$(".rowLink").click(function(){
		window.location=$(this).data('url');
	});

	
/*Prevent default action*/
	$(".preventDefault").click(function(e){
		e.preventDefault();
	});


	window.numberFormat=function(x){
		return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
	}



window.monthOptions = function(month=null){

		var monthOptions="";
		var months = new Array('January','February','March','April','May','June','July','August','September','October','November','December');

		for (x = 0; x < 12; x++){
			if((month-1) == x)
				monthOptions+="<option selected value='"+(x+1)+"'>"+months[x]+"</option>";
			else
				monthOptions+="<option value='"+(x+1)+"'>"+months[x]+"</option>";
		}

		$(".monthOptions").html(monthOptions);

	}




window.yearOptions = function(year=null){

		var yearOptions="";
		var dt = new Date();
		var currentYear = dt.getFullYear() + 1;
		var yearOptions = "<option value=''>Select year</option>";

		for( ; currentYear >= 1970; currentYear-- ){
				if(currentYear == year)
					yearOptions+="<option selected value="+currentYear+">"+currentYear+"</option>";

				else
					yearOptions+="<option value="+currentYear+">"+currentYear+"</option>";
			}

		$(".yearOptions").html(yearOptions);

	}




/*Fetch states*/
	window.stateOptions = function(){

		var that = $(".stateOptions");

		that.html("<option>Collecting states......</option>");
		$.get('<?php echo e(url("fetch-state")); ?>',function(data){
			// console.log(data);
			var stateOptions = "<option>Select a state</option>";
			$.each(data.states,function(i,value){
				stateOptions+="<option value='"+value.id+"'>"+value.name+"</option>";
			});


			that.html(stateOptions);

		});

	}



	window.departmentOptions = function(user_id=0){
		var that = $(".departmentOptions");
		that.html("<option>Collecting departments......</option>");
		$.get('<?php echo e(url("fetch-department")); ?>',{user_id:user_id},function(data){
			console.log(data);
			var departments='';
			var data = data.departments;
			$.each(data,function(i,value){
				departments+="<option value='"+value.id+"'>"+value.name+"</option>";
			});

			 that.html(departments);
		});
		
	}

	


	window.bankOptions = function(){
		var that = $(".bankOptions");
		that.html("<option>Collecting banks......</option>");
		$.get('<?php echo e(url("fetch-bank")); ?>',function(data){
			console.log(data);
			var banks='';
			var data = data.banks;
			$.each(data,function(i,value){
				banks+="<option value='"+value.id+"'>"+value.name+"</option>";
			});

			 that.html(banks);
		});
		
	}

	


/*Ajax fetch lgas*/
	$(".stateOptions").change(function(){
		var id = $(this).val();
		var that = $(".lgaOptions");
		that.html("<option>Collecting local governments......</option>");
		$.get('<?php echo e(url("fetch-lga")); ?>',{state_id:id},function(data){
			var lgas='';
			var data = data.lgas;
			$.each(data,function(i,value){
				lgas+="<option value='"+value.id+"'>"+value.name+"</option>";
			});

			 that.html(lgas);

		});
	});
	
	
	
/*Change table status*/
	$(document).on('click','.statusToggle',function(e){
		e.preventDefault();
		var that = $(this);
		var id = that.data('id');
		var url = that.attr('href');

		$.confirm({
			title:'Change status',
			type:'red',
			icon:'fa fa-warning',
			content:'Are you sure ?',
			buttons:{
				Yes : function(){
					$.post(url,{id:id},function(data){
						console.log(data);
						if(data.success===1){
							// alert('Status Changed!');
							location.reload();
						}
						else if(data==150){
							window.location="<?php echo e(url('150')); ?>";
						}
						else{
							alert(data.message);
						}
					});
				},

				No : function(){}

			}
		});
		
	});
	
	
	
	
	
	
/*Delete data*/
	$(document).on('click','.delete',function(e){
		e.preventDefault();
		var that = $(this);
		var id = that.data('id');
		var url = that.attr('href');
		var spin = that.data('spin');




		$.confirm({
			content : 'This operation is irreversible <br> Sure to delete ? ',
			type : 'orange',
			escapeKey: true,
			backgroundDismiss: true,
			title : 'Delete permanently',
			icon:'fa fa-warning',
			buttons: {
				Yes : function (){

					if(spin=='yes')
						that.html('<i class="fa fa-spinner fa-spin"></i>');

					$.post(url,{id:id},function(data){
						console.log(data);
						if(data==150 || data=="150"){
							window.location="<?php echo e(url('150')); ?>";
						}
						else{
							if(data.success===1){

								$("#"+id).hide(1000);

									$.confirm({
										content:data.message+'<br> Would you like to reload this page to see the latest data?',
										type:'green',
										escapeKey: true,
										title : 'Delete status',
										backgroundDismiss: true,
										buttons:{
											Yes : function(){
												location.reload();
											},

											No : function(){}

										}
									});

								}
							else{

									console.log(data);
									alert(data.message);

								}


						}
						
					});
				},

				No : function(){}

			}

		});

		
		
	});
	
	
	
	
	window.formProcessor = function(){
		$(".formProcessor").submit(function(e){
		e.preventDefault();
		var that = $(this);
		// var data = that.serialize();
		var url = that.attr('action');
		var post = that.attr('method');
		var display=that.find(".formAlert");
		display.html("<div class='text-center text-bold'><i class='fa fa-spinner fa-spin fa-2x'></i> Please wait.....</div>");

		display.show();

		$.ajax({
			url:url,
			type:"POST",
			data:new FormData(this),
			contentType:false,
			cache:false,
			processData:false,
			success:function(data){
				 console.log(data);
				if(data=='150'){
               		 window.location="<?php echo e(url('150')); ?>";
         		   }

				else if(data.success==1){
					
					if(data.retain==0) {
						// that[0].reset();
						that.trigger('reset');
					}
					else if(data.retain==301){

						$.confirm({
                            title:'Operation successful',
                            content:'Would you like to refresh this page to see the latest data?',
                            icon:'fa fa-check-circle',
                            type:'green',
                            buttons:{
                                yes:function(){
                                    location.reload();
                                },
                                no:function(){
                                    
                                }
                            }
                        });
                        
						
					}
					
					
					display.html("<div class='alert alert-success text-center'>"+data.message+"  <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a></div>");

					setTimeout(function(){display.hide(1000);},6000);
				}
				else if(data.success==301){
					
					$.alert({
						content : data.message,
						title : 'Operation status',
						type : 'green',
					});
						location.reload();
					
					
				}
				else{
					display.html("<div class='alert alert-danger text-center'>"+data.message+"</div>");
				}
				

			},

			 error: function(data) {
				var status = data.status;
			 	/*Checking form validation error*/
			 	var m='';
			 	var error = data.responseJSON;
			 	if(status===422){

                    for(var k in error.errors){
                           // m+=error.errors[k];
                           m+="<div class='alert alert-danger text-center'>"+error.errors[k]+"</div>";
                        }
			 		}

			 		// Other errors
			 	else {

			 	
			 		
			 		 m+="<div class='alert alert-danger text-center'>"+error.message+"</div>";
			 	}
			 		display.html(m);
                    // console.log(data);
                            
                 }

		});

		// submitButton.remove("<i class='fa fa-spinner fa-spin fa-2x'></i>");
	
	});
	}
	
	
	
	
/*Process form*/
	$(".formProcessor").submit(function(e){
		e.preventDefault();
		var that = $(this);
		// var data = that.serialize();
		var url = that.attr('action');
		var post = that.attr('method');
		var display=that.find(".formAlert");
		display.html("<div class='text-center text-bold'><i class='fa fa-spinner fa-spin fa-2x'></i> Please wait.....</div>");

		display.show();

		$.ajax({
			url:url,
			type:"POST",
			data:new FormData(this),
			contentType:false,
			cache:false,
			processData:false,
			success:function(data){
				 console.log(data);
				if(data=='150'){
               		 window.location="<?php echo e(url('150')); ?>";
         		   }

				else if(data.success==1){
					
					if(data.retain==0) {
						// that[0].reset();
						that.trigger('reset');
					}
					else if(data.retain==301){

						$.confirm({
                            title:'Operation successful',
                            content:'Would you like to refresh this page to see the latest data?',
                            icon:'fa fa-check-circle',
                            type:'green',
                            buttons:{
                                yes:function(){
                                    location.reload();
                                },
                                no:function(){
                                    
                                }
                            }
                        });
                        
						
					}
					
					
					display.html("<div class='alert alert-success text-center'>"+data.message+"  <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a></div>");

					setTimeout(function(){display.hide(1000);},6000);
				}
				else if(data.success==301){
					$.alert({
						content : data.message,
						title : 'Operation status',
						type : 'green',
					});
						location.reload();
					
				}
				else{
					display.html("<div class='alert alert-danger text-center'>"+data.message+"</div>");
				}
				

			},

			 error: function(data) {
				var status = data.status;
			 	/*Checking form validation error*/
			 	var m='';
			 	var error = data.responseJSON;
			 	if(status===422){

                    for(var k in error.errors){
                           // m+=error.errors[k];
                           m+="<div class='alert alert-danger text-center'>"+error.errors[k]+"</div>";
                        }
			 		}

			 		// Other errors
			 	else {

			 	
			 		
			 		 m+="<div class='alert alert-danger text-center'>"+error.message+"</div>";
			 	}
			 		display.html(m);
                    // console.log(data);
                            
                 }

		});

		// submitButton.remove("<i class='fa fa-spinner fa-spin fa-2x'></i>");
	
	});
	
	
	

	$(".toggleImager").click(function(){
			$(this).siblings(".logoPicker").click();
		});
			
	$(".logoPicker").change(function(event){
		var showImage=$(this).siblings(".toggleImager").children(".showImage");
		showImage.show();
		$(this).siblings(".toggleImager").children(".i").hide();
		showImage.attr("src",URL.createObjectURL(event.target.files[0]));
		});
	
});
	
</script>
