<?php $__env->startSection('content'); ?>

  <ul class="breadcrumb">
             <li class="breadcrumb-item">
              <a href="<?php echo e(url('home')); ?>">Dashboard</a>
            </li>
            <li class="breadcrumb-item">
              <a href="<?php echo e(url('classes')); ?>">All classes</a>
            </li>
            <li class="breadcrumb-item">
              <span><?php echo e($subject->name); ?> assessments</span>
            </li>
          </ul>
          <!--------------------
          END - Breadcrumbs
          -------------------->
          <div class="content-i">
            <div class="content-box">
                <div class="element-wrapper">
                    
                    <h5 class="element-header">
                      <?php echo App\Aagc::name($aagc_id); ?> <?php echo e($subject->name); ?> Assessment
                      <a href="#" class="moreOption float-right btn btn-success"><i class="fa fa-search"></i> More Options </a>
                    </h5>



                    <!-- <div class="element-box">
                     
                    </div> -->

                    <div class="element-box table-responsive">


                     
                     <?php if(count($assessments) > 0): ?>
                      
                        <table id="table" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>S/N</th>
                                    <th>Student's ID</th>
                                    <th>Name</th>
                                    <th>1<sup>st</sup> Test</th>
                                    <th>2<sup>nd</sup> Test</th>
                                    <th>3<sup>rd</sup> Test</th>
                                    <th>Exam</th>
                                    <th>Total</th>
                                    <th>Grade</th>
                                    <th>Remark</th>
                                    <th>Options</th>
                                </tr>
                            </thead>
                            <tbody>

                              <?php $__currentLoopData = $assessments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assessment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <?php

                                    $test1 = $assessment->test1;
                                    $test2 = $assessment->test2;
                                    $test3 = $assessment->test3;
                                    $exam = $assessment->exam;


                                    $gp = App\Assessment::gradeHelper($test1,$test2,$test3,$exam);

                                   ?>
                                <tr id="<?php echo e($assessment->id); ?>">
                                  <td><?php echo e($x); ?></td>
                                  <td><?php echo e($assessment->admission_no); ?></td>
                                  <td><?php echo e($assessment->name.' '.$assessment->othernames); ?></td>
                                  <td><?php echo e($test1); ?></td>
                                  <td><?php echo e($test2); ?></td>
                                  <td><?php echo e($test3); ?></td>
                                  <td><?php echo e($exam); ?></td>
                                  <td><?php echo e($assessment->gp); ?></td>
                                  <td><?php echo e($assessment->grade); ?></td>
                                  <td><?php echo e($assessment->remark); ?></td>
                                  <td>
                                    <a  href="<?php echo e(url('assessments/destroy')); ?>" data-id="<?php echo e($assessment->id); ?>"  class="text-danger delete" href="#" title="Delete">
                                      <i class="os-icon os-icon-ui-15"></i>
                                    </a>
                                    <a href="<?php echo e(url('assessments/edit/'.$assessment->id)); ?>" title="Edit" class="edit">
                                      <i class="os-icon os-icon-ui-49"></i>
                                    </a>
                                  </td>
                                </tr>
                                <?php ($x++); ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             
                                
                                
                            </tbody>

                        </table>
                      
                    
                    <?php else: ?>
                      <h3>No assessment found</h3>
                    <?php endif; ?>

                    </div>
                </div>
              

              
            </div>
          </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('modal'); ?>
  <!-- Create new subject modal -->
  <div class="modal fade" id="moreOption">
    <div class="modal-dialog modal-md ">
      <div class="modal-content">

        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-name">Fetch assessment</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>

        <!-- Modal body -->
        <div class="modal-body">
          <form method="get" action="<?php echo e(url('assessments/printer')); ?>">

                        

                        <input type="hidden" name="aagc_id" value="<?php echo e($aagc_id); ?>" />

                        
                        <div class="form-group">
                          <select class="form-control sessionOptions" required="" name="session_id"></select>
                        </div>

                        <div class="form-group">
                          <select class="form-control termOptions" required="" name="term_id"></select>
                        </div>

                         <div class="form-group">
                            <select name="subject_id" required="" class="form-control subjectOptions"></select>
                         </div>

                        <div class="form-group">
                          <button class="btn btn-primary" type="submit">View Result</button>

                          
                        </div>

                      


                      </form>
        </div>

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('script'); ?>
  <script type="text/javascript">
    $(document).ready(function(){

      $("#table").DataTable();


      $(".moreOption").click(function(e){
        e.preventDefault();
        sessionOptions('<?php echo e($session_id); ?>');
        termOptions('<?php echo e($term_id); ?>');
        var value = '<?php echo e($aagc_id); ?>';
        subjectOptions('<?php echo e($subject->id); ?>','id IN (SELECT subject_id FROM aagc_subject WHERE aagc_id='+value+')');

        $("#moreOption").modal('show');
      });


      $(".edit").click(function(e){
          e.preventDefault();
          var url = $(this).attr('href');
          
          $.dialog({
              content: function () {
                  var self = this;
                  return $.ajax({
                      url: url,
                      method: 'get',
                  }).done(function (data) {
                      self.setContent(data);
                      self.setTitle('Edit Assessment');
                  }).fail(function(){
                      self.setContent('Something went wrong');
                  });
              },
              columnClass: 'm',
          });


      });

    });
  </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>