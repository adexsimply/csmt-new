<?php if(session()->has('success')): ?>
	<div class="alert text-center alert-success">
		<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		<?php echo e(session()->get('success')); ?>

	</div>
<?php endif; ?>
<?php if(session()->has('error')): ?>
	<div class="alert text-center alert-danger">
		<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		<?php echo e(session()->get('error')); ?>

	</div>
<?php endif; ?>