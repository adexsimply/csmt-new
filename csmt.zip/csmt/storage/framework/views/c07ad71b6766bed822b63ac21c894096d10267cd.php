
<div class="element-box">
	<form class="formProcessor" method="post" action="<?php echo e(url('bece/update')); ?>">
		<?php echo e(csrf_field()); ?>

		<div class="formAlert"></div>

		<input type="hidden" name="student_id" value="<?php echo e($student->id); ?>">
		<input type="hidden" name="session_id" value="<?php echo e($session_id); ?>">

		<div class="form-group">
			<label>Examination no:</label>
			<input type="text" required="" value="<?php echo e($examination_no); ?>" name="examination_no" placeholder="Enter examination no:" class="form-control" />
		</div>


		<?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<input type="hidden" name="subject_id[]" value="<?php echo e($subject->id); ?>">

			<div class="form-group">

				<label><?php echo e($subject->name); ?></label>

				 <?php
                        $score = App\Bece::score($student->id, $subject->id);
                        if($score)
                            $score = $score->score;
                        else
                            $score = 0;
                 ?>

				<input type="number" required="" class="form-control" name="score[]" value="<?php echo e($score); ?>" min="0" max="100" placeholder="Enter <?php echo e($subject->name); ?> score" />

			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		<div class="form-group">
			<label>Remark</label>
			<textarea name="remark" required="" placeholder="Enter remark" class="form-control"><?php echo e($remark); ?></textarea>
		</div>

		<button class="btn btn-primary">Submit</button>
	</form>
</div>
<script type="text/javascript">
	formProcessor();
</script>