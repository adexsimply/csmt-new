<?php $__env->startSection('content'); ?>

  <ul class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="<?php echo e(url('home')); ?>">Dashboard</a>
            </li>
            <li class="breadcrumb-item">
              <a href="<?php echo e(url('classes')); ?>">All classes</a>
            </li>
          </ul>
          <!--
          END - Breadcrumbs
          -->
          <div class="content-i">
            <div class="content-box">
              <div class="element-wrapper compact pt-4">
                <div class="element-wrapper">
                    

                    <h4 class="element-header clearfix">
                      Academic Class Setup
                    </h4>

                    <div class="element-box">

                      <?php if(count($groupClasses)): ?>


                        <div id="accordion">

                        <?php $__currentLoopData = $groupClasses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupClass): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                          <div class="card <?php echo e($x == 1 ? '' : 'rounded-0'); ?> ">
                            <div class="card-header">
                              <a class="card-link" data-toggle="collapse" href="#collapse<?php echo e($x); ?>">
                                <h3><?php echo e($groupClass->name); ?></h3>
                              </a>
                            </div>
                            <div id="collapse<?php echo e($x); ?>" class="collapse <?php echo e($x == 1 ? 'show' : ''); ?>" data-parent="#accordion">
                              <div class="card-body">
                                <?php 
                                  $arms = App\Group_class::armAlias($groupClass->id);
                                ?>


                                <?php if(count($arms) > 0 ): ?>

                                  <div class="row">
                                  <?php $__currentLoopData = $arms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-sm-4">
                                        <a class="element-box el-tablo centered trend-in-corner padded bold-label" href="<?php echo e(url('classes/aagc/'.$groupClass->group_id.'/'.$arm->id.'/'.Addons::url($groupClass->name.'-'.$arm->arm.'-'.$arm->alias))); ?>">
                                          <div class="label dashboard-icons">
                                            <div class="icon-rocket"></div>
                                          </div>
                                          <div class="value dashboard-title">
                                            <?php echo e($arm->arm.' ('.$arm->alias.')'); ?> 
                                          </div>
                                          
                                        </a>
                                      </div>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>


                                <?php else: ?>
                                  <h3 class="text-center">No class arm found</h3>
                                <?php endif; ?> 

                                <a href="#" data-group_class_id="<?php echo e($groupClass->id); ?>" class="newArm btn btn-success">Add <?php echo e($groupClass->name); ?> Arm</a>


                              </div>
                            </div>
                          </div>

                          <?php ($x++); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>

                      <?php else: ?>
                        <h3>No class found, Please call the admin</h3>
                      <?php endif; ?>


                    </div>

                    
                   
                    
                </div>
              </div>
              

              
            </div>
          </div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('modal'); ?>



  <!-- Edit group_class modal -->
  <div class="modal fade" id="editgroup_class">
    <div class="modal-dialog modal-md ">
      <div class="modal-content">

        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-name">Edit group_class</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>

        <!-- Modal body -->
        <div class="modal-body">
          <form class="formProcessor" method="POST" action="<?php echo e(url('group_classes/update')); ?>">

            <div class="formAlert"></div>

            <input type="hidden" name="id" id="id">
            <div class="form-group">
              <label for=""> group_class Name</label>
              <input id="name" required="" name="name" class="form-control" placeholder="Enter group_class name" type="text">
           </div>  


            <button class="btn btn-primary" type="submit"> Update group_class</button>

          </form>
        </div>

      </div>
    </div>
  </div>


  <!-- Create new group_class modal -->
  <div class="modal fade" id="newArm">
    <div class="modal-dialog modal-sm ">
      <div class="modal-content">

        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-name">Create new arm</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>

        <!-- Modal body -->
        <div class="modal-body">
          <form class="formProcessor" method="POST" action="<?php echo e(url('classes/aagc/store')); ?>">

            <div class="formAlert"></div>

            <input type="hidden" id="group_class_id" name="group_class_id">

            <div class="form-group">
              <select class="armOptions form-control" name="arm_id"></select>
            </div>  


            <div class="form-group">
              <select class="aliasOptions form-control" name="alias_id"></select>
            </div>  


          <button class="btn btn-primary" type="submit"> Submit</button>

             </form>
        </div>

      </div>
    </div>
  </div>



<?php $__env->stopSection(); ?>



<?php $__env->startSection('script'); ?>
  <script type="text/javascript">
    $(document).ready(function(){
      

      /*Trigger ad new group_class modal form*/
      $('.newArm').click(function(e){
        e.preventDefault();
        armOptions();
        aliasOptions();

        var group_class_id = $(this).data('group_class_id');

        $("#group_class_id").val(group_class_id);

        $('#newArm').modal('show');
      });


      /*Edit group_class*/
      $('.editgroup_class').click(function(e){
        e.preventDefault();

        var url = $(this).attr('href');
        
        $.get(url,function(data){
          console.log(data);
          var group_class = data.group_class;
          $("#editgroup_class").find('#id').val(group_class.id);
          $("#editgroup_class").find('#name').val(group_class.name);

          $("#editgroup_class").modal('show');
        });
      });

        
  /*Change table status*/
    $(document).on('click','.activateTerm',function(e){
      e.preventDefault();
      var that = $(this);
      var id = that.data('id');
      var url = that.attr('href');

      $.confirm({
        title:'Activate term',
        type:'orange',
        escapeKey: true,
        backgroundDismiss: true,
        icon:'fa fa-warning',
        content:'Are you sure you want to activate this term ?',
        buttons:{
          Yes : function(){
            $.post(url,{id:id},function(data){
              console.log(data);
              if(data.success===1){

                /*Display aax response*/
                $.dialog({
                  content:'Selected term activated successfully',
                  type:'green',
                  escapeKey: true,
                  backgroundDismiss: true,
                  title:'Term activated',
                  icon:'fa fa-check-circle'
                });



                location.reload();
              }
              else if(data==150){
                window.location="<?php echo e(url('150')); ?>";
              }
              else{
                alert(data.message);
              }
            });
          },

          No : function(){}

        }
      });
      
    });




    });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>