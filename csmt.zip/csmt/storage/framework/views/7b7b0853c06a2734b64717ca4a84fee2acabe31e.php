
<?php if(count($sessions) > 0): ?>
<div class="row mb-xl-2 mb-xxl-3">
      
      <?php $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-4">
            <a class="element-box el-tablo centered trend-in-corner padded bold-label" href="<?php echo e(url($exam.'/'.$session->id)); ?>">
                <div class="label dashboard-icons">
                  <div class="os-icon os-icon-tasks-checked"></div>
                </div>
                <div class="value dashboard-title">
                    <?php echo e($session->name); ?>

                </div>
            </a>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

<div class="text-center m-5">
        <a class="btn btn-primary" href="<?php echo e(url($exam.'/create')); ?>"><i class="fa fa-plus-circle"></i> Add new result</a>
      </div>
<?php else: ?>

  <div class="text-center">
        <h3>No result found</h3>
        <a class="btn btn-primary" href="<?php echo e(url($exam.'/create')); ?>"><i class="fa fa-plus-circle"></i> Add new result</a>
  </div>
  
<?php endif; ?>