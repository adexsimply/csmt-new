    
    <?php if(count($students) > 0 ): ?>
    <div class="table-responsive">
            <table class="table table-lightborder">
                <thead>
                   <tr>
                      <th>S/N</th>
                       <th>Student's ID</th>
                       <th>Name</th>
                       <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
 

                                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr id="<?php echo e($student->pivot->id); ?>">
                                    <td><?php echo e($x); ?></td>
                                    <td><?php echo e($student->admission_no); ?></td>
                                    <td><?php echo e($student->surname.' '.$student->othernames); ?></td>
                                    <td><a class="delete" data-toggle="tooltip" title="Remove student from subject" data-id="<?php echo e($student->pivot->id); ?>" href="<?php echo e(url('classes/aagc/subject-student/destroy')); ?>"><i class="fa fa-trash text-danger"></i></a></td>
                                  </tr>
                                  <?php ($x++) ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                    </tbody>
                    
                                   </table>
                                </div>
      <?php else: ?>
        <h3 class="text-center">No student found in selected subject</h3>
      <?php endif; ?>