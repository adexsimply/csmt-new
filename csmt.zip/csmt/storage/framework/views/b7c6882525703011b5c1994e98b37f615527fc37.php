<?php $__env->startSection('content'); ?>

	<ul class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="<?php echo e(url('home')); ?>">Dashboard</a>
            </li>
            <li class="breadcrumb-item">
              <span>Sessions</span>
            </li>
          </ul>
          <!--
          END - Breadcrumbs
          -->
          <div class="content-i">
            <div class="content-box">
              <div class="element-wrapper compact pt-4">
                <div class="element-wrapper">
                    

                    <h4 class="element-header clearfix">
                      Academic Session Setup

                      <a href="#" class="newSession float-right btn btn-success">create new session</a>
                    </h4>

                    
                   
                    
                      <?php if(count($sessions) > 0 ): ?>


                        <?php $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                        <div class="element-box" id="<?php echo e($session->id); ?>">
                           <h3><?php echo e($session->name); ?></h3>
                           <hr>
                          
                          <div class="row mb-xl-2 mb-xxl-3">

                              <?php $__currentLoopData = $session->terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                  <?php if($term->pivot->status == 1 ): ?>
                                      <div class="col-sm-4">
                                        <a class="element-box  bg-success text-white el-tablo centered trend-in-corner padded bold-label" href="#">
                                          <div class="label dashboard-icons">
                                            <div class="icon-check text-white mr-1"></div>
                                          </div>
                                          <div class="value dashboard-title">
                                            <?php echo e($term->name); ?> 
                                          </div>
                                          
                                        </a>
                                      </div>

                                  <?php else: ?>

                                      <div class="col-sm-4">
                                        <a data-toggle="tooltip" data-id="<?php echo e($term->pivot->id); ?>" title="Click to activate" class="element-box el-tablo activateTerm centered trend-in-corner padded bold-label" href="<?php echo e(url('sessions/activate')); ?>">
                                          <div class="label dashboard-icons">
                                            <div class="os-icon os-icon-tasks-checked"></div>
                                          </div>
                                          <div class="value dashboard-title">
                                            <?php echo e($term->name); ?>

                                          </div>
                                          
                                        </a>
                                      </div>

                                  <?php endif; ?> 

                                 
                                     
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  

                          </div>
                                  <div class="clearfix">

                                    <div class="btn btn-group float-right">
                                       <a class="btn editSession btn-info btn-sm" href="<?php echo e(url('sessions/edit/'.$session->id)); ?>" data-toggle="tooltip" title="Edit <?php echo e($session->name); ?>"><i class="fa fa-edit"></i> Edit </a>

                                       <a class="btn btn-danger delete btn-sm" data-id="<?php echo e($session->id); ?>" href="<?php echo e(url('sessions/destroy/'.$session->id)); ?>" data-toggle="tooltip" title="Delete <?php echo e($session->name); ?>"><i class="os-icon os-icon-ui-15"></i>  Delete </a>
                                    </div>


                                  </div>



                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div class="dataTables_paginate paging_simple_numbers" id="example_paginate">
                          <?php echo e($sessions->links()); ?>

                        </div>

                      <?php else: ?>

                        <div class="element-box text-center">
                          <h3> No Session found! </h3>
                          <a href="#" class="newSession btn btn-success">Add new session</a>
                        </div>
                      <?php endif; ?>
                    
                </div>
              </div>
              

              
            </div>
          </div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('modal'); ?>



	<!-- Edit session modal -->
	<div class="modal fade" id="editSession">
	  <div class="modal-dialog modal-md ">
	    <div class="modal-content">

	      <!-- Modal Header -->
	      <div class="modal-header">
	        <h4 class="modal-name">Edit session</h4>
	        <button type="button" class="close" data-dismiss="modal">&times;</button>
	      </div>

	      <!-- Modal body -->
	      <div class="modal-body">
	        <form class="formProcessor" method="POST" action="<?php echo e(url('sessions/update')); ?>">

	        	<div class="formAlert"></div>

	        	<input type="hidden" name="id" id="id">
	        	<div class="form-group">
			        <label for=""> session Name</label>
			        <input id="name" required="" name="name" class="form-control" placeholder="Enter session name" type="text">
			     </div>  


			      <button class="btn btn-primary" type="submit"> Update session</button>

          </form>
	      </div>

	    </div>
	  </div>
	</div>


	<!-- Create new session modal -->
	<div class="modal fade" id="newSession">
	  <div class="modal-dialog modal-md ">
	    <div class="modal-content">

	      <!-- Modal Header -->
	      <div class="modal-header">
	        <h4 class="modal-name">Create new Session</h4>
	        <button type="button" class="close" data-dismiss="modal">&times;</button>
	      </div>

	      <!-- Modal body -->
	      <div class="modal-body">
	        <form class="formProcessor" id="newSession" method="POST" action="<?php echo e(url('sessions/store')); ?>">

	        	<div class="formAlert"></div>

	        	<div class="form-group">
			        <label for=""> Session name</label>
			        <input name="name" required="" class="form-control" placeholder="e.g 2010/2012 session" type="text">
			    </div>  



            <div class="form-check">
                <input type="checkbox" name='activate' value="1" class="form-check-input" id="activate_session">
                <label class="form-check-label" for="activate_session">Activate session</label>
            </div> 

          <br>
            <button class="btn btn-primary" type="submit"> Add session</button>
          
			    

             </form>
	      </div>

	    </div>
	  </div>
	</div>



<?php $__env->stopSection(); ?>



<?php $__env->startSection('script'); ?>
	<script type="text/javascript">
		$(document).ready(function(){


      if(hash = location.hash){
        $(hash).modal('show');
      }
      

      /*Trigger ad new session modal form*/
			$('.newSession').click(function(e){
        e.preventDefault();

        $('#newSession').modal('show');
      });


      /*Edit session*/
      $('.editSession').click(function(e){
        e.preventDefault();

        var url = $(this).attr('href');
        
        $.get(url,function(data){
          console.log(data);
          var session = data.session;
          $("#editSession").find('#id').val(session.id);
          $("#editSession").find('#name').val(session.name);

          $("#editSession").modal('show');
        });
      });

        
  /*Change table status*/
    $(document).on('click','.activateTerm',function(e){
      e.preventDefault();
      var that = $(this);
      var id = that.data('id');
      var url = that.attr('href');

      $.confirm({
        title:'Activate term',
        type:'orange',
        escapeKey: true,
        backgroundDismiss: true,
        icon:'fa fa-warning',
        content:'Are you sure you want to activate this term ?',
        buttons:{
          Yes : function(){
            $.post(url,{id:id},function(data){
              console.log(data);
              if(data.success===1){

                /*Display aax response*/
                $.dialog({
                  content:'Selected term activated successfully',
                  type:'green',
                  escapeKey: true,
                  backgroundDismiss: true,
                  title:'Term activated',
                  icon:'fa fa-check-circle'
                });



                location.reload();
              }
              else if(data==150){
                window.location="<?php echo e(url('150')); ?>";
              }
              else{
                alert(data.message);
              }
            });
          },

          No : function(){}

        }
      });
      
    });




		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>