<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo e(config('app.name')); ?></title>

        <!-- Fonts -->
        <!-- <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css"> -->
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/special.css')); ?>" rel="stylesheet">
      <link href="<?php echo e(asset('fa/css/font-awesome.css')); ?>" rel="stylesheet">
        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }


            .bold{
              font-weight: bold !important;
              
            }

            .blue{
              color: blue !important;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
        </style>
    </head>
    <body>
      <?php 
            $student = App\Student::find($student_id); 
            $total = 0;
        ?>
        <div class="flex-center position-ref">
            

            <div class="content">
                
              <table class="table table-bordered">

                <thead style="display: none;">
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  
                </thead>
                <tbody>

                  <tr class="">
                    <td class="no-space text-center" colspan="2" valign="bottom"><img style="width: 100px;" src="<?php echo e(asset('storage/images/logo.png')); ?>"></td>


                    <td class="no-space" colspan="7 text-center">
                        
                        <h2 class="bold blue no-space">CSMT STAFF SECONDARY SCHOOL</h2>
                        <h5 class="no-space bold">Along Watchman Street, P.M.B. 147, Abakaliki, Ebonyi State, Nigeria</h5>

                        <h5 class="no-space bold">Email: csmtschools@gmail.com Tel: 08032124870, 08066598503</h5>

                        <h3 class="bold blue no-space">CUMMULATIVE REPORT SHEET</h3>
                        <h4 class="bold blue no-space"><?php echo e(App\Session::find($session_id)->name); ?></h4>



                    </td>
                  </tr>

                  <tr>
                    <td colspan="3">STUDENT'S ID: <span class="bold blue"><?php echo e($student->admission_no); ?></span></td>
                    <td colspan="3">STUDENT'S NAME: <span class="bold blue"><?php echo e($student->surname.' '.$student->othernames); ?></span></td>
                    <td colspan="3">CLASS: <span class="bold blue"><?php echo App\Aagc::name($aagc_id); ?></span></td>
                  </tr>

                  <tr>
                    <td colspan="2">House: <span class="blue bold"><?php echo e($student->house->colour); ?></span> </td>
                    <td colspan="2">Club: <span class="blue bold"><?php echo e($student->club->name); ?></span> </td>


                    <td colspan="2">No in Class:  <span class="blue bold"><?php echo e(App\Aagc::find($aagc_id)->students()->count()); ?></span> </td>


                    <td colspan="3">Next Term Begins: <span class="blue bold">28-APR-2018</span></td>

                  </tr>

                  <tr>
                    <td colspan="9" class="bold" style="color:yellow; background: purple;">ACADEMIC REPORT (COGNITIVE DOMAIN)</td>
                  </tr>

                  <!-- Grade head -->
                    <tr>
                      <td></td>
                      
                      <?php if($cummulative == 2): ?>
                        <td colspan="2"></td>
                        <td class="bold blue">1<sup>st</sup> Term</td>
                        <td class="bold blue">2<sup>nd</sup> Term</td>
                        <td class="bold blue">Total</td>
                        <td class="bold blue">Average</td>
                      <?php else: ?>
                        <td></td>
                        <td class="bold blue">1<sup>st</sup> Term</td>
                        <td class="bold blue">2<sup>nd</sup> Term</td>
                        <td class="bold blue">3<sup>rd</sup> Term</td>
                        <td class="bold blue">Total</td>
                        <td class="bold blue">Average</td>
                      <?php endif; ?>

                        <td class="bold blue">Grade</td>
                        <td class="bold blue">Remark</td>


                    </tr>




                    <tr>
                      <td class="bold blue">SN</td>
                      

                      <?php if($cummulative == 2): ?>
                        <td colspan="2" class="bold blue">Subjects</td>
                        <td class="bold blue">100</td>
                        <td class="bold blue">100</td>
                        <td class="bold blue">200</td>

                      <?php else: ?>
                        <td class="bold blue">Subjects</td>
                        <td class="bold blue">100</td>
                        <td class="bold blue">100</td>
                        <td class="bold blue">100</td>
                        <td class="bold blue">300</td>
                      <?php endif; ?>

                    </tr>


                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                      <tr>
                          <td><?php echo e($x); ?></td>
                          <?php if($cummulative == 2): ?>
                            <td colspan="2" class="text-left  bold blue"><?php echo e($subject->name); ?></td>
                          <?php else: ?>
                            <td class="text-left  bold blue"><?php echo e($subject->name); ?></td>
                          <?php endif; ?>

                          <?php 
                                $scores = App\Assessment::cummulativeStudentScore($student_id,$subject->id,$aagc_id,$session_id,$cummulative);

                                $sum=0; 
                          ?>

                          <!-- Printing cummulative scores -->

                          <?php $__currentLoopData = $scores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                           
                              <td><?php echo e($score->score); ?></td>

                              <!-- Calculate score sum -->
                            <?php $sum+=$score->score ?>


                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                          <!-- Calculate grade point -->
                          <?php $gp = round($sum / $cummulative) ?>

                            <td><?php echo e($sum); ?></td>
                            <td><?php echo e($gp); ?></td>
                            <td><?php echo e(App\Assessment :: grade($gp)); ?></td>
                            <td><?php echo e(App\Assessment :: remark($gp)); ?></td>

                      </tr>

                        <!-- Calculate score sum total and increment SN -->
                        <?php $total +=$sum; $x++; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                    <tr>
                      <td colspan="9" class="blue">
                      GRADE DETAILS: <strong>A+</strong> = 90-100% , A = 80-89% , B+ = 70-79% , B = 60-69% , C = 50-59% , D = 40-49% , F = 0-39%

                    </td>
                    </tr>

                    <tr>
                      <td colspan="2">Total: <span class="blue"><?php echo e($total); ?></span></td>
                      <td colspan="3">Student's Average: </td>
                      <td colspan="2">Position in Class: </td>
                      <td colspan="2">Result: </td>
                    </tr>


                    <tr>

                      <td colspan="5" class="no-space">
                        <p class="no-margin padding-5" style="background: purple; color: yellow;">CHARACTER REPORT(AFFECTIVE DOMAIN)</p>
                        <table class="table no-space">
                           
                          <tbody>
                            <tr>
                              <td>Punctuality</td>

                              <td>
                                Classroom: - <br>
                                Resumption:  -
                              </td>
                            </tr>


                            <tr>
                              <td>Punctuality</td>

                              <td>
                                Classroom: - <br>
                                Resumption:  -
                              </td>
                            </tr>


                            <tr>
                              <td>Punctuality</td>

                              <td>
                                Classroom: - <br>
                                Resumption:  -
                              </td>
                            </tr>


                            <tr>
                              <td>Punctuality</td>

                              <td>
                                Classroom: - <br>
                                Resumption:  -
                              </td>
                            </tr>





                          </tbody>
                        </table>
                      </td>




                      <td colspan="5" class="no-space">
                        <p class="no-margin padding-5" style="background: purple; color: yellow;">CHARACTER REPORT(AFFECTIVE DOMAIN)</p>
                        <table class="table no-space">
                           
                          <tbody>
                            <tr>
                              <td>Punctuality</td>

                              <td>
                                Classroom: - <br>
                                Resumption:  -
                              </td>
                            </tr>


                            <tr>
                              <td>Punctuality</td>

                              <td>
                                Classroom: - <br>
                                Resumption:  -
                              </td>
                            </tr>


                            <tr>
                              <td>Punctuality</td>

                              <td>
                                Classroom: - <br>
                                Resumption:  -
                              </td>
                            </tr>


                            <tr>
                              <td>Punctuality</td>

                              <td>
                                Classroom: - <br>
                                Resumption:  -
                              </td>
                            </tr>





                          </tbody>
                        </table>
                      </td>




                    </tr>


                </tbody>

              </table>




            </div>
        </div>
    </body>
</html>
