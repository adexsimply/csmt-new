<?php
    use App\Group_class;
    use App\Aagc;
    use App\User;
    use App\Student;
    use App\Plugin\Addons;
    use Illuminate\SUpport\Facades\DB;

    $students = Student::groupClassStudent(3,1)->with('bece_details')
    						->get(['id','surname','othernames','admission_no']);
    
    dd(Addons::tableFields('old_testimonials'));
    
 ?>
