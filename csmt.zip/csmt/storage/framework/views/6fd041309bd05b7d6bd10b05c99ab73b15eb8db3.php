<?php $__env->startSection('content'); ?>

	<ul class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="dashboard.html">Dashboard</a>
            </li>
            <li class="breadcrumb-item">
              <a href="subject_category.html">Academic Records</a>
            </li>
            <li class="breadcrumb-item">
              <span>Academic Subject Setup</span>
            </li>
          </ul>
          <!--
          END - Breadcrumbs
          -->
          <div class="content-i">
            <div class="content-box">
              <div class="element-wrapper compact pt-4">
                <div class="element-wrapper">
                    
                    <h6 class="element-header">
                      Academic Subject Setup
                    </h6>
                   
                    <div class="element-box">
                      <div class="os-tabs-w">
                        <div class="os-tabs-controls">
                          <ul class="nav nav-tabs smaller nav-tabs-sticky">
                            <li class="nav-item">
                              <a class="nav-link active" data-toggle="tab" href="#create-new-subject"><i class="fa fa-wrench"></i>  Subject setup</a>
                            </li>

                            <li class="nav-item">
                              <a class="nav-link" data-toggle="tab" href="#tab_junior">Junior Secondary Subjects</a>
                            </li>


                            <li class="nav-item">
                              <a class="nav-link" data-toggle="tab" href="#tab_senior">Senior Secondary Subjects</a>
                            </li>
                            
                          </ul>
                          
                        </div>



                        <div class="tab-content">


                          <div class="tab-pane active" id="create-new-subject">
                            <div class="tablo-with-chart">
                              <div class="row">
                                <div class="col-sm-12 col-xxl-12">
                                  <div class="element-box">
                                    <h4>Create new subject</h4>

                                    <form class="formProcessor" action="<?php echo e(url('subjects/store')); ?>">

                                    	<div class="row">
                                    		<div class="col-sm-6">
                                    			<div class="form-group">
			                                        <label for=""> Subject Name</label>
			                                        <input name="name" class="form-control" placeholder="Enter subject name" type="text">
			                                     </div>  

                                    		</div>

                                    		<div class="col-sm-4">
                                    			<div class="form-group">
			                                        <label for=""> Subject Name</label>
			                                        <input  class="form-control" placeholder="Enter subject name" type="text">
			                                      </div>  
                                    		</div>


                                    		<div class="col-sm-2">
                                    			<div class="form-group">
                                    				<label>&nbsp</label>
			                                        	<button class="btn btn-primary" type="submit"> Add Subject</button>
			                                   		
                                    			</div>
                                    			
                                    		</div>
                                    	</div>
                                    </form>

                                  </div>


                                </div>
                              
                              </div>
                            </div>
                          </div>


                          <div class="tab-pane" id="tab_junior">
                            <div class="tablo-with-chart">
                              <div class="row">
                                <div class="col-sm-12 col-xxl-12">
                                  <div class="element-box">
                                    <h4>Create New Subject</h4>
                                    <form class="mt-4">
                                      <div class="form-group">
                                        <label for=""> Subject Name</label>
                                        <input class="form-control" placeholder="Enter subject name" type="text">
                                      </div>                                      
                                      <div class="form-buttons-w">
                                        <button class="btn btn-primary" type="submit"> Add Subject</button>
                                      </div>
                                    </form>

                                  </div>
                                  <div class="element-box">
                                    <h5>Junior Secondary Subject List</h5>
                                    <div class="table-responsive">
                                      <table class="table table-lightborder">
                                        <thead>
                                          <tr>
                                            <th>
                                              S/N
                                            </th>
                                            <th>
                                              Subject Name
                                            </th>
                                            <th>
                                              Subject Child
                                            </th>
                                            <th class="text-center">
                                              Date Added
                                            </th>
                                            <th class="text-right">
                                              Action
                                            </th>
                                          </tr>
                                        </thead>
                                        <tbody>
                                          <tr>
                                            <td>1</td>
                                            <td>Religion and National Value</td>
                                            <td>
                                              <span>C.R.S</span> 
                                              <span class="status_pill green"></span>
                                              <span>Civic Education</span> 
                                              <span class="status_pill green"></span> 
                                              <span>Social Studies</span>
                                              <span class="status_pill green"></span> 
                                              <span>Security Education</span>
                                            </td>
                                            <td class="">
                                              06-12-2016 <span class="badge badge-info">12:12pm</span>
                                            </td>
                                            <td class="row-actions">
                                              <a href="#" title="Edit" class="btn btn-info text-white">
                                                <i class="os-icon os-icon-ui-49"></i>
                                              </a>
                                              <a href="#" title="Add child" class="btn btn-warning my-2"><i class="ti-plus"></i></a>
                                              <a class="btn btn-danger text-white" href="#" title="Delete">
                                                <i class="os-icon os-icon-ui-15"></i>
                                              </a>
                                            </td>
                                          </tr>
                                          <tr>
                                            <td>2</td>
                                            <td>Pre Vocational</td>
                                            <td>
                                                <span>Agricultural Science</span>
                                                <span class="status_pill green"></span>
                                                <span>Home Economics</span>
                                            </td>
                                            <td class="">
                                              06-12-2016  <span class="badge badge-info">12:09pm</span>
                                            </td>
                                            <td class="row-actions">
                                              <a href="#" title="Edit" class="btn btn-info text-white"><i class="os-icon os-icon-ui-49"></i></a>
                                              <a href="#" title="Add child" class="btn btn-warning my-2"><i class="ti-plus"></i></a>
                                              <a class="btn btn-danger text-white" href="#" title="Delete" class="btn btn-danger">
                                                <i class="os-icon os-icon-ui-15"></i>
                                              </a>
                                            </td>
                                          </tr>
                                          <tr>
                                            <td>3</td>
                                            <td>Mathematics</td>
                                            <td>
                                            </td>
                                            <td class="">
                                              06-12-2016  <span class="badge badge-info">12:09pm</span>
                                            </td>
                                            <td class="row-actions">
                                              <a href="#" title="Edit" class="btn btn-info text-white"><i class="os-icon os-icon-ui-49"></i></a>
                                              <a href="#" title="Add child" class="btn btn-warning my-2"><i class="ti-plus"></i></a>
                                              <a class="btn btn-danger text-white" href="#" title="Delete">
                                                <i class="os-icon os-icon-ui-15"></i>
                                              </a>
                                            </td>
                                          </tr>
                                          <tr>
                                            <td>3</td>
                                            <td>Mathematics</td>
                                            <td>
                                            </td>
                                            <td class="">
                                              06-12-2016  <span class="badge badge-info">12:09pm</span>
                                            </td>
                                            <td class="row-actions">
                                              <a href="#" title="Edit" class="btn btn-info text-white"><i class="os-icon os-icon-ui-49"></i></a>
                                              <a href="#" title="Add child" class="btn btn-warning my-2"><i class="ti-plus"></i></a>
                                              <a class="btn btn-danger text-white" href="#" title="Delete">
                                                <i class="os-icon os-icon-ui-15"></i>
                                              </a>
                                            </td>
                                          </tr>
                                          <tr>
                                            <td>4</td>
                                            <td>Igbo Language</td>
                                            <td>
                                            </td>
                                            <td class="">
                                              06-12-2016   <span class="badge badge-info">12:09pm</span>
                                            </td>
                                            <td class="row-actions">
                                              <a href="#" title="Edit" class="btn btn-info text-white"><i class="os-icon os-icon-ui-49"></i></a>
                                              <a href="#" title="Add child" class="btn btn-warning my-2"><i class="ti-plus"></i></a>
                                              <a class="btn btn-danger text-white" href="#" title="Delete">
                                                <i class="os-icon os-icon-ui-15"></i>
                                              </a>
                                            </td>
                                          </tr>
                                          <tr>
                                            <td>5</td>
                                            <td>French</td>
                                            <td>
                                            </td>
                                            <td class="">
                                              06-12-2016   <span class="badge badge-info">12:09pm</span>
                                            </td>
                                            <td class="row-actions">
                                              <a href="#" title="Edit" class="btn btn-info text-white"><i class="os-icon os-icon-ui-49"></i></a>
                                              <a href="#" title="Add child" class="btn btn-warning my-2"><i class="ti-plus"></i></a>
                                              <a class="btn btn-danger text-white" href="#" title="Delete">
                                                <i class="os-icon os-icon-ui-15"></i>
                                              </a>
                                            </td>
                                          </tr>
                                          <tr>
                                            <td>6</td>
                                            <td>C.C Arts</td>
                                            <td>
                                            </td>
                                            <td class="">
                                              06-12-2016   <span class="badge badge-info">12:09pm</span>
                                            </td>
                                            <td class="row-actions">
                                              <a href="#" title="Edit" class="btn btn-info text-white"><i class="os-icon os-icon-ui-49"></i></a>
                                              <a href="#" title="Add child" class="btn btn-warning"><i class="ti-plus"></i></a>
                                              <a class="btn btn-danger text-white" href="#" title="Delete">
                                                <i class="os-icon os-icon-ui-15"></i>
                                              </a>
                                            </td>
                                          </tr>
                                          <tr>
                                            <td>7</td>
                                            <td>Business Studies</td>
                                            <td>
                                            </td>
                                            <td class="">
                                              06-12-2016   <span class="badge badge-info">12:09pm</span>
                                            </td>
                                            <td class="row-actions">
                                              <a href="#" title="Edit" class="btn btn-info text-white"><i class="os-icon os-icon-ui-49"></i></a>
                                              <a href="#" title="Add child" class="btn btn-warning my-2"><i class="ti-plus"></i></a>
                                              <a class="btn btn-danger text-white" href="#" title="Delete" >
                                                <i class="os-icon os-icon-ui-15"></i>
                                              </a>
                                            </td>
                                          </tr>
                                          <tr>
                                            <td>8</td>
                                            <td>English Language</td>
                                            <td>
                                              <span>Literature in English</span>
                                              <span class="status_pill green"></span>
                                              <span>Phonetics</span>
                                              <span class="status_pill green"></span>
                                              <span>Grammar</span>
                                            </td>
                                            <td class="">
                                              06-12-2016   <span class="badge badge-info">12:09pm</span>
                                            </td>
                                            <td class="row-actions">
                                              <a href="#" title="Edit" class="btn btn-info text-white"><i class="os-icon os-icon-ui-49"></i></a>
                                              <a href="#" title="Add child" class="btn btn-warning my-2"><i class="ti-plus"></i></a>
                                              <a class="btn btn-danger text-white" href="#" title="Delete" >
                                                <i class="os-icon os-icon-ui-15"></i>
                                              </a>
                                            </td>
                                          </tr>

                                          <tr>
                                            <td>9</td>
                                            <td>Basic Science and Technology</td>
                                            <td>
                                              
                                              <span>Basic Science</span>
                                              <span class="status_pill green"></span>
                                              <span>Basic Technology</span>
                                              <span class="status_pill green"></span>
                                              <span>P.H.E</span>
                                              <span class="status_pill green"></span>
                                              <span>Information Technology</span>
                                              
                                            </td>
                                            <td class="">
                                              06-12-2016   <span class="badge badge-info">12:09pm</span>
                                            </td>
                                            <td class="row-actions">
                                              <a href="#" title="Edit" class="btn btn-info text-white"><i class="os-icon os-icon-ui-49"></i></a>
                                              <a href="#" title="Add child" class="btn btn-warning my-2"><i class="ti-plus"></i></a>
                                              <a  href="#" title="Delete" class=" btn btn-danger text-white">
                                                <i class="os-icon os-icon-ui-15"></i>
                                              </a>
                                            </td>
                                          </tr>

                                        </tbody>
                                      </table>
                                    </div>

                                  </div>
                                </div>
                              
                              </div>
                            </div>
                          </div>


                          <div class="tab-pane" id="tab_senior">
                            <div class="tablo-with-chart">
                              <div class="row">
                                <div class="col-sm-12 col-xxl-12">



                                  <div class="element-box">
                                    <h4>Create New Subject</h4>
                                    <form class="mt-4">
                                      <div class="form-group">
                                        <label for=""> Subject Name</label>
                                        <input class="form-control" placeholder="E.g English Language" type="text">
                                      </div>  
                                      <div class="form-group row mt-5">
                                        <label class="col-sm-4 col-form-label">Class Arm</label>
                                        <div class="col-sm-8">
                                          <div class="form-check">
                                            <label class="form-check-label">
                                              <input checked="" class="form-check-input" name="classArm" type="checkbox" value="science">Science</label>
                                          </div>
                                          <div class="form-check">
                                            <label class="form-check-label">
                                              <input class="form-check-input" name="classArm" type="checkbox" value="humanities">Humanities</label>
                                          </div>
                                          <div class="form-check">
                                            <label class="form-check-label">
                                              <input class="form-check-input" name="classArm" type="checkbox" value="business">Business</label>
                                          </div>
                                        </div>
                                      </div> 
                                      <div class="form-group row mt-5">
                                        <label class="col-sm-4 col-form-label">Subject Status</label>
                                        <div class="col-sm-8">
                                          <div class="form-check">
                                            <label class="form-check-label">
                                              <input checked="" class="form-check-input" name="subjectStatus" type="radio" value="compulsory">Compulsory</label>
                                          </div>
                                          <div class="form-check">
                                            <label class="form-check-label">
                                              <input class="form-check-input" name="subjectStatus" type="radio" value="optional">Optional</label>
                                          </div>
                                          
                                        </div>
                                      </div>                                   
                                      <div class="form-buttons-w">
                                        <button class="btn btn-primary" type="submit"> Add Subject</button>
                                      </div>
                                    </form>

                                  </div>


                                  <div class="element-box">
                                    <h5 class="mb-5">
                                      <span class="pull-left">Senior Secondary Subject List</span> 
                                      <a href="senior_subject_class.html" class="btn btn-outline-primary pull-right">View by Class Arms</a>
                                    </h5>



                                    <div class="table-responsive">
                                      <table class="table table-bordered">
                                        <thead>
                                          <tr>
                                            <th>
                                              S/N
                                            </th>
                                            <th>
                                              Subject Name
                                            </th>
                                            <th>
                                              Class Arm
                                            </th>
                                            <th>Subject Status</th>
                                            <th class="text-center">
                                              Date Added
                                            </th>
                                            <th class="text-right">
                                              Action
                                            </th>
                                          </tr>
                                        </thead>
                                        <tbody>
                                          <tr>
                                            <td>1</td>
                                            <td>Igbo Language</td>
                                            <td>
                                              <span class="badge badge-warning"> Humanities </span>
                                              <span class="badge badge-primary"> Business</span> 

                                            </td>
                                            <td>Optional</td>
                                            <td class="">16-07-2017 <span class="badge badge-info">7:02pm</span>
                                            </td>
                                            <td class="row-actions">
                                              <a href="#" title="Edit" class="btn btn-info text-white mb-2"><i class="os-icon os-icon-ui-49"></i></a>
                                             
                                              <a class="btn btn-danger text-white" href="#" title="Delete">
                                                <i class="os-icon os-icon-ui-15"></i>
                                              </a>
                                            </td>
                                          </tr>
                                          
                                          <tr>
                                            <td>2</td>
                                            <td>Further Mathematics</td>
                                            <td>
                                              <span class="badge badge-success">Science </span> 
                                              <span class="badge badge-warning"> Humanities </span>
                                              <span class="badge badge-primary"> Business</span> 

                                            </td>
                                            <td>Compulsory</td>
                                            <td class="">12-04-2017  <span class="badge badge-info">5:48pm</span>
                                            </td>
                                            <td class="row-actions">
                                              <a href="#" title="Edit" class="btn btn-info text-white mb-2"><i class="os-icon os-icon-ui-49"></i></a>
                                             
                                              <a class="btn btn-danger text-white" href="#" title="Delete">
                                                <i class="os-icon os-icon-ui-15"></i>
                                              </a>
                                            </td>
                                          </tr>

                                          <tr>
                                            <td>3</td>
                                            <td>Phonetics</td>
                                            <td>
                                              <span class="badge badge-success">Science </span> 
                                              <span class="badge badge-warning"> Humanities </span>
                                              <span class="badge badge-primary"> Business</span> 

                                            </td>
                                            <td>Compulsory</td>
                                            <td class="">15-12-2016  <span class="badge badge-info">4:01pm</span>
                                            </td>
                                            <td class="row-actions">
                                              <a href="#" title="Edit" class="btn btn-info text-white mb-2"><i class="os-icon os-icon-ui-49"></i></a>
                                             
                                              <a class="btn btn-danger text-white" href="#" title="Delete">
                                                <i class="os-icon os-icon-ui-15"></i>
                                              </a>
                                            </td>
                                          </tr>
                                          <tr>
                                            <td>4</td>
                                            <td>Catering</td>
                                            <td>
                                              <span class="badge badge-success">Science </span> 
                                              <span class="badge badge-warning"> Humanities </span>
                                              <span class="badge badge-primary"> Business</span> 
                                            </td>
                                            <td>Optional</td>
                                            <td class="">27-11-2015   <span class="badge badge-info">12:08pm</span>
                                            </td>
                                            <td class="row-actions">
                                              <a href="#" title="Edit" class="btn btn-info text-white mb-2"><i class="os-icon os-icon-ui-49"></i></a>
                                             
                                              <a class="btn btn-danger text-white" href="#" title="Delete">
                                                <i class="os-icon os-icon-ui-15"></i>
                                              </a>
                                            </td>
                                          </tr>

                                          <tr>
                                            <td>5</td>
                                            <td>French Language</td>
                                            <td>
                                              <span class="badge badge-success">Science</span>
                                              <span class="badge badge-warning">Humanities </span>
                                              <span class="badge badge-primary">Business</span> 
                                            </td>
                                            <td>Compulsory</td>
                                            <td class="">27-11-2015   <span class="badge badge-info">12:08pm</span>
                                            </td>
                                            <td class="row-actions">
                                              <a href="#" title="Edit" class="btn btn-info text-white mb-2"><i class="os-icon os-icon-ui-49"></i></a>
                                             
                                              <a class="btn btn-danger text-white" href="#" title="Delete">
                                                <i class="os-icon os-icon-ui-15"></i>
                                              </a>
                                            </td>
                                          </tr>

                                          <tr>
                                            <td>6</td>
                                            <td>Accounts</td>
                                            <td>
                                              <span class="badge badge-primary">Business</span> 
                                            </td>
                                            <td>Compulsory</td>
                                            <td class="">27-06-2015    <span class="badge badge-info">8:14pm</span>
                                            </td>
                                            <td class="row-actions">
                                              <a href="#" title="Edit" class="btn btn-info text-white mb-2"><i class="os-icon os-icon-ui-49"></i></a>
                                             
                                              <a class="btn btn-danger text-white" href="#" title="Delete">
                                                <i class="os-icon os-icon-ui-15"></i>
                                              </a>
                                            </td>
                                          </tr>

                                          <tr>
                                            <td>7</td>
                                            <td>Commerce</td>
                                            <td>
                                              <span class="badge badge-primary">Business</span> 
                                            </td>
                                            <td>Compulsory</td>
                                            <td class="">19-06-2015   <span class="badge badge-info">1:14pm </span>
                                            </td>
                                            <td class="row-actions">
                                              <a href="#" title="Edit" class="btn btn-info text-white mb-2"><i class="os-icon os-icon-ui-49"></i></a>
                                             
                                              <a class="btn btn-danger text-white" href="#" title="Delete">
                                                <i class="os-icon os-icon-ui-15"></i>
                                              </a>
                                            </td>
                                          </tr>

                                          <tr>
                                            <td>8</td>
                                            <td>Christian Religious Knowledge</td>
                                            <td>
                                              <span class="badge badge-warning">Humanities</span> 
                                            </td>
                                            <td>Compulsory</td>
                                            <td class="">19-06-2015 <span class="badge badge-info">1:13pm</span>
                                            </td>
                                            <td class="row-actions">
                                              <a href="#" title="Edit" class="btn btn-info text-white mb-2"><i class="os-icon os-icon-ui-49"></i></a>
                                             
                                              <a class="btn btn-danger text-white" href="#" title="Delete">
                                                <i class="os-icon os-icon-ui-15"></i>
                                              </a>
                                            </td>
                                          </tr> 
                                          <tr>
                                            <td>9</td>
                                            <td>Government</td>
                                            <td>
                                              <span class="badge badge-warning">Humanities</span> 
                                            </td>
                                            <td>Compulsory</td>
                                            <td class="">19-06-2015 <span class="badge badge-info">1:13pm</span>
                                            </td>
                                            <td class="row-actions">
                                              <a href="#" title="Edit" class="btn btn-info text-white mb-2"><i class="os-icon os-icon-ui-49"></i></a>
                                             
                                              <a class="btn btn-danger text-white" href="#" title="Delete">
                                                <i class="os-icon os-icon-ui-15"></i>
                                              </a>
                                            </td>
                                          </tr>
                                          <tr>
                                            <td>10</td>
                                            <td>Literature in English</td>
                                            <td>
                                              <span class="badge badge-warning">Humanities </span>
                                              <span class="badge badge-primary">Business</span> 
                                            </td>
                                            <td>Compulsory</td>
                                            <td class="">19-06-2015 <span class="badge badge-info">1:13pm</span>
                                            </td>
                                            <td class="row-actions">
                                              <a href="#" title="Edit" class="btn btn-info text-white mb-2"><i class="os-icon os-icon-ui-49"></i></a>
                                             
                                              <a class="btn btn-danger text-white" href="#" title="Delete">
                                                <i class="os-icon os-icon-ui-15"></i>
                                              </a>
                                            </td>
                                          </tr>

                                          <tr>
                                            <td>11</td>
                                            <td>Chemistry</td>
                                            <td>
                                              <span class="badge badge-success">Science</span> 
                                            </td>
                                            <td>Compulsory</td>
                                            <td class="">19-06-2015 <span class="badge badge-info">1:12pm</span>
                                            </td>
                                            <td class="row-actions">
                                              <a href="#" title="Edit" class="btn btn-info text-white mb-2"><i class="os-icon os-icon-ui-49"></i></a>
                                             
                                              <a class="btn btn-danger text-white" href="#" title="Delete">
                                                <i class="os-icon os-icon-ui-15"></i>
                                              </a>
                                            </td>
                                          </tr>
                                          <tr>
                                            <td>12</td>
                                            <td>Physics</td>
                                            <td>
                                              <span class="badge badge-success">Science</span> 
                                            </td>
                                            <td>Compulsory</td>
                                            <td class="">19-06-2015 <span class="badge badge-info">1:12pm</span>
                                            </td>
                                            <td class="row-actions">
                                              <a href="#" title="Edit" class="btn btn-info text-white mb-2"><i class="os-icon os-icon-ui-49"></i></a>
                                             
                                              <a class="btn btn-danger text-white" href="#" title="Delete">
                                                <i class="os-icon os-icon-ui-15"></i>
                                              </a>
                                            </td>
                                          </tr>

                                          <tr>
                                            <td>13</td>
                                            <td>Biology</td>
                                            <td>
                                              <span class="badge badge-success">Science</span> 
                                            </td>
                                            <td>Compulsory</td>
                                            <td class="">19-06-2015 <span class="badge badge-info">1:12pm</span>
                                            </td>
                                            <td class="row-actions">
                                              <a href="#" title="Edit" class="btn btn-info text-white mb-2"><i class="os-icon os-icon-ui-49"></i></a>
                                             
                                              <a class="btn btn-danger text-white" href="#" title="Delete">
                                                <i class="os-icon os-icon-ui-15"></i>
                                              </a>
                                            </td>
                                          </tr>

                                          <tr>
                                            <td>14</td>
                                            <td>Economics</td>
                                            <td>
                                              <span class="badge badge-success">Science</span> 
                                              <span class="badge badge-warning">Humanities </span>
                                              <span class="badge badge-primary">Business</span>
                                            </td>
                                            <td>Compulsory</td>
                                            <td class="">19-06-2015 <span class="badge badge-info">1:12pm</span>
                                            </td>
                                            <td class="row-actions">
                                              <a href="#" title="Edit" class="btn btn-info text-white mb-2"><i class="os-icon os-icon-ui-49"></i></a>
                                             
                                              <a class="btn btn-danger text-white" href="#" title="Delete">
                                                <i class="os-icon os-icon-ui-15"></i>
                                              </a>
                                            </td>
                                          </tr>

                                          <tr>
                                            <td>15</td>
                                            <td>  Visual Arts </td>
                                            <td>
                                              <span class="badge badge-warning">Humanities </span>
                                              <span class="badge badge-primary">Business</span>
                                            </td>
                                            <td>Optional</td>
                                            <td class="">19-06-2015 <span class="badge badge-info">1:10pm</span>
                                            </td>
                                            <td class="row-actions">
                                              <a href="#" title="Edit" class="btn btn-info text-white mb-2"><i class="os-icon os-icon-ui-49"></i></a>
                                             
                                              <a class="btn btn-danger text-white" href="#" title="Delete">
                                                <i class="os-icon os-icon-ui-15"></i>
                                              </a>
                                            </td>
                                          </tr>

                                          <tr>
                                            <td>16</td>
                                            <td>Biology</td>
                                            <td>
                                              <span class="badge badge-warning">Humanities </span>
                                              <span class="badge badge-primary">Business</span>
                                            </td>
                                            <td>Optional</td>
                                            <td class="">19-06-2015 <span class="badge badge-info">1:9pm</span>
                                            </td>
                                            <td class="row-actions">
                                              <a href="#" title="Edit" class="btn btn-info text-white mb-2"><i class="os-icon os-icon-ui-49"></i></a>
                                             
                                              <a class="btn btn-danger text-white" href="#" title="Delete">
                                                <i class="os-icon os-icon-ui-15"></i>
                                              </a>
                                            </td>
                                          </tr>
                                          <tr>
                                            <td>17</td>
                                            <td>Technical Drawing</td>
                                            <td>
                                              <span class="badge badge-success">Science</span>
                                             
                                            </td>
                                            <td>Optional</td>
                                            <td class="">19-06-2015 <span class="badge badge-info">1:07pm</span>
                                            </td>
                                            <td class="row-actions">
                                              <a href="#" title="Edit" class="btn btn-info text-white mb-2"><i class="os-icon os-icon-ui-49"></i></a>
                                             
                                              <a class="btn btn-danger text-white" href="#" title="Delete">
                                                <i class="os-icon os-icon-ui-15"></i>
                                              </a>
                                            </td>
                                          </tr>
                                          <tr>
                                            <td>18</td>
                                            <td>Agricultural Science</td>
                                            <td>
                                              <span class="badge badge-success">Science</span>
                                              <span class="badge badge-warning">Humanities </span>
                                              <span class="badge badge-primary">Business</span>
                                             
                                            </td>
                                            <td>Optional</td>
                                            <td class="">19-06-2015 <span class="badge badge-info">1:05pm</span>
                                            </td>
                                            <td class="row-actions">
                                              <a href="#" title="Edit" class="btn btn-info text-white mb-2"><i class="os-icon os-icon-ui-49"></i></a>
                                             
                                              <a class="btn btn-danger text-white" href="#" title="Delete">
                                                <i class="os-icon os-icon-ui-15"></i>
                                              </a>
                                            </td>
                                          </tr>

                                          <tr>
                                            <td>19</td>
                                            <td>Geography</td>
                                            <td>
                                              <span class="badge badge-success">Science</span>
                                              
                                             
                                            </td>
                                            <td>Optional</td>
                                            <td class="">19-06-2015 <span class="badge badge-info">1:02pm</span>
                                            </td>
                                            <td class="row-actions">
                                              <a href="#" title="Edit" class="btn btn-info text-white mb-2"><i class="os-icon os-icon-ui-49"></i></a>
                                             
                                              <a class="btn btn-danger text-white" href="#" title="Delete">
                                                <i class="os-icon os-icon-ui-15"></i>
                                              </a>
                                            </td>
                                          </tr>
                                          <tr>
                                            <td>20</td>
                                            <td>Data Processing</td>
                                            <td>
                                              <span class="badge badge-success">Science</span>
                                              <span class="badge badge-warning">Humanities </span>
                                              <span class="badge badge-primary">Business</span>
                                             
                                            </td>
                                            <td>Optional</td>
                                            <td class="">19-06-2015 <span class="badge badge-info">1:01pm</span>
                                            </td>
                                            <td class="row-actions">
                                              <a href="#" title="Edit" class="btn btn-info text-white mb-2"><i class="os-icon os-icon-ui-49"></i></a>
                                             
                                              <a class="btn btn-danger text-white" href="#" title="Delete">
                                                <i class="os-icon os-icon-ui-15"></i>
                                              </a>
                                            </td>
                                          </tr>
                                          <tr>
                                            <td>21</td>
                                            <td>Civic Education </td>
                                            <td>
                                              <span class="badge badge-success">Science</span>
                                              <span class="badge badge-warning">Humanities </span>
                                              <span class="badge badge-primary">Business</span>
                                             
                                            </td>
                                            <td>Compulsory</td>
                                            <td class="">19-06-2015 <span class="badge badge-info">1:01pm</span>
                                            </td>
                                            <td class="row-actions">
                                              <a href="#" title="Edit" class="btn btn-info text-white mb-2"><i class="os-icon os-icon-ui-49"></i></a>
                                             
                                              <a class="btn btn-danger text-white" href="#" title="Delete">
                                                <i class="os-icon os-icon-ui-15"></i>
                                              </a>
                                            </td>
                                          </tr>
                                          <tr>
                                            <td>22</td>
                                            <td>Mathematics</td>
                                            <td>
                                              <span class="badge badge-success">Science</span>
                                              <span class="badge badge-warning">Humanities </span>
                                              <span class="badge badge-primary">Business</span>
                                             
                                            </td>
                                            <td>Compulsory</td>
                                            <td class="">19-06-2015 <span class="badge badge-info">12:58pm</span>
                                            </td>
                                            <td class="row-actions">
                                              <a href="#" title="Edit" class="btn btn-info text-white mb-2"><i class="os-icon os-icon-ui-49"></i></a>
                                             
                                              <a class="btn btn-danger text-white" href="#" title="Delete">
                                                <i class="os-icon os-icon-ui-15"></i>
                                              </a>
                                            </td>
                                          </tr>
                                          <tr>
                                            <td>23</td>
                                            <td>English Language</td>
                                            <td>
                                              <span class="badge badge-success">Science</span>
                                              <span class="badge badge-warning">Humanities </span>
                                              <span class="badge badge-primary">Business</span>
                                             
                                            </td>
                                            <td>Compulsory</td>
                                            <td class="">19-06-2015 <span class="badge badge-info">12:53pm</span>
                                            </td>
                                            <td class="row-actions">
                                              <a href="#" title="Edit" class="btn btn-info text-white mb-2"><i class="os-icon os-icon-ui-49"></i></a>
                                             
                                              <a class="btn btn-danger text-white" href="#" title="Delete">
                                                <i class="os-icon os-icon-ui-15"></i>
                                              </a>
                                            </td>
                                          </tr>

                                        </tbody>
                                      </table>
                                    </div>




                                  </div>



                                </div>
                              
                              </div>
                            </div>
                          </div>



                        </div>


                      </div>
                    </div>
                </div>
              </div>
              

              
            </div>
          </div>
        </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	<script type="text/javascript">
		$(document).ready(function(){
			$('.nav-tabs-sticky').stickyTabs();
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>