<div class="top-menu-secondary with-overflow color-scheme-dark">
        <!--
        START - Messages Link in secondary top menu
        -->
        <div class="logo-w menu-size">
          <a class="logo" href="index.html"><img src="<?php echo e(asset('storage/images/logo.png')); ?>"><span>CSMT</span></a>
        </div>
        
        <!--
        START - Top Menu Controls
        -->
        <div class="top-menu-controls">
          <div class="element-search d-none d-xl-block">
            <input placeholder="Start typing to search..." type="text">
          </div>
          <div class="top-icon top-search d-xl-none">
            <i class="os-icon os-icon-ui-37"></i>
          </div>          
         
          <!--
          START - Settings Link in secondary top menu
          -->
          <div class="top-icon top-settings os-dropdown-trigger os-dropdown-center">
            <i class="os-icon os-icon-ui-46"></i>
            <div class="os-dropdown">
              <div class="icon-w">
                <i class="os-icon os-icon-ui-46"></i>
              </div>
              <ul>
                <li>
                  <a href="#"><i class="os-icon os-icon-ui-49"></i><span>Profile Settings</span></a>
                </li>
                <li>
                  <a href="#"><i class="os-icon os-icon-grid-10"></i><span>Billing Info</span></a>
                </li>
                <li>
                  <a href="#"><i class="os-icon os-icon-ui-44"></i><span>My Invoices</span></a>
                </li>
                <li>
                  <a href="#"><i class="os-icon os-icon-ui-15"></i><span>Deactivate Account</span></a>
                </li>
              </ul>
            </div>
          </div>
          <!--
          END - Settings Link in secondary top menu
          --><!--
          START - User avatar and menu in secondary top menu
          -->
          <div class="logged-user-w">
            <div class="logged-user-i">
              <div class="avatar-w">
                <img alt="" src="<?php echo e(asset('storage/images/avatar1.jpg')); ?>">
              </div>
              <div class="logged-user-menu">
                <div class="logged-user-avatar-info">
                  <div class="avatar-w">
                    <img alt="" src="<?php echo e(asset('storage/images/avatar1.jpg')); ?>">
                  </div>
                  <div class="logged-user-info-w">
                    <div class="logged-user-name">
                     Shina Adetoye
                    </div>
                    <div class="logged-user-role">
                      Administrator
                    </div>
                  </div>
                </div>
                <div class="bg-icon">
                  <i class="os-icon os-icon-wallet-loaded"></i>
                </div>
                <ul>
                  <li>
                    <a href="apps_email.html"><i class="os-icon os-icon-mail-01"></i><span>Incoming Mail</span></a>
                  </li>
                  <li>
                    <a href="users_profile_big.html"><i class="os-icon os-icon-user-male-circle2"></i><span>Profile Details</span></a>
                  </li>
                  <li>
                    <a href="users_profile_small.html"><i class="os-icon os-icon-coins-4"></i><span>Billing Details</span></a>
                  </li>
                  <li>
                    <a href="#"><i class="os-icon os-icon-others-43"></i><span>Notifications</span></a>
                  </li>
                  <li>
                    <a href="#"><i class="os-icon os-icon-signs-11"></i><span>Logout</span></a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <!--
          END - User avatar and menu in secondary top menu
          -->
        </div>
        <!--
        END - Top Menu Controls
        -->
      </div>