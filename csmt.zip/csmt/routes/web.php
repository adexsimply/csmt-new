<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::get('test', function () {
    return view('test');
});


Route::get('empty', function () {
    return view('empty');
});



Route::middleware(['auth'])->group(function(){
	
	Route::get('/home', 'HomeController@index');

	Route::view('extra','extra.index');

	Route::prefix('next-term-begins')->group(function(){
		Route::post('store','NextTermBeginController@store');
		Route::post('delete','NextTermBeginController@destroy');
	});

	/*Testimonials*/
	Route::prefix('testimonials')->group(function(){
		Route::view('/','testimonials.index');
		Route::get('create','TestimonialController@create');
		Route::get('show','TestimonialController@show');
		Route::get('edit/{id}','TestimonialController@edit');
		Route::get('student/{session_id}','TestimonialController@fetchStudents');

		Route::post('store','TestimonialController@store');
		Route::post('update','TestimonialController@update');
		Route::post('delete','TestimonialController@destroy');
	});



	/*Old Testimonials*/
	Route::prefix('old-testimonials')->group(function(){
		Route::get('create','OldTestimonialController@create');
		Route::get('show','OldTestimonialController@show');
		Route::get('edit/{id}','OldTestimonialController@edit');
		Route::get('student/{session_id}','OldTestimonialController@fetchStudents');

		Route::post('store','OldTestimonialController@store');
		Route::post('update','OldTestimonialController@update');
		Route::post('delete','OldTestimonialController@destroy');
	});



	/*Subject URIs*/
	Route::prefix('subjects')->group(function(){
		Route::get('/','SubjectController@index');
		Route::post('store','SubjectController@store');
		Route::get('edit/{id}','SubjectController@edit');
		Route::post('update','SubjectController@update');
		Route::post('destroy','SubjectController@destroy');


	/*Subject category URIs*/
		Route::get('category/create/{subject_school_id}','SubjectCategoryController@create');
		Route::post('category/store','SubjectCategoryController@store');
		Route::get('category/edit/{id}','SubjectCategoryController@edit');
		Route::post('category/update','SubjectCategoryController@update');
		Route::post('category/destroy','SubjectCategoryController@destroy');
		Route::get('category/addup/{id}/{subject_school_id}','SubjectCategoryController@addupCreate')->where(['id','[0-9]+'],['subject_school_id','[0-9]+']);
		Route::post('category/addup/store','SubjectCategoryController@addupStore');
	});



	/*Bece URIs*/
	Route::prefix('bece')->group(function(){
		Route::get('sessions','BeceController@session');
		Route::get('/{session_id}','BeceController@index')->where(['session_id','[0-9]+']);
		Route::get('show/{student_id}','BeceController@show');
		Route::get('edit/{student_id}/{session_id}','BeceController@edit');
		Route::post('update','BeceController@update');
	});


/*Junior mock URIs*/
	Route::prefix('junior-mock')->group(function(){
		Route::get('sessions','JuniorMockController@session');
		Route::get('/{session_id}','JuniorMockController@index')->where(['session_id','[0-9]+']);
		Route::get('show/{student_id}','JuniorMockController@show');
		Route::get('edit/{student_id}/{session_id}','JuniorMockController@edit');
		Route::post('update','JuniorMockController@update');
	});




/*Senior mock URIs*/
	Route::prefix('senior-mock')->group(function(){
		Route::get('sessions','SeniorMockController@session');
		Route::get('/{session_id}','SeniorMockController@index')->where(['session_id','[0-9]+']);
		Route::get('show/{student_id}','SeniorMockController@show');
		Route::get('edit/{student_id}/{session_id}','SeniorMockController@edit');
		Route::post('update','SeniorMockController@update');
	});



	/*Neco URIs*/
	Route::prefix('neco')->group(function(){
		Route::get('sessions','NecoController@session');
		Route::get('/{session_id}','NecoController@index')->where(['session_id','[0-9]+']);
		Route::get('show/{student_id}','NecoController@show');
		Route::get('edit/{student_id}/{session_id}','NecoController@edit');
		Route::post('update','NecoController@update');
	});



	/*Waec URIs*/
	Route::prefix('waec')->group(function(){
		Route::get('sessions','WaecController@session');
		Route::get('/{session_id}','WaecController@index')->where(['session_id','[0-9]+']);
		Route::get('show/{student_id}','WaecController@show');
		Route::get('edit/{student_id}/{session_id}','WaecController@edit');
		Route::post('update','WaecController@update');
	});



	/*Session URIs*/
	Route::prefix('sessions')->group(function(){
		Route::get('/','SessionController@index');
		Route::post('store','SessionController@store');
		Route::get('edit/{id}','SessionController@edit')->where(['id','[0-9]+']);
		Route::post('update','SessionController@update');
		Route::post('activate','SessionController@activate');
		Route::any('destroy/{id}','SessionController@destroy');

	});



	/*Class URIs*/
	Route::prefix('classes')->group(function(){
		Route::get('/{group_id?}','GroupClassController@index')->where(['group_id','[0-9]+']);

		/*Collect session list for inclusion to class */
		Route::get('aagc/session-list/{aagc_id}','AagcController@sessionList');

		/*Collect class arm student to add commment*/
		Route::get('aagc/comment/{aagc_id}/{session_id}','AagcController@commentSessionStudentList');

		/*Student promotion*/
		Route::get('aagc/promotion/{aagc_id}/{session_id}/{term_id}','AagcController@createPromotion');

		Route::get('aagc/{group_id}/{id}/{name?}','AagcController@index')->where(['id','[0-9]+'],['group_id','[0-9]+']);

		Route::get('aagc/session-details/{group_id}/{group_class_id}/{aagc_id}/{session_id}','AagcController@sessionDetails');

		Route::get('aagc/subject-student/getnew/{aagc_id}/{session_id}/{subject_id}','AagcController@getStudentToSubject');
		Route::get('aagc/subject-student/view/{aagc_id}/{session_id}/{subject_id}','AagcController@viewSubjectStudent');

		Route::post('aagc/subject-setup','AagcController@subjectSetup');
		Route::post('aagc/comment','AagcController@commentOnStudent');
		Route::post('aagc/subject-student-addup','AagcController@studentAddup');
		Route::post('aagc/subject-student/destroy','AagcController@removeStudentFromSubject');

		Route::post('aagc/subject-student','AagcController@addStudentToSubject');
		Route::post('aagc/store','AagcController@store');
		Route::post('aagc/store-single-session','AagcController@addSingleSessionToClass');
		Route::post('aagc/promotion','AagcController@promotion');
		Route::post('aagc/subject/destroy','AagcController@deleteSubject');
		Route::post('aagc/subjects/addnew','AagcController@newSingleSubject');

	});





	Route::prefix('students')->group(function(){
		Route::get('/','StudentController@index');
		Route::get('birthday','StudentController@birthday');
		Route::get('edit/{student_id}','StudentController@edit');
		Route::get('show/{student_id}','StudentController@show');
		Route::get('create/{aagc_id}/{session_id}','StudentController@create');
		Route::get('full-registration','StudentController@createFull');
		Route::post('store','StudentController@store');
		Route::post('update','StudentController@update');
		Route::post('destroy','StudentController@destroy');

	});




	Route::prefix('assessments')->group(function(){

		Route::get('class-assessment-printer','AssessmentController@classAssessment');

		
		Route::get('printer','AssessmentController@printer');
		Route::get('edit/{id}','AssessmentController@edit');
		Route::get('show/{subject_id}','AssessmentController@subjectResult');

		Route::get('cummulative/{aagc_id}/{session_id}','AssessmentController@cummulative');

		Route::get('show/{aagc_id}/{session_id}/{subject_id}','AssessmentController@show');

		Route::get('class-assessment-printer/{aagc_id}/{session_id}/{term_id}','AssessmentController@classAssessment');

		Route::get('create/{aagc_id}/{session_id}/{subject_id}/{term_id}','AssessmentController@create');

		Route::get('printer/{subject_id}/{aagc_id}/{session_id?}/{term_id?}','AssessmentController@printer');
		
		Route::get('print-term-statement/{student_id}/{aagc_id}/{session_id}/{term_id}','AssessmentController@printTermStatement');

		Route::get('print-cummulative-statement/{student_id}/{aagc_id}/{session_id}/{cummulative}','AssessmentController@printCummulativeStatement');



		Route::post('store','AssessmentController@store');
		Route::post('update','AssessmentController@update');
		Route::post('destroy','AssessmentController@destroy');
	});







});




Route::prefix('select')->group(function(){
	Route::get('groups','SelectController@groups');
	Route::get('sessions','SelectController@sessions');
	Route::get('arms','SelectController@arms');
	Route::get('aliases','SelectController@aliases');
	Route::get('full-arms/{group_class_id}','SelectController@fullArms');
	Route::get('assessment_types','SelectController@assessment_types');
	Route::get('classes','SelectController@classes');
	Route::get('subjects/{sql?}','SelectController@subjects');
	Route::get('clubs','SelectController@clubs');
	Route::get('grades','SelectController@grades');
	Route::get('houses','SelectController@houses');
	Route::get('lgas','SelectController@lgas');
	Route::get('states','SelectController@states');
	Route::get('session_term','SelectController@session_term');
	Route::get('student_abilities','SelectController@student_abilities');
	Route::get('student_categories','SelectController@student_categories');
	Route::get('student_posts','SelectController@student_posts');
	Route::get('subject_schools','SelectController@subject_schools');
	Route::get('subject_categories','SelectController@subject_categories');
	Route::get('terms','SelectController@terms');
});


Auth::routes();