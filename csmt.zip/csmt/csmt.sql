-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 16, 2018 at 12:20 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `csmt`
--

DELIMITER $$
--
-- Functions
--
CREATE DEFINER=`root`@`localhost` FUNCTION `examScore` (`score` INT) RETURNS INT(3) RETURN score * 0.7$$

CREATE DEFINER=`root`@`localhost` FUNCTION `grade` (`grade_point` INT) RETURNS CHAR(2) CHARSET latin1 RETURN 
                   CASE
                       WHEN grade_point >= 90 THEN "A+"
                       WHEN grade_point >= 80 THEN "A"
                       WHEN grade_point >= 70 THEN "B+"
                       WHEN grade_point >= 60 THEN "B"
                       WHEN grade_point >= 50 THEN "C"
                       WHEN grade_point >= 40 THEN "D"
                       WHEN grade_point < 40 THEN "F"
                   END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `gradePoint` (`test1` INT, `test2` INT, `test3` INT, `exam` INT) RETURNS INT(3) return ((test1 + test2 + test3) * 0.1) + (exam * 0.7)$$

CREATE DEFINER=`root`@`localhost` FUNCTION `remark` (`grade_point` INT(5) UNSIGNED) RETURNS VARCHAR(20) CHARSET latin1 RETURN 
                   CASE
                       WHEN grade_point >= 90 THEN "EXCELLENT"
                       WHEN grade_point >= 80 THEN "VERY GOOD"
                       WHEN grade_point >= 70 THEN "GOOD"
                       WHEN grade_point >= 60 THEN "FAIRLY GOOD"
                       WHEN grade_point >= 50 THEN "FAIR"
                       WHEN grade_point >= 40 THEN "POOR"
                       WHEN grade_point < 40 THEN "VERY POOR"
                   END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `testScore` (`score` INT) RETURNS INT(3) RETURN score * 0.1$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `aagc`
--

CREATE TABLE `aagc` (
  `id` int(10) UNSIGNED NOT NULL,
  `group_class_id` int(10) UNSIGNED NOT NULL,
  `arm_id` int(10) UNSIGNED NOT NULL,
  `alias_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `aagc`
--

INSERT INTO `aagc` (`id`, `group_class_id`, `arm_id`, `alias_id`, `created_at`, `updated_at`) VALUES
(2, 1, 1, 1, NULL, NULL),
(3, 1, 2, 2, NULL, NULL),
(4, 1, 3, 3, NULL, NULL),
(5, 2, 1, 1, NULL, NULL),
(6, 1, 4, 3, NULL, NULL),
(7, 3, 1, 1, NULL, NULL),
(8, 3, 2, 2, NULL, NULL),
(9, 3, 3, 3, NULL, NULL),
(10, 6, 1, 4, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `aagc_session`
--

CREATE TABLE `aagc_session` (
  `id` int(10) UNSIGNED NOT NULL,
  `session_id` int(10) UNSIGNED NOT NULL,
  `aagc_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `aagc_session`
--

INSERT INTO `aagc_session` (`id`, `session_id`, `aagc_id`) VALUES
(1, 1, 2),
(2, 1, 3),
(3, 1, 4),
(4, 1, 6),
(5, 1, 5),
(6, 1, 7),
(7, 1, 8),
(8, 1, 10),
(9, 2, 2),
(10, 2, 3),
(11, 2, 4),
(12, 2, 6),
(13, 2, 5),
(14, 2, 7),
(15, 2, 8),
(16, 2, 9),
(17, 2, 10);

-- --------------------------------------------------------

--
-- Table structure for table `aagc_session_student`
--

CREATE TABLE `aagc_session_student` (
  `id` int(10) UNSIGNED NOT NULL,
  `aagc_id` int(10) UNSIGNED NOT NULL,
  `session_id` int(10) UNSIGNED NOT NULL,
  `student_id` int(10) UNSIGNED NOT NULL,
  `principal_comment` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `teacher_comment` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hostel_comment` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `promotion_status` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `aagc_session_student`
--

INSERT INTO `aagc_session_student` (`id`, `aagc_id`, `session_id`, `student_id`, `principal_comment`, `teacher_comment`, `hostel_comment`, `promotion_status`, `created_at`, `updated_at`) VALUES
(11, 10, 1, 49, NULL, NULL, NULL, 0, NULL, NULL),
(14, 8, 1, 52, NULL, NULL, NULL, 0, NULL, NULL),
(15, 8, 1, 53, NULL, NULL, NULL, 0, NULL, NULL),
(16, 7, 1, 54, NULL, NULL, NULL, 0, NULL, NULL),
(17, 2, 1, 8, 'pp', 'pp', 'pp', 1, NULL, '2018-05-14 15:05:21'),
(18, 2, 1, 9, 'pp', 'pp', 'pp', 1, NULL, '2018-05-14 15:05:21'),
(19, 2, 1, 48, 'Grate nd responsible', 'Good bOy', 'Hes', 0, NULL, '2018-05-14 15:05:21'),
(20, 2, 1, 51, 'll', 'j', 'j', 0, NULL, '2018-05-14 15:05:21'),
(21, 2, 1, 52, 'hh', 'hh', 'jj', 0, NULL, '2018-05-14 15:05:21'),
(22, 5, 1, 56, NULL, NULL, NULL, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `aagc_subject`
--

CREATE TABLE `aagc_subject` (
  `id` int(10) UNSIGNED NOT NULL,
  `aagc_id` int(10) UNSIGNED NOT NULL,
  `subject_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `aagc_subject`
--

INSERT INTO `aagc_subject` (`id`, `aagc_id`, `subject_id`, `created_at`, `updated_at`) VALUES
(1, 4, 1, '2018-05-07 05:05:36', NULL),
(2, 5, 1, '2018-05-08 08:05:50', NULL),
(3, 5, 2, '2018-05-08 08:05:50', NULL),
(4, 5, 3, '2018-05-08 08:05:50', NULL),
(5, 5, 4, '2018-05-08 08:05:50', NULL),
(6, 5, 5, '2018-05-08 08:05:50', NULL),
(7, 5, 6, '2018-05-08 08:05:50', NULL),
(8, 5, 12, '2018-05-08 08:05:50', NULL),
(9, 5, 13, '2018-05-08 08:05:50', NULL),
(10, 2, 1, '2018-05-09 03:05:36', NULL),
(11, 2, 2, '2018-05-09 03:05:36', NULL),
(12, 2, 3, NULL, NULL),
(13, 2, 13, NULL, NULL),
(14, 2, 12, NULL, NULL),
(15, 2, 6, NULL, NULL),
(16, 2, 5, NULL, NULL),
(17, 2, 4, NULL, NULL),
(18, 7, 1, '2018-05-13 07:05:35', NULL),
(19, 7, 2, '2018-05-13 07:05:35', NULL),
(20, 7, 3, '2018-05-13 07:05:35', NULL),
(21, 7, 4, '2018-05-13 07:05:35', NULL),
(22, 7, 5, '2018-05-13 07:05:35', NULL),
(23, 7, 6, '2018-05-13 07:05:35', NULL),
(24, 7, 12, '2018-05-13 07:05:35', NULL),
(25, 7, 13, '2018-05-13 07:05:35', NULL),
(66, 8, 1, '2018-05-13 08:05:46', NULL),
(67, 8, 2, '2018-05-13 08:05:46', NULL),
(68, 8, 3, '2018-05-13 08:05:46', NULL),
(69, 8, 4, '2018-05-13 08:05:46', NULL),
(70, 8, 5, '2018-05-13 08:05:46', NULL),
(71, 8, 6, '2018-05-13 08:05:46', NULL),
(72, 8, 12, '2018-05-13 08:05:46', NULL),
(73, 8, 13, '2018-05-13 08:05:46', NULL),
(74, 10, 1, '2018-05-13 22:05:35', NULL),
(75, 10, 3, '2018-05-13 22:05:35', NULL),
(76, 10, 4, '2018-05-13 22:05:35', NULL),
(77, 10, 5, '2018-05-13 22:05:35', NULL),
(78, 10, 6, '2018-05-13 22:05:35', NULL),
(79, 10, 7, '2018-05-13 22:05:35', NULL),
(80, 10, 8, '2018-05-13 22:05:35', NULL),
(81, 10, 10, '2018-05-13 22:05:35', NULL),
(82, 10, 11, '2018-05-13 22:05:35', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `aagc_subject_student`
--

CREATE TABLE `aagc_subject_student` (
  `id` int(10) UNSIGNED NOT NULL,
  `subject_id` int(10) UNSIGNED NOT NULL,
  `aagc_id` int(10) UNSIGNED NOT NULL,
  `student_id` int(10) UNSIGNED NOT NULL,
  `session_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `aagc_subject_student`
--

INSERT INTO `aagc_subject_student` (`id`, `subject_id`, `aagc_id`, `student_id`, `session_id`, `created_at`, `updated_at`) VALUES
(12, 1, 2, 8, 1, '2018-05-09 03:05:36', NULL),
(13, 2, 2, 8, 1, '2018-05-09 03:05:36', NULL),
(14, 1, 2, 9, 1, '2018-05-09 03:05:36', NULL),
(15, 2, 2, 9, 1, '2018-05-09 03:05:36', NULL),
(16, 1, 2, 48, 1, NULL, NULL),
(17, 2, 2, 48, 1, NULL, NULL),
(20, 1, 2, 50, 1, NULL, NULL),
(21, 2, 2, 50, 1, NULL, NULL),
(22, 1, 2, 51, 1, NULL, NULL),
(23, 2, 2, 51, 1, NULL, NULL),
(24, 3, 2, 8, 1, NULL, NULL),
(25, 3, 2, 9, 1, NULL, NULL),
(26, 3, 2, 48, 1, NULL, NULL),
(28, 3, 2, 50, 1, NULL, NULL),
(29, 3, 2, 51, 1, NULL, NULL),
(30, 13, 2, 8, 1, NULL, NULL),
(31, 13, 2, 9, 1, NULL, NULL),
(32, 13, 2, 48, 1, NULL, NULL),
(34, 13, 2, 50, 1, NULL, NULL),
(35, 13, 2, 51, 1, NULL, NULL),
(36, 12, 2, 8, 1, NULL, NULL),
(37, 12, 2, 9, 1, NULL, NULL),
(38, 12, 2, 48, 1, NULL, NULL),
(40, 12, 2, 50, 1, NULL, NULL),
(41, 12, 2, 51, 1, NULL, NULL),
(42, 6, 2, 8, 1, NULL, NULL),
(43, 6, 2, 9, 1, NULL, NULL),
(44, 6, 2, 48, 1, NULL, NULL),
(46, 6, 2, 50, 1, NULL, NULL),
(47, 6, 2, 51, 1, NULL, NULL),
(48, 5, 2, 8, 1, NULL, NULL),
(49, 5, 2, 9, 1, NULL, NULL),
(50, 5, 2, 48, 1, NULL, NULL),
(52, 5, 2, 50, 1, NULL, NULL),
(53, 5, 2, 51, 1, NULL, NULL),
(54, 4, 2, 8, 1, NULL, NULL),
(55, 4, 2, 9, 1, NULL, NULL),
(56, 4, 2, 48, 1, NULL, NULL),
(58, 4, 2, 50, 1, NULL, NULL),
(59, 4, 2, 51, 1, NULL, NULL),
(124, 1, 8, 52, 1, '2018-05-13 08:05:46', NULL),
(125, 2, 8, 52, 1, '2018-05-13 08:05:46', NULL),
(126, 3, 8, 52, 1, '2018-05-13 08:05:46', NULL),
(127, 4, 8, 52, 1, '2018-05-13 08:05:46', NULL),
(128, 5, 8, 52, 1, '2018-05-13 08:05:46', NULL),
(129, 6, 8, 52, 1, '2018-05-13 08:05:46', NULL),
(130, 12, 8, 52, 1, '2018-05-13 08:05:46', NULL),
(131, 13, 8, 52, 1, '2018-05-13 08:05:46', NULL),
(132, 1, 8, 53, 1, '2018-05-13 08:05:46', NULL),
(133, 2, 8, 53, 1, '2018-05-13 08:05:46', NULL),
(134, 3, 8, 53, 1, '2018-05-13 08:05:46', NULL),
(135, 4, 8, 53, 1, '2018-05-13 08:05:46', NULL),
(136, 5, 8, 53, 1, '2018-05-13 08:05:46', NULL),
(137, 6, 8, 53, 1, '2018-05-13 08:05:46', NULL),
(138, 12, 8, 53, 1, '2018-05-13 08:05:46', NULL),
(139, 13, 8, 53, 1, '2018-05-13 08:05:46', NULL),
(140, 1, 7, 54, 1, NULL, NULL),
(141, 2, 7, 54, 1, NULL, NULL),
(142, 3, 7, 54, 1, NULL, NULL),
(143, 4, 7, 54, 1, NULL, NULL),
(144, 5, 7, 54, 1, NULL, NULL),
(145, 6, 7, 54, 1, NULL, NULL),
(146, 12, 7, 54, 1, NULL, NULL),
(147, 13, 7, 54, 1, NULL, NULL),
(148, 1, 10, 49, 1, '2018-05-13 22:05:35', NULL),
(149, 3, 10, 49, 1, '2018-05-13 22:05:35', NULL),
(150, 4, 10, 49, 1, '2018-05-13 22:05:35', NULL),
(151, 5, 10, 49, 1, '2018-05-13 22:05:35', NULL),
(152, 6, 10, 49, 1, '2018-05-13 22:05:35', NULL),
(153, 7, 10, 49, 1, '2018-05-13 22:05:35', NULL),
(154, 8, 10, 49, 1, '2018-05-13 22:05:35', NULL),
(155, 10, 10, 49, 1, '2018-05-13 22:05:35', NULL),
(156, 11, 10, 49, 1, '2018-05-13 22:05:35', NULL),
(157, 1, 5, 56, 1, NULL, NULL),
(158, 2, 5, 56, 1, NULL, NULL),
(159, 3, 5, 56, 1, NULL, NULL),
(160, 4, 5, 56, 1, NULL, NULL),
(161, 5, 5, 56, 1, NULL, NULL),
(162, 6, 5, 56, 1, NULL, NULL),
(163, 12, 5, 56, 1, NULL, NULL),
(164, 13, 5, 56, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Stand-in structure for view `aagc_view`
--
CREATE TABLE `aagc_view` (
`id` int(10) unsigned
,`class` varchar(20)
,`arm` varchar(42)
);

-- --------------------------------------------------------

--
-- Table structure for table `aliases`
--

CREATE TABLE `aliases` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `aliases`
--

INSERT INTO `aliases` (`id`, `name`) VALUES
(1, 'Ruby'),
(2, 'Diamond'),
(3, 'Gold'),
(4, 'Science');

-- --------------------------------------------------------

--
-- Table structure for table `arms`
--

CREATE TABLE `arms` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `arms`
--

INSERT INTO `arms` (`id`, `name`) VALUES
(1, 'A'),
(2, 'B'),
(3, 'C'),
(4, 'D');

-- --------------------------------------------------------

--
-- Table structure for table `assessments`
--

CREATE TABLE `assessments` (
  `id` int(10) UNSIGNED NOT NULL,
  `test1` int(10) UNSIGNED NOT NULL,
  `test3` int(10) UNSIGNED NOT NULL,
  `test2` int(10) UNSIGNED NOT NULL,
  `exam` int(10) UNSIGNED NOT NULL,
  `student_id` int(10) UNSIGNED NOT NULL,
  `aagc_id` int(10) UNSIGNED NOT NULL,
  `session_id` int(10) UNSIGNED NOT NULL,
  `term_id` int(10) UNSIGNED NOT NULL,
  `subject_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `assessments`
--

INSERT INTO `assessments` (`id`, `test1`, `test3`, `test2`, `exam`, `student_id`, `aagc_id`, `session_id`, `term_id`, `subject_id`, `created_at`, `updated_at`) VALUES
(1, 80, 87, 77, 89, 8, 2, 1, 1, 1, NULL, '2018-05-10 17:03:23'),
(2, 67, 55, 99, 100, 9, 2, 1, 1, 1, NULL, '2018-05-10 17:04:39'),
(4, 88, 66, 77, 75, 9, 2, 1, 1, 2, NULL, '2018-05-11 21:53:56'),
(5, 90, 90, 100, 90, 8, 2, 1, 1, 2, NULL, '2018-05-11 21:53:10'),
(6, 89, 56, 76, 45, 48, 2, 1, 1, 2, NULL, NULL),
(7, 90, 54, 76, 89, 49, 2, 1, 1, 2, NULL, NULL),
(8, 78, 56, 90, 89, 50, 2, 1, 1, 2, NULL, NULL),
(9, 44, 66, 77, 88, 51, 2, 1, 1, 2, NULL, NULL),
(10, 89, 66, 99, 77, 48, 2, 1, 1, 1, NULL, NULL),
(11, 77, 44, 66, 55, 49, 2, 1, 1, 1, NULL, NULL),
(12, 22, 77, 55, 99, 50, 2, 1, 1, 1, NULL, NULL),
(13, 66, 44, 88, 99, 51, 2, 1, 1, 1, NULL, NULL),
(14, 89, 77, 90, 55, 8, 2, 1, 1, 3, NULL, NULL),
(15, 44, 88, 77, 55, 9, 2, 1, 1, 3, NULL, NULL),
(16, 55, 88, 77, 0, 48, 2, 1, 1, 3, NULL, NULL),
(17, 99, 77, 8, 90, 49, 2, 1, 1, 3, NULL, NULL),
(18, 90, 89, 90, 0, 50, 2, 1, 1, 3, NULL, NULL),
(19, 89, 56, 87, 77, 51, 2, 1, 1, 3, NULL, NULL),
(20, 90, 7, 89, 88, 8, 2, 1, 1, 13, NULL, NULL),
(21, 88, 78, 90, 99, 9, 2, 1, 1, 13, NULL, NULL),
(22, 67, 9, 89, 100, 48, 2, 1, 1, 13, NULL, NULL),
(23, 78, 66, 90, 89, 49, 2, 1, 1, 13, NULL, NULL),
(24, 78, 88, 88, 6, 50, 2, 1, 1, 13, NULL, NULL),
(25, 77, 90, 88, 56, 51, 2, 1, 1, 13, NULL, NULL),
(26, 78, 90, 39, 78, 8, 2, 1, 1, 12, NULL, NULL),
(27, 88, 66, 77, 44, 9, 2, 1, 1, 12, NULL, NULL),
(28, 88, 55, 99, 77, 48, 2, 1, 1, 12, NULL, NULL),
(29, 90, 99, 99, 100, 49, 2, 1, 1, 12, NULL, NULL),
(30, 89, 0, 99, 99, 50, 2, 1, 1, 12, NULL, NULL),
(31, 99, 66, 99, 43, 51, 2, 1, 1, 12, NULL, NULL),
(32, 90, 55, 66, 44, 8, 2, 1, 1, 5, NULL, NULL),
(33, 44, 34, 54, 12, 9, 2, 1, 1, 5, NULL, NULL),
(34, 67, 67, 89, 55, 48, 2, 1, 1, 5, NULL, NULL),
(35, 80, 55, 89, 66, 49, 2, 1, 1, 5, NULL, NULL),
(36, 88, 44, 90, 89, 50, 2, 1, 1, 5, NULL, NULL),
(37, 44, 89, 67, 45, 51, 2, 1, 1, 5, NULL, NULL),
(38, 90, 100, 90, 100, 8, 2, 1, 1, 6, NULL, NULL),
(39, 89, 88, 88, 56, 9, 2, 1, 1, 6, NULL, NULL),
(40, 56, 89, 45, 9, 48, 2, 1, 1, 6, NULL, NULL),
(41, 87, 23, 55, 56, 49, 2, 1, 1, 6, NULL, NULL),
(42, 8, 11, 9, 100, 50, 2, 1, 1, 6, NULL, NULL),
(43, 78, 12, 90, 15, 51, 2, 1, 1, 6, NULL, NULL),
(44, 78, 19, 19, 90, 8, 2, 1, 1, 4, NULL, NULL),
(45, 99, 10, 18, 99, 9, 2, 1, 1, 4, NULL, NULL),
(46, 10, 20, 10, 89, 48, 2, 1, 1, 4, NULL, NULL),
(47, 19, 79, 46, 20, 49, 2, 1, 1, 4, NULL, NULL),
(48, 78, 10, 90, 20, 50, 2, 1, 1, 4, NULL, NULL),
(49, 57, 78, 80, 12, 51, 2, 1, 1, 4, NULL, NULL),
(50, 90, 90, 90, 98, 8, 2, 1, 2, 3, NULL, NULL),
(51, 100, 100, 100, 90, 9, 2, 1, 2, 3, NULL, NULL),
(52, 90, 99, 55, 44, 48, 2, 1, 2, 3, NULL, NULL),
(53, 80, 67, 90, 89, 49, 2, 1, 2, 3, NULL, NULL),
(54, 4, 88, 67, 99, 50, 2, 1, 2, 3, NULL, NULL),
(55, 56, 67, 99, 3, 51, 2, 1, 2, 3, NULL, NULL),
(56, 90, 99, 78, 99, 8, 2, 1, 2, 2, NULL, NULL),
(57, 99, 77, 88, 99, 9, 2, 1, 2, 2, NULL, NULL),
(58, 68, 0, 99, 78, 48, 2, 1, 2, 2, NULL, NULL),
(59, 99, 3, 6, 88, 49, 2, 1, 2, 2, NULL, NULL),
(60, 76, 66, 88, 6, 50, 2, 1, 2, 2, NULL, NULL),
(61, 45, 10, 89, 90, 51, 2, 1, 2, 2, NULL, NULL),
(62, 88, 56, 90, 98, 8, 2, 1, 2, 13, NULL, NULL),
(63, 90, 100, 90, 98, 9, 2, 1, 2, 13, NULL, NULL),
(64, 67, 90, 45, 34, 48, 2, 1, 2, 13, NULL, NULL),
(65, 22, 7, 55, 90, 49, 2, 1, 2, 13, NULL, NULL),
(66, 66, 99, 77, 44, 50, 2, 1, 2, 13, NULL, NULL),
(67, 90, 56, 89, 49, 51, 2, 1, 2, 13, NULL, NULL),
(68, 1, 89, 67, 100, 8, 2, 1, 2, 12, NULL, NULL),
(69, 90, 34, 56, 88, 9, 2, 1, 2, 12, NULL, NULL),
(70, 67, 45, 90, 90, 48, 2, 1, 2, 12, NULL, NULL),
(71, 78, 90, 90, 90, 49, 2, 1, 2, 12, NULL, NULL),
(72, 45, 100, 90, 100, 50, 2, 1, 2, 12, NULL, NULL),
(73, 0, 100, 90, 1, 51, 2, 1, 2, 12, NULL, NULL),
(74, 89, 19, 78, 100, 8, 2, 1, 2, 6, NULL, NULL),
(75, 100, 100, 100, 79, 9, 2, 1, 2, 6, NULL, NULL),
(76, 99, 4, 66, 99, 48, 2, 1, 2, 6, NULL, NULL),
(77, 44, 77, 99, 10, 49, 2, 1, 2, 6, NULL, NULL),
(78, 100, 66, 99, 77, 50, 2, 1, 2, 6, NULL, NULL),
(79, 54, 44, 88, 77, 51, 2, 1, 2, 6, NULL, NULL),
(80, 89, 88, 27, 67, 8, 2, 1, 2, 1, NULL, NULL),
(81, 19, 90, 67, 56, 9, 2, 1, 2, 1, NULL, NULL),
(82, 67, 99, 46, 44, 48, 2, 1, 2, 1, NULL, NULL),
(83, 90, 67, 89, 9, 49, 2, 1, 2, 1, NULL, NULL),
(84, 68, 5, 99, 78, 50, 2, 1, 2, 1, NULL, NULL),
(85, 97, 98, 68, 4, 51, 2, 1, 2, 1, NULL, NULL),
(86, 99, 77, 66, 55, 8, 2, 1, 2, 5, NULL, NULL),
(87, 77, 77, 55, 4, 9, 2, 1, 2, 5, NULL, NULL),
(88, 88, 8, 66, 80, 48, 2, 1, 2, 5, NULL, NULL),
(89, 0, 87, 8, 88, 49, 2, 1, 2, 5, NULL, NULL),
(90, 44, 0, 88, 55, 50, 2, 1, 2, 5, NULL, NULL),
(91, 44, 99, 77, 0, 51, 2, 1, 2, 5, NULL, NULL),
(92, 78, 76, 90, 44, 8, 2, 1, 2, 4, NULL, NULL),
(93, 66, 44, 88, 77, 9, 2, 1, 2, 4, NULL, NULL),
(94, 44, 44, 77, 66, 48, 2, 1, 2, 4, NULL, NULL),
(95, 99, 66, 88, 44, 49, 2, 1, 2, 4, NULL, NULL),
(96, 77, 5, 66, 33, 50, 2, 1, 2, 4, NULL, NULL),
(97, 99, 90, 0, 90, 51, 2, 1, 2, 4, NULL, NULL),
(98, 87, 4, 56, 55, 8, 2, 1, 3, 3, NULL, NULL),
(99, 4, 7, 6, 7, 9, 2, 1, 3, 3, NULL, NULL),
(100, 9, 5, 7, 6, 48, 2, 1, 3, 3, NULL, NULL),
(101, 8, 5, 7, 7, 49, 2, 1, 3, 3, NULL, NULL),
(102, 8, 5, 7, 4, 50, 2, 1, 3, 3, NULL, NULL),
(103, 9, 6, 8, 4, 51, 2, 1, 3, 3, NULL, NULL),
(104, 56, 7, 6, 5, 8, 2, 1, 3, 2, NULL, NULL),
(105, 4, 9, 7, 4, 9, 2, 1, 3, 2, NULL, NULL),
(106, 6, 7, 5, 9, 48, 2, 1, 3, 2, NULL, NULL),
(107, 7, 9, 8, 69, 49, 2, 1, 3, 2, NULL, NULL),
(108, 7, 57, 8, 53, 50, 2, 1, 3, 2, NULL, NULL),
(109, 6, 8, 5, 5, 51, 2, 1, 3, 2, NULL, NULL),
(110, 88, 99, 99, 99, 8, 2, 1, 3, 13, NULL, NULL),
(111, 99, 99, 99, 99, 9, 2, 1, 3, 13, NULL, NULL),
(112, 99, 99, 99, 99, 48, 2, 1, 3, 13, NULL, NULL),
(113, 99, 99, 99, 99, 49, 2, 1, 3, 13, NULL, NULL),
(114, 99, 99, 99, 99, 50, 2, 1, 3, 13, NULL, NULL),
(115, 99, 99, 99, 99, 51, 2, 1, 3, 13, NULL, NULL),
(116, 78, 88, 77, 88, 8, 2, 1, 3, 12, NULL, NULL),
(117, 88, 88, 88, 88, 9, 2, 1, 3, 12, NULL, NULL),
(118, 88, 88, 88, 88, 48, 2, 1, 3, 12, NULL, NULL),
(119, 88, 88, 88, 88, 49, 2, 1, 3, 12, NULL, NULL),
(120, 88, 88, 88, 88, 50, 2, 1, 3, 12, NULL, NULL),
(121, 88, 88, 88, 88, 51, 2, 1, 3, 12, NULL, NULL),
(122, 7, 88, 88, 87, 8, 2, 1, 3, 6, NULL, NULL),
(123, 90, 66, 66, 66, 9, 2, 1, 3, 6, NULL, NULL),
(124, 66, 66, 66, 66, 48, 2, 1, 3, 6, NULL, NULL),
(125, 66, 66, 66, 66, 49, 2, 1, 3, 6, NULL, NULL),
(126, 66, 66, 66, 66, 50, 2, 1, 3, 6, NULL, NULL),
(127, 66, 66, 66, 66, 51, 2, 1, 3, 6, NULL, NULL),
(128, 77, 77, 88, 66, 8, 2, 1, 3, 1, NULL, NULL),
(129, 66, 77, 77, 77, 9, 2, 1, 3, 1, NULL, NULL),
(130, 88, 88, 88, 88, 48, 2, 1, 3, 1, NULL, NULL),
(131, 88, 88, 88, 88, 49, 2, 1, 3, 1, NULL, NULL),
(132, 88, 88, 88, 88, 50, 2, 1, 3, 1, NULL, NULL),
(133, 88, 88, 88, 88, 51, 2, 1, 3, 1, NULL, NULL),
(134, 58, 99, 99, 99, 8, 2, 1, 3, 5, NULL, NULL),
(135, 99, 99, 99, 99, 9, 2, 1, 3, 5, NULL, NULL),
(136, 99, 99, 99, 99, 48, 2, 1, 3, 5, NULL, NULL),
(137, 99, 99, 99, 99, 49, 2, 1, 3, 5, NULL, NULL),
(138, 99, 99, 99, 99, 50, 2, 1, 3, 5, NULL, NULL),
(139, 99, 99, 99, 99, 51, 2, 1, 3, 5, NULL, NULL),
(140, 56, 77, 66, 77, 8, 2, 1, 3, 4, NULL, NULL),
(141, 77, 7, 77, 77, 9, 2, 1, 3, 4, NULL, NULL),
(142, 77, 77, 77, 77, 48, 2, 1, 3, 4, NULL, NULL),
(143, 77, 77, 77, 77, 49, 2, 1, 3, 4, NULL, NULL),
(144, 77, 77, 77, 77, 50, 2, 1, 3, 4, NULL, NULL),
(145, 77, 77, 77, 77, 51, 2, 1, 3, 4, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `assessment_types`
--

CREATE TABLE `assessment_types` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `percentage` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `assessment_types`
--

INSERT INTO `assessment_types` (`id`, `name`, `percentage`, `created_at`, `updated_at`) VALUES
(1, 'First test', 10, NULL, NULL),
(2, 'Second test', 10, NULL, NULL),
(3, 'Third test', 10, NULL, NULL),
(4, 'Exam', 70, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `beces`
--

CREATE TABLE `beces` (
  `id` int(10) UNSIGNED NOT NULL,
  `student_id` int(10) UNSIGNED NOT NULL,
  `subject_id` int(10) UNSIGNED NOT NULL,
  `session_id` int(10) UNSIGNED NOT NULL,
  `score` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `beces`
--

INSERT INTO `beces` (`id`, `student_id`, `subject_id`, `session_id`, `score`, `created_at`, `updated_at`) VALUES
(17, 53, 1, 1, 89, NULL, NULL),
(18, 53, 2, 1, 55, NULL, NULL),
(19, 53, 3, 1, 77, NULL, NULL),
(20, 53, 4, 1, 44, NULL, NULL),
(21, 53, 5, 1, 88, NULL, NULL),
(22, 53, 6, 1, 55, NULL, NULL),
(23, 53, 12, 1, 9, NULL, NULL),
(24, 53, 13, 1, 66, NULL, NULL),
(41, 54, 1, 1, 98, NULL, NULL),
(42, 54, 2, 1, 6, NULL, NULL),
(43, 54, 3, 1, 7, NULL, NULL),
(44, 54, 4, 1, 88, NULL, NULL),
(45, 54, 5, 1, 44, NULL, NULL),
(46, 54, 6, 1, 66, NULL, NULL),
(47, 54, 12, 1, 33, NULL, NULL),
(48, 54, 13, 1, 99, NULL, NULL),
(49, 52, 1, 1, 89, NULL, NULL),
(50, 52, 2, 1, 99, NULL, NULL),
(51, 52, 3, 1, 89, NULL, NULL),
(52, 52, 4, 1, 78, NULL, NULL),
(53, 52, 5, 1, 98, NULL, NULL),
(54, 52, 6, 1, 87, NULL, NULL),
(55, 52, 12, 1, 90, NULL, NULL),
(56, 52, 13, 1, 98, NULL, NULL),
(66, 49, 1, 1, 56, NULL, NULL),
(67, 49, 3, 1, 89, NULL, NULL),
(68, 49, 4, 1, 77, NULL, NULL),
(69, 49, 5, 1, 88, NULL, NULL),
(70, 49, 6, 1, 99, NULL, NULL),
(71, 49, 7, 1, 45, NULL, NULL),
(72, 49, 8, 1, 89, NULL, NULL),
(73, 49, 10, 1, 99, NULL, NULL),
(74, 49, 11, 1, 99, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `bece_details`
--

CREATE TABLE `bece_details` (
  `id` int(10) UNSIGNED NOT NULL,
  `student_id` int(10) UNSIGNED NOT NULL,
  `examination_no` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remark` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bece_details`
--

INSERT INTO `bece_details` (`id`, `student_id`, `examination_no`, `remark`, `created_at`, `updated_at`) VALUES
(1, 52, 'Peter', 'Stupidly behaved well', NULL, NULL),
(2, 53, 'BCDE400GO', 'Well behaved but practically stupid', NULL, NULL),
(3, 54, '3567YT90', 'Good', NULL, NULL),
(4, 49, 'ADS13B00199Y', 'Good boy', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `clubs`
--

CREATE TABLE `clubs` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `clubs`
--

INSERT INTO `clubs` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Jet', NULL, NULL),
(2, 'Health', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cummulative_assessements`
--

CREATE TABLE `cummulative_assessements` (
  `id` int(10) UNSIGNED NOT NULL,
  `score` int(10) UNSIGNED NOT NULL,
  `student_id` int(10) UNSIGNED NOT NULL,
  `aagc_id` int(10) UNSIGNED NOT NULL,
  `session_id` int(10) UNSIGNED NOT NULL,
  `term_id` int(10) UNSIGNED NOT NULL,
  `subject_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cummulative_assessements`
--

INSERT INTO `cummulative_assessements` (`id`, `score`, `student_id`, `aagc_id`, `session_id`, `term_id`, `subject_id`, `created_at`, `updated_at`) VALUES
(1, 84, 8, 2, 1, 1, 1, NULL, NULL),
(2, 53, 9, 2, 1, 1, 1, NULL, NULL),
(3, 80, 8, 2, 1, 1, 2, NULL, NULL),
(4, 29, 9, 2, 1, 1, 2, NULL, NULL),
(5, 89, 8, 2, 1, 1, 2, NULL, NULL),
(6, 54, 48, 2, 1, 1, 2, NULL, NULL),
(7, 84, 49, 2, 1, 1, 2, NULL, NULL),
(8, 85, 50, 2, 1, 1, 2, NULL, NULL),
(9, 80, 51, 2, 1, 1, 2, NULL, NULL),
(10, 79, 48, 2, 1, 1, 1, NULL, NULL),
(11, 57, 49, 2, 1, 1, 1, NULL, NULL),
(12, 85, 50, 2, 1, 1, 1, NULL, NULL),
(13, 89, 51, 2, 1, 1, 1, NULL, NULL),
(14, 64, 8, 2, 1, 1, 3, NULL, NULL),
(15, 59, 9, 2, 1, 1, 3, NULL, NULL),
(16, 22, 48, 2, 1, 1, 3, NULL, NULL),
(17, 81, 49, 2, 1, 1, 3, NULL, NULL),
(18, 27, 50, 2, 1, 1, 3, NULL, NULL),
(19, 77, 51, 2, 1, 1, 3, NULL, NULL),
(20, 80, 8, 2, 1, 1, 13, NULL, NULL),
(21, 95, 9, 2, 1, 1, 13, NULL, NULL),
(22, 86, 48, 2, 1, 1, 13, NULL, NULL),
(23, 86, 49, 2, 1, 1, 13, NULL, NULL),
(24, 30, 50, 2, 1, 1, 13, NULL, NULL),
(25, 65, 51, 2, 1, 1, 13, NULL, NULL),
(26, 75, 8, 2, 1, 1, 12, NULL, NULL),
(27, 54, 9, 2, 1, 1, 12, NULL, NULL),
(28, 78, 48, 2, 1, 1, 12, NULL, NULL),
(29, 99, 49, 2, 1, 1, 12, NULL, NULL),
(30, 88, 50, 2, 1, 1, 12, NULL, NULL),
(31, 56, 51, 2, 1, 1, 12, NULL, NULL),
(32, 52, 8, 2, 1, 1, 5, NULL, NULL),
(33, 22, 9, 2, 1, 1, 5, NULL, NULL),
(34, 61, 48, 2, 1, 1, 5, NULL, NULL),
(35, 69, 49, 2, 1, 1, 5, NULL, NULL),
(36, 84, 50, 2, 1, 1, 5, NULL, NULL),
(37, 52, 51, 2, 1, 1, 5, NULL, NULL),
(38, 98, 8, 2, 1, 1, 6, NULL, NULL),
(39, 66, 9, 2, 1, 1, 6, NULL, NULL),
(40, 25, 48, 2, 1, 1, 6, NULL, NULL),
(41, 56, 49, 2, 1, 1, 6, NULL, NULL),
(42, 73, 50, 2, 1, 1, 6, NULL, NULL),
(43, 28, 51, 2, 1, 1, 6, NULL, NULL),
(44, 75, 8, 2, 1, 1, 4, NULL, NULL),
(45, 82, 9, 2, 1, 1, 4, NULL, NULL),
(46, 66, 48, 2, 1, 1, 4, NULL, NULL),
(47, 28, 49, 2, 1, 1, 4, NULL, NULL),
(48, 32, 50, 2, 1, 1, 4, NULL, NULL),
(49, 30, 51, 2, 1, 1, 4, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `grades`
--

CREATE TABLE `grades` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lower_bound` int(10) UNSIGNED NOT NULL,
  `upper_bound` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`) VALUES
(1, 'Junior School'),
(2, 'Senior School');

-- --------------------------------------------------------

--
-- Table structure for table `group_classes`
--

CREATE TABLE `group_classes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `group_classes`
--

INSERT INTO `group_classes` (`id`, `name`, `group_id`) VALUES
(1, 'JSS 1', 1),
(2, 'JSS 2', 1),
(3, 'JSS3', 1),
(4, 'SSS1', 2),
(5, 'SSS2', 2),
(6, 'SSS3', 2);

-- --------------------------------------------------------

--
-- Table structure for table `houses`
--

CREATE TABLE `houses` (
  `id` int(10) UNSIGNED NOT NULL,
  `colour` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `houses`
--

INSERT INTO `houses` (`id`, `colour`, `created_at`, `updated_at`) VALUES
(1, 'Red', NULL, NULL),
(2, 'Green', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `junior_mocks`
--

CREATE TABLE `junior_mocks` (
  `id` int(10) UNSIGNED NOT NULL,
  `student_id` int(10) UNSIGNED NOT NULL,
  `subject_id` int(10) UNSIGNED NOT NULL,
  `session_id` int(10) UNSIGNED NOT NULL,
  `score` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `junior_mocks`
--

INSERT INTO `junior_mocks` (`id`, `student_id`, `subject_id`, `session_id`, `score`, `created_at`, `updated_at`) VALUES
(9, 52, 1, 1, 100, NULL, NULL),
(10, 52, 2, 1, 98, NULL, NULL),
(11, 52, 3, 1, 98, NULL, NULL),
(12, 52, 4, 1, 97, NULL, NULL),
(13, 52, 5, 1, 97, NULL, NULL),
(14, 52, 6, 1, 100, NULL, NULL),
(15, 52, 12, 1, 100, NULL, NULL),
(16, 52, 13, 1, 100, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `junior_mock_details`
--

CREATE TABLE `junior_mock_details` (
  `id` int(10) UNSIGNED NOT NULL,
  `student_id` int(10) UNSIGNED NOT NULL,
  `remark` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `junior_mock_details`
--

INSERT INTO `junior_mock_details` (`id`, `student_id`, `remark`, `created_at`, `updated_at`) VALUES
(1, 52, 'Great girl for life', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `lgas`
--

CREATE TABLE `lgas` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lgas`
--

INSERT INTO `lgas` (`id`, `name`, `state_id`) VALUES
(1, 'badagry', 1),
(2, 'Owerri', 2);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(6, '2018_05_06_230128_create_student_spies_table', 2),
(7, '2018_05_15_231030_create_next_term_begins_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `necos`
--

CREATE TABLE `necos` (
  `id` int(10) UNSIGNED NOT NULL,
  `student_id` int(10) UNSIGNED NOT NULL,
  `subject_id` int(10) UNSIGNED NOT NULL,
  `session_id` int(10) UNSIGNED NOT NULL,
  `score` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `necos`
--

INSERT INTO `necos` (`id`, `student_id`, `subject_id`, `session_id`, `score`, `created_at`, `updated_at`) VALUES
(10, 49, 1, 1, 77, NULL, NULL),
(11, 49, 3, 1, 99, NULL, NULL),
(12, 49, 4, 1, 88, NULL, NULL),
(13, 49, 5, 1, 99, NULL, NULL),
(14, 49, 6, 1, 44, NULL, NULL),
(15, 49, 7, 1, 88, NULL, NULL),
(16, 49, 8, 1, 99, NULL, NULL),
(17, 49, 10, 1, 99, NULL, NULL),
(18, 49, 11, 1, 89, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `neco_details`
--

CREATE TABLE `neco_details` (
  `id` int(10) UNSIGNED NOT NULL,
  `student_id` int(10) UNSIGNED NOT NULL,
  `examination_no` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remark` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `neco_details`
--

INSERT INTO `neco_details` (`id`, `student_id`, `examination_no`, `remark`, `created_at`, `updated_at`) VALUES
(1, 49, 'ADS13B00199Y', 'Great boy in class', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `next_term_begins`
--

CREATE TABLE `next_term_begins` (
  `id` int(10) UNSIGNED NOT NULL,
  `begins` date NOT NULL,
  `session_id` int(10) UNSIGNED NOT NULL,
  `term_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `old_testimonials`
--

CREATE TABLE `old_testimonials` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `areas_good_at` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_admitted` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_graduated` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_held` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conduct` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `old_testimonials`
--

INSERT INTO `old_testimonials` (`id`, `name`, `areas_good_at`, `image`, `session_admitted`, `session_graduated`, `post_held`, `abilities`, `conduct`, `created_at`, `updated_at`) VALUES
(1, 'Peter Moses', 'ppp', '1526305362.jpeg', 'ppp', 'ppp', 'ppp', 'ppp', 'ppp', '2018-05-14 12:30:26', '2018-05-14 12:42:42');

-- --------------------------------------------------------

--
-- Table structure for table `parents`
--

CREATE TABLE `parents` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone1` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone2` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `parents`
--

INSERT INTO `parents` (`id`, `name`, `address`, `phone1`, `phone2`, `created_at`, `updated_at`) VALUES
(3, 'Mrs. Peter Serah', '10, Arukwe Street, aradagun; Badagry', '08039092522', '08029906960', NULL, '2018-05-08 02:48:03'),
(5, 'Mr. Adeshina', 'Gbagi, Ibadan', '08090906990', '08022334455', NULL, NULL),
(6, 'Dorcas Sanni', 'This is the one', '08033668844', '45286489', NULL, NULL),
(7, 'ppp', 'pp', 'ppp', 'ppp', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `parent_relationships`
--

CREATE TABLE `parent_relationships` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `senior_mocks`
--

CREATE TABLE `senior_mocks` (
  `id` int(10) UNSIGNED NOT NULL,
  `student_id` int(10) UNSIGNED NOT NULL,
  `subject_id` int(10) UNSIGNED NOT NULL,
  `session_id` int(10) UNSIGNED NOT NULL,
  `score` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `senior_mocks`
--

INSERT INTO `senior_mocks` (`id`, `student_id`, `subject_id`, `session_id`, `score`, `created_at`, `updated_at`) VALUES
(1, 49, 1, 1, 89, NULL, NULL),
(2, 49, 3, 1, 54, NULL, NULL),
(3, 49, 4, 1, 66, NULL, NULL),
(4, 49, 5, 1, 99, NULL, NULL),
(5, 49, 6, 1, 88, NULL, NULL),
(6, 49, 7, 1, 99, NULL, NULL),
(7, 49, 8, 1, 77, NULL, NULL),
(8, 49, 10, 1, 88, NULL, NULL),
(9, 49, 11, 1, 99, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `senior_mock_details`
--

CREATE TABLE `senior_mock_details` (
  `id` int(10) UNSIGNED NOT NULL,
  `student_id` int(10) UNSIGNED NOT NULL,
  `remark` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `senior_mock_details`
--

INSERT INTO `senior_mock_details` (`id`, `student_id`, `remark`, `created_at`, `updated_at`) VALUES
(1, 49, 'Great', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, '2017/2018 Academic Session', NULL, NULL),
(2, '2018/2019 Academic Session', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `session_term`
--

CREATE TABLE `session_term` (
  `id` int(10) UNSIGNED NOT NULL,
  `session_id` int(10) UNSIGNED NOT NULL,
  `term_id` int(10) UNSIGNED NOT NULL,
  `status` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `session_term`
--

INSERT INTO `session_term` (`id`, `session_id`, `term_id`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 0, NULL, NULL),
(2, 1, 2, 0, NULL, NULL),
(3, 1, 3, 1, NULL, NULL),
(4, 2, 1, 0, NULL, NULL),
(5, 2, 2, 0, NULL, NULL),
(6, 2, 3, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE `states` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`id`, `name`) VALUES
(1, 'Lagos'),
(2, 'Imo');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(10) UNSIGNED NOT NULL,
  `admission_no` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surname` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `othernames` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dob` date NOT NULL,
  `blood_group` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `genotype` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `health_challenges` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emergency_treatment` tinyint(1) NOT NULL,
  `immunization` tinyint(1) NOT NULL,
  `lab_test` tinyint(1) NOT NULL,
  `admitted_session_id` int(10) UNSIGNED NOT NULL,
  `graduated_session_id` int(10) UNSIGNED DEFAULT NULL,
  `parent_id` int(10) UNSIGNED NOT NULL,
  `state_id` int(10) UNSIGNED NOT NULL,
  `lga_id` int(10) UNSIGNED NOT NULL,
  `parent_relationship` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `club_id` int(10) UNSIGNED NOT NULL,
  `house_id` int(10) UNSIGNED NOT NULL,
  `student_category_id` int(10) UNSIGNED NOT NULL,
  `status` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `admission_no`, `surname`, `othernames`, `gender`, `dob`, `blood_group`, `genotype`, `health_challenges`, `emergency_treatment`, `immunization`, `lab_test`, `admitted_session_id`, `graduated_session_id`, `parent_id`, `state_id`, `lga_id`, `parent_relationship`, `club_id`, `house_id`, `student_category_id`, `status`, `created_at`, `updated_at`) VALUES
(8, 'CSMT/SSS/2015/001', 'Peters', 'Moses Hennuho', 'male', '2001-04-07', 'A', 'AS', 'non', 0, 1, 1, 1, NULL, 3, 1, 1, 'Mother', 2, 2, 2, 0, '2018-05-07 12:59:21', '2018-05-14 14:22:49'),
(9, 'CSMT/SSS/2015/002', 'Adeshina', 'Adetoye', 'male', '2018-01-01', 'A', 'AS', 'AS', 1, 1, 1, 1, NULL, 5, 2, 2, 'Father', 2, 2, 2, 0, '2018-05-08 03:55:31', '2018-05-09 03:25:51'),
(48, 'CSMT/SSS/2015/003', 'Razak', 'Sodiq', 'male', '2018-02-02', 'A', 'AS', 'AS', 1, 1, 1, 1, NULL, 3, 2, 2, 'parent', 2, 2, 2, 0, '2018-05-12 00:31:48', '2018-05-12 00:31:48'),
(49, 'CSMT/SSS/2015/004', 'Moz', 'Joy', 'male', '2018-02-02', 'A', 'AS', 'AS', 1, 1, 1, 1, NULL, 3, 2, 2, 'parent', 2, 2, 2, 0, '2018-05-12 00:32:01', '2018-05-12 00:32:01'),
(50, 'CSMT/SSS/2015/005', 'May', 'Crite', 'male', '2018-02-02', 'A', 'AS', 'AS', 1, 1, 1, 1, NULL, 3, 2, 2, 'parent', 2, 2, 2, 0, '2018-05-12 00:32:16', '2018-05-12 00:32:16'),
(51, 'CSMT/SSS/2015/006', 'Peter', 'Yarw', 'male', '2018-02-02', 'A', 'AS', 'AS', 1, 1, 1, 1, NULL, 3, 2, 2, 'parent', 2, 2, 2, 0, '2018-05-12 00:32:36', '2018-05-12 00:32:36'),
(52, 'CSMT/SSS/2015/030', 'Sanni', 'Deborah', 'female', '2005-05-05', 'A', 'AS', 'non', 1, 1, 1, 1, NULL, 6, 1, 1, 'Mother', 2, 2, 2, 0, '2018-05-13 07:58:25', '2018-05-13 07:58:25'),
(53, 'CSMT/SSS/2015/031', 'Joh', 'Forland', 'male', '2005-07-07', 'A', 'AS', 'AS', 1, 1, 1, 1, NULL, 7, 2, 2, 'pppp', 2, 2, 2, 0, '2018-05-13 08:01:59', '2018-05-13 08:01:59'),
(54, 'CSMT/SSS/2015/033', 'Godin', 'Joe', 'male', '2018-12-30', 'A', 'AS', 'non', 1, 1, 1, 1, NULL, 3, 2, 2, 'pp', 2, 2, 2, 0, '2018-05-13 20:20:38', '2018-05-13 20:20:38'),
(56, 'CSMT/SSS/2015/036', 'May', 'John', 'female', '2016-11-29', 'A+', 'AA', 'non', 1, 1, 1, 1, NULL, 3, 1, 1, 'Father', 1, 1, 2, 0, '2018-05-15 09:46:20', '2018-05-15 09:46:20');

-- --------------------------------------------------------

--
-- Table structure for table `student_categories`
--

CREATE TABLE `student_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `student_categories`
--

INSERT INTO `student_categories` (`id`, `name`) VALUES
(1, 'Day'),
(2, 'Boarding');

-- --------------------------------------------------------

--
-- Table structure for table `student_spies`
--

CREATE TABLE `student_spies` (
  `id` int(10) UNSIGNED NOT NULL,
  `student_id` int(10) UNSIGNED NOT NULL,
  `aagc_id` int(10) UNSIGNED NOT NULL,
  `current_class` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `arm` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `student_spies`
--

INSERT INTO `student_spies` (`id`, `student_id`, `aagc_id`, `current_class`, `arm`) VALUES
(5, 8, 2, 'JSS 1', 'A(Ruby)'),
(6, 9, 2, 'JSS 1', 'A(Ruby)'),
(7, 48, 2, 'JSS 1', 'A(Ruby)'),
(8, 49, 10, 'SSS3', 'A(Science)'),
(9, 50, 2, 'JSS 1', 'A(Ruby)'),
(10, 51, 2, 'JSS 1', 'A(Ruby)'),
(11, 52, 8, 'JSS3', 'B(Diamond)'),
(12, 53, 8, 'JSS3', 'B(Diamond)'),
(13, 54, 7, 'JSS3', 'A(Ruby)'),
(14, 56, 5, 'JSS 2', 'A(Ruby)');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_school_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `name`, `subject_school_id`, `created_at`, `updated_at`) VALUES
(1, 'Computer Science', 1, '2018-05-07 05:42:58', '2018-05-07 05:42:58'),
(2, 'Basic Science', 2, '2018-05-08 06:03:15', '2018-05-08 06:03:15'),
(3, 'Agricultural Science', 1, '2018-05-08 06:03:46', '2018-05-08 06:03:46'),
(4, 'Mathematics', 1, '2018-05-08 06:03:57', '2018-05-08 06:03:57'),
(5, 'English Language', 1, '2018-05-08 06:04:10', '2018-05-08 06:04:10'),
(6, 'Civic Education', 1, '2018-05-08 06:04:20', '2018-05-08 06:04:20'),
(7, 'Physics', 3, '2018-05-08 06:04:45', '2018-05-08 06:04:45'),
(8, 'Chemistry', 3, '2018-05-08 06:04:54', '2018-05-08 06:04:54'),
(9, 'Account', 3, '2018-05-08 06:05:03', '2018-05-08 06:05:03'),
(10, 'Biology', 3, '2018-05-08 06:05:13', '2018-05-08 06:05:13'),
(11, 'Economics', 3, '2018-05-08 06:05:22', '2018-05-08 06:05:22'),
(12, 'Business Studies', 2, '2018-05-08 06:05:32', '2018-05-08 06:05:32'),
(13, 'Basic Technology', 2, '2018-05-08 06:05:45', '2018-05-08 06:05:45');

-- --------------------------------------------------------

--
-- Table structure for table `subject_categories`
--

CREATE TABLE `subject_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_school_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subject_categories`
--

INSERT INTO `subject_categories` (`id`, `name`, `subject_school_id`, `created_at`, `updated_at`) VALUES
(1, 'Science', 3, NULL, NULL),
(2, 'Business', 3, NULL, NULL),
(3, 'General', 2, NULL, NULL),
(4, 'Science', 2, NULL, NULL),
(5, 'Others', 2, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subject_schools`
--

CREATE TABLE `subject_schools` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subject_schools`
--

INSERT INTO `subject_schools` (`id`, `name`) VALUES
(1, 'All'),
(2, 'Junior'),
(3, 'Senior');

-- --------------------------------------------------------

--
-- Table structure for table `subject_subject_category`
--

CREATE TABLE `subject_subject_category` (
  `id` int(10) UNSIGNED NOT NULL,
  `subject_category_id` int(10) UNSIGNED NOT NULL,
  `subject_id` int(10) UNSIGNED NOT NULL,
  `subject_school_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subject_subject_category`
--

INSERT INTO `subject_subject_category` (`id`, `subject_category_id`, `subject_id`, `subject_school_id`) VALUES
(1, 1, 3, 3),
(2, 1, 10, 3),
(3, 1, 8, 3),
(4, 1, 6, 3),
(5, 1, 1, 3),
(6, 1, 11, 3),
(7, 1, 5, 3),
(8, 1, 4, 3),
(9, 1, 7, 3),
(10, 2, 9, 3),
(11, 2, 10, 3),
(12, 2, 6, 3),
(13, 2, 11, 3),
(14, 2, 5, 3),
(15, 2, 4, 3),
(16, 3, 5, 2),
(17, 3, 4, 2),
(18, 4, 3, 2),
(19, 4, 2, 2),
(20, 4, 13, 2),
(21, 4, 1, 2),
(22, 5, 12, 2),
(23, 5, 6, 2);

-- --------------------------------------------------------

--
-- Table structure for table `terms`
--

CREATE TABLE `terms` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `terms`
--

INSERT INTO `terms` (`id`, `name`) VALUES
(1, 'First term'),
(2, 'Second term'),
(3, 'Third term');

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

CREATE TABLE `testimonials` (
  `id` int(10) UNSIGNED NOT NULL,
  `areas_good_at` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_admitted` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_graduated` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_held` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `student_id` int(10) UNSIGNED NOT NULL,
  `conduct` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `testimonials`
--

INSERT INTO `testimonials` (`id`, `areas_good_at`, `image`, `session_admitted`, `session_graduated`, `post_held`, `abilities`, `student_id`, `conduct`, `created_at`, `updated_at`) VALUES
(4, 'Foolishness', '1526300657.jpeg', '2017/2018 Academic Session', '2017/2018 Academic Session', 'Bad Boy king', 'Stupidity', 9, 'Other qualities tells better', '2018-05-14 11:24:17', '2018-05-14 11:24:17');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Moses Peter', 'mohemos@live.com', '$2y$10$2LuAKovAbtj0PYcRprXbU.ObHeJa8XCdqom30.begOkbStgHcFp6m', 'btOQlJEwwn3avmFuO3GsmsCWW0RixkxSyev4m8M0UfbWqxV3BXicL3Vgs6VZ', '2018-05-07 03:29:37', '2018-05-07 03:29:37');

-- --------------------------------------------------------

--
-- Table structure for table `waecs`
--

CREATE TABLE `waecs` (
  `id` int(10) UNSIGNED NOT NULL,
  `student_id` int(10) UNSIGNED NOT NULL,
  `subject_id` int(10) UNSIGNED NOT NULL,
  `session_id` int(10) UNSIGNED NOT NULL,
  `score` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `waecs`
--

INSERT INTO `waecs` (`id`, `student_id`, `subject_id`, `session_id`, `score`, `created_at`, `updated_at`) VALUES
(1, 49, 1, 1, 99, NULL, NULL),
(2, 49, 3, 1, 90, NULL, NULL),
(3, 49, 4, 1, 100, NULL, NULL),
(4, 49, 5, 1, 100, NULL, NULL),
(5, 49, 6, 1, 100, NULL, NULL),
(6, 49, 7, 1, 98, NULL, NULL),
(7, 49, 8, 1, 99, NULL, NULL),
(8, 49, 10, 1, 100, NULL, NULL),
(9, 49, 11, 1, 99, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `waec_details`
--

CREATE TABLE `waec_details` (
  `id` int(10) UNSIGNED NOT NULL,
  `student_id` int(10) UNSIGNED NOT NULL,
  `examination_no` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remark` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `waec_details`
--

INSERT INTO `waec_details` (`id`, `student_id`, `examination_no`, `remark`, `created_at`, `updated_at`) VALUES
(1, 49, 'ADS13B00199Y', 'The best on earth', NULL, NULL);

-- --------------------------------------------------------

--
-- Structure for view `aagc_view`
--
DROP TABLE IF EXISTS `aagc_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `aagc_view`  AS  select `aagc`.`id` AS `id`,`gc`.`name` AS `class`,concat(`a`.`name`,'(',`al`.`name`,')') AS `arm` from (((`aagc` join `group_classes` `gc` on((`gc`.`id` = `aagc`.`group_class_id`))) join `arms` `a` on((`a`.`id` = `aagc`.`arm_id`))) join `aliases` `al` on((`al`.`id` = `aagc`.`alias_id`))) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aagc`
--
ALTER TABLE `aagc`
  ADD PRIMARY KEY (`id`),
  ADD KEY `aagc_group_class_id_foreign` (`group_class_id`),
  ADD KEY `aagc_alias_id_foreign` (`alias_id`),
  ADD KEY `aagc_arm_id_foreign` (`arm_id`);

--
-- Indexes for table `aagc_session`
--
ALTER TABLE `aagc_session`
  ADD PRIMARY KEY (`id`),
  ADD KEY `aagc_session_session_id_foreign` (`session_id`),
  ADD KEY `aagc_session_aagc_id_foreign` (`aagc_id`);

--
-- Indexes for table `aagc_session_student`
--
ALTER TABLE `aagc_session_student`
  ADD PRIMARY KEY (`id`),
  ADD KEY `aagc_session_student_aagc_id_foreign` (`aagc_id`),
  ADD KEY `aagc_session_student_session_id_foreign` (`session_id`),
  ADD KEY `aagc_session_student_student_id_foreign` (`student_id`);

--
-- Indexes for table `aagc_subject`
--
ALTER TABLE `aagc_subject`
  ADD PRIMARY KEY (`id`),
  ADD KEY `aagc_subject_aagc_id_foreign` (`aagc_id`),
  ADD KEY `aagc_subject_subject_id_foreign` (`subject_id`);

--
-- Indexes for table `aagc_subject_student`
--
ALTER TABLE `aagc_subject_student`
  ADD PRIMARY KEY (`id`),
  ADD KEY `aagc_subject_student_subject_id_foreign` (`subject_id`),
  ADD KEY `aagc_subject_student_aagc_id_foreign` (`aagc_id`),
  ADD KEY `aagc_subject_student_student_id_foreign` (`student_id`),
  ADD KEY `aagc_subject_student_session_id_foreign` (`session_id`);

--
-- Indexes for table `aliases`
--
ALTER TABLE `aliases`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `arms`
--
ALTER TABLE `arms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `assessments`
--
ALTER TABLE `assessments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `assessments_aagc_id_foreign` (`aagc_id`),
  ADD KEY `assessments_session_id_foreign` (`session_id`),
  ADD KEY `assessments_term_id_foreign` (`term_id`),
  ADD KEY `assessments_student_id_foreign` (`student_id`),
  ADD KEY `assessments_subject_id_foreign` (`subject_id`);

--
-- Indexes for table `assessment_types`
--
ALTER TABLE `assessment_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `beces`
--
ALTER TABLE `beces`
  ADD PRIMARY KEY (`id`),
  ADD KEY `beces_student_id_foreign` (`student_id`),
  ADD KEY `beces_subject_id_foreign` (`subject_id`),
  ADD KEY `beces_session_id_foreign` (`session_id`);

--
-- Indexes for table `bece_details`
--
ALTER TABLE `bece_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bece_details_student_id_foreign` (`student_id`);

--
-- Indexes for table `clubs`
--
ALTER TABLE `clubs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cummulative_assessements`
--
ALTER TABLE `cummulative_assessements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cummulative_assessements_aagc_id_foreign` (`aagc_id`),
  ADD KEY `cummulative_assessements_session_id_foreign` (`session_id`),
  ADD KEY `cummulative_assessements_term_id_foreign` (`term_id`),
  ADD KEY `cummulative_assessements_student_id_foreign` (`student_id`),
  ADD KEY `cummulative_assessements_subject_id_foreign` (`subject_id`);

--
-- Indexes for table `grades`
--
ALTER TABLE `grades`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `group_classes`
--
ALTER TABLE `group_classes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `group_classes_group_id_foreign` (`group_id`);

--
-- Indexes for table `houses`
--
ALTER TABLE `houses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `junior_mocks`
--
ALTER TABLE `junior_mocks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `junior_mocks_student_id_foreign` (`student_id`),
  ADD KEY `junior_mocks_subject_id_foreign` (`subject_id`),
  ADD KEY `junior_mocks_session_id_foreign` (`session_id`);

--
-- Indexes for table `junior_mock_details`
--
ALTER TABLE `junior_mock_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `junior_mock_details_student_id_foreign` (`student_id`);

--
-- Indexes for table `lgas`
--
ALTER TABLE `lgas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lgas_state_id_foreign` (`state_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `necos`
--
ALTER TABLE `necos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `necos_student_id_foreign` (`student_id`),
  ADD KEY `necos_subject_id_foreign` (`subject_id`),
  ADD KEY `necos_session_id_foreign` (`session_id`);

--
-- Indexes for table `neco_details`
--
ALTER TABLE `neco_details`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `neco_details_examination_no_unique` (`examination_no`),
  ADD KEY `neco_details_student_id_foreign` (`student_id`);

--
-- Indexes for table `next_term_begins`
--
ALTER TABLE `next_term_begins`
  ADD PRIMARY KEY (`id`),
  ADD KEY `next_term_begins_session_id_foreign` (`session_id`),
  ADD KEY `next_term_begins_term_id_foreign` (`term_id`);

--
-- Indexes for table `old_testimonials`
--
ALTER TABLE `old_testimonials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `parents`
--
ALTER TABLE `parents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `parent_relationships`
--
ALTER TABLE `parent_relationships`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `senior_mocks`
--
ALTER TABLE `senior_mocks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `senior_mocks_student_id_foreign` (`student_id`),
  ADD KEY `senior_mocks_subject_id_foreign` (`subject_id`),
  ADD KEY `senior_mocks_session_id_foreign` (`session_id`);

--
-- Indexes for table `senior_mock_details`
--
ALTER TABLE `senior_mock_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `senior_mock_details_student_id_foreign` (`student_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `session_term`
--
ALTER TABLE `session_term`
  ADD PRIMARY KEY (`id`),
  ADD KEY `session_term_session_id_foreign` (`session_id`),
  ADD KEY `session_term_term_id_foreign` (`term_id`);

--
-- Indexes for table `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `students_admission_no_unique` (`admission_no`),
  ADD KEY `students_admitted_session_id_foreign` (`admitted_session_id`),
  ADD KEY `students_graduated_session_id_foreign` (`graduated_session_id`),
  ADD KEY `students_parent_id_foreign` (`parent_id`),
  ADD KEY `students_state_id_foreign` (`state_id`),
  ADD KEY `students_lga_id_foreign` (`lga_id`),
  ADD KEY `students_club_id_foreign` (`club_id`),
  ADD KEY `students_house_id_foreign` (`house_id`),
  ADD KEY `students_student_category_id_foreign` (`student_category_id`);

--
-- Indexes for table `student_categories`
--
ALTER TABLE `student_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_spies`
--
ALTER TABLE `student_spies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_spies_student_id_foreign` (`student_id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subjects_subject_school_id_foreign` (`subject_school_id`);

--
-- Indexes for table `subject_categories`
--
ALTER TABLE `subject_categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subject_categories_subject_school_id_foreign` (`subject_school_id`);

--
-- Indexes for table `subject_schools`
--
ALTER TABLE `subject_schools`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subject_subject_category`
--
ALTER TABLE `subject_subject_category`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subject_subject_category_subject_school_id_foreign` (`subject_school_id`),
  ADD KEY `subject_subject_category_subject_id_foreign` (`subject_id`),
  ADD KEY `subject_subject_category_subject_category_id_foreign` (`subject_category_id`);

--
-- Indexes for table `terms`
--
ALTER TABLE `terms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testimonials`
--
ALTER TABLE `testimonials`
  ADD PRIMARY KEY (`id`),
  ADD KEY `testimonials_student_id_foreign` (`student_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `waecs`
--
ALTER TABLE `waecs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `waecs_student_id_foreign` (`student_id`),
  ADD KEY `waecs_subject_id_foreign` (`subject_id`),
  ADD KEY `waecs_session_id_foreign` (`session_id`);

--
-- Indexes for table `waec_details`
--
ALTER TABLE `waec_details`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `waec_details_examination_no_unique` (`examination_no`),
  ADD KEY `waec_details_student_id_foreign` (`student_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aagc`
--
ALTER TABLE `aagc`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `aagc_session`
--
ALTER TABLE `aagc_session`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `aagc_session_student`
--
ALTER TABLE `aagc_session_student`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `aagc_subject`
--
ALTER TABLE `aagc_subject`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;
--
-- AUTO_INCREMENT for table `aagc_subject_student`
--
ALTER TABLE `aagc_subject_student`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=165;
--
-- AUTO_INCREMENT for table `aliases`
--
ALTER TABLE `aliases`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `arms`
--
ALTER TABLE `arms`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `assessments`
--
ALTER TABLE `assessments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=146;
--
-- AUTO_INCREMENT for table `assessment_types`
--
ALTER TABLE `assessment_types`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `beces`
--
ALTER TABLE `beces`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;
--
-- AUTO_INCREMENT for table `bece_details`
--
ALTER TABLE `bece_details`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `clubs`
--
ALTER TABLE `clubs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `cummulative_assessements`
--
ALTER TABLE `cummulative_assessements`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;
--
-- AUTO_INCREMENT for table `grades`
--
ALTER TABLE `grades`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `group_classes`
--
ALTER TABLE `group_classes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `houses`
--
ALTER TABLE `houses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `junior_mocks`
--
ALTER TABLE `junior_mocks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `junior_mock_details`
--
ALTER TABLE `junior_mock_details`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `lgas`
--
ALTER TABLE `lgas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `necos`
--
ALTER TABLE `necos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `neco_details`
--
ALTER TABLE `neco_details`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `next_term_begins`
--
ALTER TABLE `next_term_begins`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `old_testimonials`
--
ALTER TABLE `old_testimonials`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `parents`
--
ALTER TABLE `parents`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `parent_relationships`
--
ALTER TABLE `parent_relationships`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `senior_mocks`
--
ALTER TABLE `senior_mocks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `senior_mock_details`
--
ALTER TABLE `senior_mock_details`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `sessions`
--
ALTER TABLE `sessions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `session_term`
--
ALTER TABLE `session_term`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `states`
--
ALTER TABLE `states`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;
--
-- AUTO_INCREMENT for table `student_categories`
--
ALTER TABLE `student_categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `student_spies`
--
ALTER TABLE `student_spies`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `subject_categories`
--
ALTER TABLE `subject_categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `subject_schools`
--
ALTER TABLE `subject_schools`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `subject_subject_category`
--
ALTER TABLE `subject_subject_category`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `terms`
--
ALTER TABLE `terms`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `testimonials`
--
ALTER TABLE `testimonials`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `waecs`
--
ALTER TABLE `waecs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `waec_details`
--
ALTER TABLE `waec_details`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `aagc`
--
ALTER TABLE `aagc`
  ADD CONSTRAINT `aagc_alias_id_foreign` FOREIGN KEY (`alias_id`) REFERENCES `aliases` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `aagc_arm_id_foreign` FOREIGN KEY (`arm_id`) REFERENCES `arms` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `aagc_group_class_id_foreign` FOREIGN KEY (`group_class_id`) REFERENCES `group_classes` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `aagc_session`
--
ALTER TABLE `aagc_session`
  ADD CONSTRAINT `aagc_session_aagc_id_foreign` FOREIGN KEY (`aagc_id`) REFERENCES `aagc` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `aagc_session_session_id_foreign` FOREIGN KEY (`session_id`) REFERENCES `sessions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `aagc_session_student`
--
ALTER TABLE `aagc_session_student`
  ADD CONSTRAINT `aagc_session_student_aagc_id_foreign` FOREIGN KEY (`aagc_id`) REFERENCES `aagc` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `aagc_session_student_session_id_foreign` FOREIGN KEY (`session_id`) REFERENCES `sessions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `aagc_session_student_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `aagc_subject`
--
ALTER TABLE `aagc_subject`
  ADD CONSTRAINT `aagc_subject_aagc_id_foreign` FOREIGN KEY (`aagc_id`) REFERENCES `aagc` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `aagc_subject_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `aagc_subject_student`
--
ALTER TABLE `aagc_subject_student`
  ADD CONSTRAINT `aagc_subject_student_aagc_id_foreign` FOREIGN KEY (`aagc_id`) REFERENCES `aagc` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `aagc_subject_student_session_id_foreign` FOREIGN KEY (`session_id`) REFERENCES `sessions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `aagc_subject_student_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `aagc_subject_student_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `assessments`
--
ALTER TABLE `assessments`
  ADD CONSTRAINT `assessments_aagc_id_foreign` FOREIGN KEY (`aagc_id`) REFERENCES `aagc` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `assessments_session_id_foreign` FOREIGN KEY (`session_id`) REFERENCES `sessions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `assessments_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `assessments_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `assessments_term_id_foreign` FOREIGN KEY (`term_id`) REFERENCES `terms` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `beces`
--
ALTER TABLE `beces`
  ADD CONSTRAINT `beces_session_id_foreign` FOREIGN KEY (`session_id`) REFERENCES `sessions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `beces_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `beces_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `bece_details`
--
ALTER TABLE `bece_details`
  ADD CONSTRAINT `bece_details_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `cummulative_assessements`
--
ALTER TABLE `cummulative_assessements`
  ADD CONSTRAINT `cummulative_assessements_session_id_foreign` FOREIGN KEY (`session_id`) REFERENCES `sessions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `cummulative_assessements_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `cummulative_assessements_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `cummulative_assessements_term_id_foreign` FOREIGN KEY (`term_id`) REFERENCES `terms` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `group_classes`
--
ALTER TABLE `group_classes`
  ADD CONSTRAINT `group_classes_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `junior_mocks`
--
ALTER TABLE `junior_mocks`
  ADD CONSTRAINT `junior_mocks_session_id_foreign` FOREIGN KEY (`session_id`) REFERENCES `sessions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `junior_mocks_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `junior_mocks_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `junior_mock_details`
--
ALTER TABLE `junior_mock_details`
  ADD CONSTRAINT `junior_mock_details_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `lgas`
--
ALTER TABLE `lgas`
  ADD CONSTRAINT `lgas_state_id_foreign` FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `necos`
--
ALTER TABLE `necos`
  ADD CONSTRAINT `necos_session_id_foreign` FOREIGN KEY (`session_id`) REFERENCES `sessions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `necos_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `necos_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `neco_details`
--
ALTER TABLE `neco_details`
  ADD CONSTRAINT `neco_details_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `next_term_begins`
--
ALTER TABLE `next_term_begins`
  ADD CONSTRAINT `next_term_begins_session_id_foreign` FOREIGN KEY (`session_id`) REFERENCES `sessions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `next_term_begins_term_id_foreign` FOREIGN KEY (`term_id`) REFERENCES `terms` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `senior_mocks`
--
ALTER TABLE `senior_mocks`
  ADD CONSTRAINT `senior_mocks_session_id_foreign` FOREIGN KEY (`session_id`) REFERENCES `sessions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `senior_mocks_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `senior_mocks_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `senior_mock_details`
--
ALTER TABLE `senior_mock_details`
  ADD CONSTRAINT `senior_mock_details_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `session_term`
--
ALTER TABLE `session_term`
  ADD CONSTRAINT `session_term_session_id_foreign` FOREIGN KEY (`session_id`) REFERENCES `sessions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `session_term_term_id_foreign` FOREIGN KEY (`term_id`) REFERENCES `terms` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_admitted_session_id_foreign` FOREIGN KEY (`admitted_session_id`) REFERENCES `sessions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `students_club_id_foreign` FOREIGN KEY (`club_id`) REFERENCES `clubs` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `students_graduated_session_id_foreign` FOREIGN KEY (`graduated_session_id`) REFERENCES `sessions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `students_house_id_foreign` FOREIGN KEY (`house_id`) REFERENCES `houses` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `students_lga_id_foreign` FOREIGN KEY (`lga_id`) REFERENCES `lgas` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `students_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `parents` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `students_state_id_foreign` FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `students_student_category_id_foreign` FOREIGN KEY (`student_category_id`) REFERENCES `student_categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `student_spies`
--
ALTER TABLE `student_spies`
  ADD CONSTRAINT `student_spies_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `subjects`
--
ALTER TABLE `subjects`
  ADD CONSTRAINT `subjects_subject_school_id_foreign` FOREIGN KEY (`subject_school_id`) REFERENCES `subject_schools` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `subject_categories`
--
ALTER TABLE `subject_categories`
  ADD CONSTRAINT `subject_categories_subject_school_id_foreign` FOREIGN KEY (`subject_school_id`) REFERENCES `subject_schools` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `subject_subject_category`
--
ALTER TABLE `subject_subject_category`
  ADD CONSTRAINT `subject_subject_category_subject_category_id_foreign` FOREIGN KEY (`subject_category_id`) REFERENCES `subject_categories` (`id`),
  ADD CONSTRAINT `subject_subject_category_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `subject_subject_category_subject_school_id_foreign` FOREIGN KEY (`subject_school_id`) REFERENCES `subject_schools` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `testimonials`
--
ALTER TABLE `testimonials`
  ADD CONSTRAINT `testimonials_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `waecs`
--
ALTER TABLE `waecs`
  ADD CONSTRAINT `waecs_session_id_foreign` FOREIGN KEY (`session_id`) REFERENCES `sessions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `waecs_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `waecs_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `waec_details`
--
ALTER TABLE `waec_details`
  ADD CONSTRAINT `waec_details_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
