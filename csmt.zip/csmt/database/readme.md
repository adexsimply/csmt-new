Database function and their definations:


===========Grade point============

CREATE  gradePoint (test1 int, test2 int, test3 int, exam int) 
	RETURNS float(4,1)
	RETURN ((test1 + test2 + test3) * 0.1) + (exam * 0.7)


===========Grade============
CREATE FUNCTION grade (grade_point INT) RETURNS char(2) CHARSET latin1
	RETURN 
        CASE
            WHEN grade_point >= 90 THEN "A+"
            WHEN grade_point >= 80 THEN "A"
            WHEN grade_point >= 70 THEN "B+"
            WHEN grade_point >= 60 THEN "B"
            WHEN grade_point >= 50 THEN "C"
            WHEN grade_point >= 40 THEN "D"
            WHEN grade_point < 40 THEN "F"
        END



===========Remarks============

CREATE FUNCTION remark (grade_point INT) RETURNS varchar(15) CHARSET latin1
	RETURN 
        CASE
            WHEN grade_point >= 90 THEN "EXCELLENT"
            WHEN grade_point >= 80 THEN "VERY GOOD"
            WHEN grade_point >= 70 THEN "GOOD"
            WHEN grade_point >= 60 THEN "FAIRLY GOOD"
            WHEN grade_point >= 50 THEN "FAIR"
            WHEN grade_point >= 40 THEN "POOR"
            WHEN grade_point < 40 THEN "VERY POOR"
        END
