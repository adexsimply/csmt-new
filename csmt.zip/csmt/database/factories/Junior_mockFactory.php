<?php

use Faker\Generator as Faker;

$factory->define(App\Junior_mock::class, function (Faker $faker) {
    return [
        //
    ];
});
