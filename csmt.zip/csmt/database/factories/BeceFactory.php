<?php

use Faker\Generator as Faker;

$factory->define(App\Bece::class, function (Faker $faker) {
    return [
        //
    ];
});
