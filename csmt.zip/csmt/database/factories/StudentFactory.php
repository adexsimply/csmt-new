<?php

use Faker\Generator as Faker;

$factory->define(App\Student::class, function (Faker $faker) {
    return [
        'admission_no' => 'CSMT/SSS/2015/00'.rand(1,1000) ,
        'surname' => $faker->firstname,
        'othernames' => $faker->name,
        'gender' => 'male',
        'dob' => $faker->date,
        'blood_group' =>'a' ,'genotype' =>'a' ,'health_challenges' =>'a' ,'emergency_treatment' =>1 ,'immunization' => 1,'lab_test' =>1 ,'admitted_session_id' =>1 ,'graduated_session_id' =>1 ,'parent_id' =>3 ,'state_id' =>1 ,'lga_id' =>1 ,'parent_relationship' =>1 ,'club_id' =>1 ,'house_id' =>1 ,'student_category_id' =>1 ,'status'=>0

    ];
});

