<?php

use Faker\Generator as Faker;

$factory->define(App\Subject_category::class, function (Faker $faker) {
    return [
        //
    ];
});
